#!/bin/bash
npm run build-prod
node cloud/modules/run.js prod
