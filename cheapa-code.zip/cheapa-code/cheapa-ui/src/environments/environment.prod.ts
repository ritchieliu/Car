export const environment = {
  production: true,
  hmr: false,
  cognitoUserPoolId: 'ap-southeast-2_pEjVIKUT8',
  cognitoClientId: '7qeeq1n83ltulpkl2vlgkka007',
  apiBaseURL: 'https://api.cheapacarrental.com',
  googleApiKey: 'AIzaSyAZuvWMQM4qwFG9XpDvzZsPSu0oJGoaHQY',
  facebook: {
    appId: '1805041716228767'
  },
  google: {
    clientId: '1007290825087-v6t4qbj57ieansl8l0b2m148a6drtrg2.apps.googleusercontent.com'
  },
};
