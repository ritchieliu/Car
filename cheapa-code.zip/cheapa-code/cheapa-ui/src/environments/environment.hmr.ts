export const environment = {
  production: false,
  hmr: true,
  cognitoUserPoolId: 'us-east-1_Xe7ZV0BCE',
  cognitoClientId: '58fcte0uskjjuqdcktmptbe3ut',
  apiBaseURL: 'https://apidev.cheapacarrental.com',
  googleApiKey: 'AIzaSyAZuvWMQM4qwFG9XpDvzZsPSu0oJGoaHQY',
  facebook: {
    appId: '1805041716228767'
  },
  google: {
    clientId: '1007290825087-v6t4qbj57ieansl8l0b2m148a6drtrg2.apps.googleusercontent.com'
  },
};
