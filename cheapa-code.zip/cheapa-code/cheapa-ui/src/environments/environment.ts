// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  hmr: false,
  cognitoUserPoolId: 'us-east-1_Xe7ZV0BCE',
  cognitoClientId: '58fcte0uskjjuqdcktmptbe3ut',
  apiBaseURL: 'https://apidev.cheapacarrental.com',
  googleApiKey: 'AIzaSyAZuvWMQM4qwFG9XpDvzZsPSu0oJGoaHQY',
  facebook: {
    appId: '1805041716228767'
  },
  google: {
    clientId: '1007290825087-v6t4qbj57ieansl8l0b2m148a6drtrg2.apps.googleusercontent.com'
  },
};
