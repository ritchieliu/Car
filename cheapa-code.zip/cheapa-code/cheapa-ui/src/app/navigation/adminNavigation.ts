export const adminNavigation = [
  {
    'id': 'management',
    'title': 'management',
    'translate': 'navigation.management',
    'type': 'group',
    'children': [
      {
        'id': 'dashboard',
        'title': 'dashboard',
        'translate': 'navigation.dashboard',
        'type': 'item',
        'icon': 'dashboard',
        'url': '/admin/dashboard'
      },
      {
        'id': 'booking',
        'title': 'booking',
        'translate': 'navigation.booking',
        'type': 'item',
        'icon': 'booking',
        'url': '/admin/booking'
      },
      {
        'id': 'orders',
        'title': 'orders',
        'translate': 'navigation.orders',
        'type': 'item',
        'icon': 'receipt',
        'url': '/admin/orders'
      },
      {
        'id': 'vehicles',
        'title': 'vehicles',
        'translate': 'navigation.vehicles',
        'type': 'item',
        'icon': 'directions_car',
        'url': '/admin/vehicles'
      },
      {
        'id': 'vehicleCategories',
        'title': 'vehicleCategories',
        'translate': 'navigation.vehicleCategories',
        'type': 'item',
        'icon': 'category',
        'url': '/admin/vehicleCategories'
      },
      {
        'id': 'devices',
        'title': 'devices',
        'translate': 'navigation.devices',
        'type': 'item',
        'icon': 'devices',
        'url': '/admin/devices'
      },
      {
        'id': 'businesses',
        'title': 'businesses',
        'translate': 'navigation.businesses',
        'type': 'item',
        'icon': 'business',
        'url': '/admin/businesses'
      }
    ]
  }
];
