import {AccountsService} from "../main/accounts/accounts.service";

export function getClientNavigation(accountsService: AccountsService) {
  return [
    {
      'id': 'client',
      'title': '',
      'translate': '',
      'type': 'group',
      'children': [
        // {
        //   'id': 'findCars',
        //   'title': 'findCars',
        //   'translate': 'navigation.findCars',
        //   'type': 'item',
        //   'icon': 'search',
        //   'url': '/findCars'
        // },
        {
          'id': 'reserve',
          'title': 'reserve',
          'translate': 'navigation.reserve',
          'type': 'item',
          'icon': 'receipt',
          'url': '/reserve'
        },
        {
          'id': 'activeOrder',
          'title': 'activeOrder',
          'translate': 'navigation.activeOrder',
          'type': 'item',
          'icon': 'directions_car',
          'url': '/orders/active',
          'hidden': !accountsService.hasSignedIn(),
        },
        {
          'id': 'orders',
          'title': 'orders',
          'translate': 'navigation.orders',
          'type': 'item',
          'icon': 'receipt',
          'url': '/orders/list',
          'hidden': !accountsService.hasSignedIn(),
        },
        {
          'id': 'terms',
          'title': 'terms',
          'translate': 'navigation.terms',
          'type': 'item',
          'icon': 'assignment',
          'url': '/terms'
        },
        {
          'id': 'signIn',
          'title': 'Login',
          'translate': 'navigation.signIn',
          'type': 'item',
          'icon': 'lock',
          'url': '/accounts/login',
          'hidden': accountsService.hasSignedIn(),
        }
      ]
    }
  ];
}
