import {AccountsService} from "../main/accounts/accounts.service";

export function getPartnerNavigation(accountsService: AccountsService) {
  return [
    {
      'id': 'client',
      'title': '',
      'translate': '',
      'type': 'group',
      'children': [
        {
          'id': 'dashboard',
          'title': 'dashboard',
          'translate': 'navigation.dashboard',
          'type': 'item',
          'icon': 'dashboard',
          'url': '/admin/dashboard'
        },
        {
          'id': 'orders',
          'title': 'orders',
          'translate': 'navigation.orders',
          'type': 'item',
          'icon': 'receipt',
          'url': '/admin/orders'
        },
        {
          'id': 'vehicles',
          'title': 'vehicles',
          'translate': 'navigation.vehicles',
          'type': 'item',
          'icon': 'directions_car',
          'url': '/admin/vehicles'
        },
        {
          'id': 'terms',
          'title': 'terms',
          'translate': 'navigation.terms',
          'type': 'item',
          'icon': 'assignment',
          'url': '/terms'
        }
      ]
    }
  ];
}
