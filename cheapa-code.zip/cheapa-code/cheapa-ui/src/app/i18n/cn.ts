export const locale = {
    lang: 'cn',
    data: {
      navigation: {
        management: '管理',
        client: '客户端',
        dashboard: '控制台',
        devices: '车载设备',
        vehicles: '车辆',
        orders: '订单'
      },
      toolbar: {
        resetPassword: '密码重置',
        logout: '退出登录'
      },
      dashboard: {
        loading: '加载中...',
        vehicleId: '车牌号',
        deviceId: '设备号',
        vehicleDescription: '车型',
        seatNumber: '座位',
        rentPricePerDay: '租金',
        vehicleOrderButton: '下单',
        vehicleOpenDoorButton: '开门',
        vehicleCloseDoorButton: '关门',
      },
      accounts: {
        confirmPassword: {
          title: '密码重置',
          newPassword: '新密码',
          newPasswordRequired: '请输入新密码',
          passwordConfirm: '密码确认',
          passwordConfirmRequired: '请输入密码确认',
          passwordMatch: '密码不匹配',
          confirm: '确定',
          backToLogin: '继续登录',
          resetSuccess: '密码已经重置成功，请再次登录',
          NotAuthorizedException: '邮箱验证链接已过期',
          ExpiredCodeException: '邮箱验证链接已过期',
          InvalidParameterException: '无效的密码'
        },
        forgotPassword: {
          title: '忘记密码',
          email: '邮箱',
          emailRequired: '请输入邮箱',
          emailNotValid: '无效的邮箱',
          reset: '重置密码',
          backToLogin: '继续登录',
          resetSuccess: '密码重置邮件已经发送至您指定的邮箱',
          UserNotFoundException: '账号不存在'
        },
        login: {
          title: '账户登录',
          email: '邮箱',
          emailRequired: '请输入邮箱',
          emailNotValid: '无效的邮箱',
          password: '密码',
          passwordRequired: '请输入密码',
          forgotPassword: '忘记密码',
          login: '登录',
          UserNotFoundException: '无效的账户或密码',
          NotAuthorizedException: '无效的账户或密码'
        },
        newPassword: {
          title: '密码设置',
          newPassword: '新密码',
          newPasswordRequired: '请输入新密码',
          passwordConfirm: '密码确认',
          passwordConfirmRequired: '请输入密码确认',
          passwordMatch: '密码不匹配',
          confirm: '确定',
          backToLogin: '继续登录',
          NotAuthorizedException: '邮箱验证链接已过期',
          ExpiredCodeException: '邮箱验证链接已过期'
        },
        resetPassword: {
          title: '密码重置',
          oldPassword: '原密码',
          oldPasswordRequired: '请输入原密码',
          newPassword: '新密码',
          newPasswordRequired: '请输入新密码',
          passwordConfirm: '密码确认',
          passwordConfirmRequired: '请输入密码确认',
          passwordMatch: '密码不匹配',
          resetPassword: '重置',
          NotAuthorizedException: '无效的账户或密码',
          InvalidParameterException: '无效的密码'
        }
      },
      devices: {
        list: {
          title: '车载设备',
          deviceId: '设备号',
          vehicleId: '车牌号',
          password: '密码',
          mobile: '手机号',
          mobileExpireDate: '手机过期日期',
          action: '操作',
          edit: '修改',
        },
        instance: {
          updateTitle: '车载设备',
          deviceId: '设备号',
          vehicleId: '车牌号'
        },
        reports: {
          list: {
            title: '设备历史报告',
            createdAt: '时间',
            type: '类型',
            payload: '内容',
            LOCATION: '设备位置',
            ONLINE: '设备上线',
            CONFIRMATION: '设备确认',
          }
        },
        form: {
          deviceId: '设备号',
          deviceIdRequired: '请输入设备号',
          vehicleId: '车牌号',
          password: '密码',
          mobile: '手机号',
          mobileExpireDate: '手机过期日期',
          save: '保存',
          close: '关闭',
        },
        route: {
          start: '起点',
          end: '终点'
        }
      },
      vehicles: {
        list: {
          title: '车辆',
          id: '车牌号',
          deviceId: '车载设备',
          description: '车型',
          seatNumber: '座位',
          transmission: '变速',
          rentPricePerDay: '租金',
          location: '当前位置',
          locationUpdatedAt: '位置更新时间',
          action: '操作',
          actionOpenDoorButton: '开门',
          actionCloseDoorButton: '关门',
          deviceReport: '历史报告',
          deviceRoute: '行车轨迹',
          edit: '编辑'
        },
        form: {
          id: '车牌号',
          idRequired: '请输入车牌号',
          make: '品牌',
          makeRequired: '请输入品牌',
          model: '型号',
          modelRequired: '请输入型号',
          seatNumber: '座位数',
          seatNumberRequired: '请输入座位数',
          transmission: '手动/自动',
          transmissionManual: '手动',
          transmissionAuto: '自动',
          transmissionRequired: '请选择手动/自动',
          color: '颜色',
          colorRequired: '请输入颜色',
          year: '年份',
          yearRequired: '请输入年份',
          rentPricePerDay: '每日租金',
          rentPricePerDayRequired: '请输入每日租金',
          save: '保存',
          close: '关闭',
        },
      },
      orders: {
        list: {
          title: '订单',
          createdAt: '订单时间',
          vehicleId: '车牌号',
          email: '邮箱',
          pickUpDate: '取车日期',
          dropOffDate: '还车日期',
          paymentAmount: '付款'
        },
        form: {
          vehicleId: '车牌号',
          vehicleIdRequired: '请输入车牌号',
          email: '邮箱',
          emailRequired: '请输入邮箱',
          pickUpDate: '取车日期',
          pickUpDateRequired: '请输入取车日期',
          dropOffDate: '还车日期',
          dropOffDateRequired: '请输入还车日期',
          paymentAmount: '付款金额',
          paymentAmountRequired: '请输入付款金额',
          save: '保存',
          close: '关闭',
        },
      }
    }
  }
;
