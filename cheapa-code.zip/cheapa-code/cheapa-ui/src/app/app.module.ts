import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule, Routes} from '@angular/router';
import {TranslateModule} from '@ngx-translate/core';
import 'hammerjs';

import {FuseModule} from '@fuse/fuse.module';
import {FuseSharedModule} from '@fuse/shared.module';

import {fuseConfig} from './fuse-config';

import {AppComponent} from './app.component';
import {FuseMainModule} from './main/main.module';
import {AppSharedModule} from "./main/common/appShared.module";

const appRoutes: Routes = [
  {
    path: 'accounts',
    loadChildren: () => import('./main/accounts/accounts.module').then(m => m.AccountsModule)
  },
  {
    path: 'findCars',
    loadChildren: () => import('./main/content/findCars/findCars.module').then(m => m.FindCarsModule)
  },
  {
    path: 'booking',
    loadChildren: () => import('./main/content/booking/booking.module').then(m => m.BookingModule)
  },
  {
    path: 'reserve',
    loadChildren: () => import('./main/content/reserve/reserve.module').then(m => m.ReserveModule)
  },
  {
    path: 'orders',
    loadChildren: () => import('./main/content/orders/orders.module').then(m => m.OrdersModule)
  },
  {
    path: 'terms',
    loadChildren: () => import('./main/content/terms/terms.module').then(m => m.TermsModule)
  },
  {
    path: 'admin/dashboard',
    loadChildren: () => import('./main/content/admin/dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: 'admin/booking',
    loadChildren: () => import('./main/content/admin/booking/booking.module').then(m => m.BookingModule)
  },
  {
    path: 'admin/devices',
    loadChildren: () => import('./main/content/admin/devices/devices.module').then(m => m.DevicesModule)
  },
  {
    path: 'admin/vehicles',
    loadChildren: () => import('./main/content/admin/vehicles/vehicles.module').then(m => m.VehiclesModule)
  },
  {
    path: 'admin/vehicleCategories',
    loadChildren: () => import('./main/content/admin/vehicleCategories/vehicleCategories.module').then(m => m.VehicleCategoryesModule)
  },
  {
    path: 'admin/orders',
    loadChildren: () => import('./main/content/admin/orders/orders.module').then(m => m.OrdersModule)
  },
  {
    path: 'admin/businesses',
    loadChildren: () => import('./main/content/admin/businesses/businesses.module').then(m => m.BusinessesModule)
  },
  {
    path: '**',
    redirectTo: '/reserve'
  }
];

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    TranslateModule.forRoot(),

    // Fuse Main and Shared modules
    FuseModule.forRoot(fuseConfig),
    FuseSharedModule,
    FuseMainModule,
    AppSharedModule,
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule {
}
