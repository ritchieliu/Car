import {Injectable} from '@angular/core';
import {MatSnackBar} from "@angular/material";

@Injectable({
  providedIn: 'root',
})
export class SnackService {
  public SUCCESS_SNACK_CLASS: string = 'successSnack';
  public FAIL_SNACK_CLASS: string = 'failSnack';
  public IN_PROGRESS_SNACK_CLASS: string = 'inProgressSnack';

  constructor(private snackBar: MatSnackBar) {
  }

  openSnack(message, panelClass) {
    this.snackBar.open(message, '', {
      duration: 5000,
      verticalPosition: 'top',
      panelClass: panelClass
    });
  }
}
