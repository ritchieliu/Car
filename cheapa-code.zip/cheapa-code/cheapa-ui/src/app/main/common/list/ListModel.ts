import {DatatableComponent} from '@swimlane/ngx-datatable';

export class ListModel {
  fullContent = {
    Items: null
  };
  content = {
    Items: null
  };

  loading = false;

  constructor(public table: DatatableComponent, public attributes: string, public searchableFields: string[], public pageSize?: number) {
  }

  public async getList(callback) {
    this.loading = true;
    const result = await callback();
    this.loading = false;
    this.content = result;
    this.fullContent = {...result};
  }

  search(event) {
    const val = event.target.value.toLowerCase();
    this.table.offset = 0;
    if (!this.searchableFields) {
      this.content.Items = this.fullContent.Items;
      return;
    }

    if (!val) {
      this.content.Items = this.fullContent.Items;
      return;
    }

    const temp = this.fullContent.Items.filter(item => {
      return (() => {
        for (const field of this.searchableFields) {
          if (!item[field]) {
            return false;
          }
          if (item[field] instanceof Array) {
            for (const fieldItem of item[field]) {
              if (!fieldItem) {
                return false;
              }
              if (fieldItem.toLowerCase().indexOf(val) !== -1) {
                return true;
              }
            }
          } else if (item[field].toString().toLowerCase().indexOf(val) !== -1) {
            return true;
          }
        }
        return false;
      })();
    });

    this.content.Items = temp;
  }
}
