import {NgModule} from '@angular/core';
import {MatAutocompleteModule, MatButtonModule, MatCardModule, MatCheckboxModule, MatDatepickerModule, MatDialogModule, MatDividerModule, MatExpansionModule, MatIconModule, MatInputModule, MatListModule, MatMenuModule, MatPaginatorModule, MatProgressBarModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule, MatSnackBarModule, MatStepperModule, MatTableModule, MatTabsModule, MatToolbarModule, MatTooltipModule} from '@angular/material';
import 'hammerjs';
import {MatMomentDateModule} from "@angular/material-moment-adapter";

@NgModule({
  imports: [
    MatButtonModule,
    MatCheckboxModule,
    MatListModule,
    MatIconModule,
    MatCardModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatMenuModule,
    MatDialogModule,
    MatSidenavModule,
    MatTooltipModule,
    MatSelectModule,
    MatExpansionModule,
    MatRadioModule,
    MatTabsModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatAutocompleteModule,
    MatDividerModule,
    MatStepperModule,
  ],
  exports: [
    MatButtonModule,
    MatCheckboxModule,
    MatListModule,
    MatIconModule,
    MatCardModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatMenuModule,
    MatDialogModule,
    MatSidenavModule,
    MatTooltipModule,
    MatSelectModule,
    MatExpansionModule,
    MatRadioModule,
    MatTabsModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatAutocompleteModule,
    MatDividerModule,
    MatSnackBarModule,
    MatStepperModule,
  ]
})
export class MaterialModule {
}
