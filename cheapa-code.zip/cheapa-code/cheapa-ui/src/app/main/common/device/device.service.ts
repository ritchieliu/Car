import {Injectable} from '@angular/core';
import {Platform} from "@angular/cdk/platform";

@Injectable({
  providedIn: 'root',
})
export class DeviceService {
  constructor(private platform: Platform) {
  }

  isMobile() {
    if (this.platform.ANDROID || this.platform.IOS) {
      return true;
    }

    return false;
  }
}
