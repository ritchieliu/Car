import {NgModule} from '@angular/core';
import {LocalStorageModule} from 'angular-2-local-storage';
import {MaterialModule} from "./material.module";
import {TranslateModule} from "@ngx-translate/core";
import {FuseSharedModule} from "@fuse/shared.module";
import {RouterModule} from "@angular/router";
import {NgxDatatableModule} from "@swimlane/ngx-datatable";
import {MomentModule} from 'ngx-moment';
import {PageComponent} from "./paginator/page.component";
import {TooltipModule} from "ng2-tooltip-directive";
import {OwlMomentDateTimeModule} from "ng-pick-datetime/date-time/adapter/moment-adapter/moment-date-time.module";
import {OwlDateTimeModule} from "ng-pick-datetime";

@NgModule({
  declarations: [
    PageComponent,
  ],
  providers: [],
  imports: [
    RouterModule,
    LocalStorageModule.forRoot({
      prefix: 'cheapa',
      storageType: 'localStorage'
    }),
    TranslateModule,
    MaterialModule,
    FuseSharedModule,
    NgxDatatableModule,
    MomentModule,
    OwlDateTimeModule,
    OwlMomentDateTimeModule,
    TooltipModule
  ],
  exports: [
    RouterModule,
    LocalStorageModule,
    TranslateModule,
    MaterialModule,
    FuseSharedModule,
    NgxDatatableModule,
    MomentModule,
    PageComponent,
    OwlDateTimeModule,
    OwlMomentDateTimeModule,
    TooltipModule
  ]
})
export class AppSharedModule {
}
