import {Injectable} from '@angular/core';
import {Ng2ImgMaxService} from "ng2-img-max";

@Injectable({
  providedIn: 'root',
})
export class ImageUploadService {

  uploadingImageEvents = [];
  isImageUploading = false;
  uploadedFiles = [];

  constructor(private ng2ImgMaxService: Ng2ImgMaxService) {
  }

  getInstance() {
    return new ImageUploadService(this.ng2ImgMaxService);
  }
  async onUploadFinished($event, uploadRequest, uploadOptions?) {
    $event.pending = true;
    this.uploadingImageEvents.push($event);
    if (!this.isImageUploading) {
      this.isImageUploading = true;
      await this.uploadImage(uploadRequest, uploadOptions);
    }
  }

  async uploadImage(uploadRequest, uploadOptions) {
    let $event = this.uploadingImageEvents[0];
    if (!$event) {
      this.isImageUploading = false;
    }
    if ($event) {
      this.ng2ImgMaxService.resize([$event.file], uploadOptions && uploadOptions.maxWidth ? uploadOptions.maxWidth : 800, uploadOptions && uploadOptions.maxHeight ? uploadOptions.maxHeight : 800).subscribe(
        result => {
          let compressed = new File([result], result.name);
          const reader: FileReader = new FileReader();
          reader.readAsDataURL(compressed);
          reader.onload = async () => {
            let imageResponse: any = await uploadRequest(reader.result);
            $event.file = new File([result], imageResponse.key);
            $event.pending = false;
            this.uploadingImageEvents.shift();
            await this.uploadImage(uploadRequest, uploadOptions);
          };
        }
      );
    }
  }

  async onRemoved($event, request) {
    this.isImageUploading = true;
    let response = await request;
    this.isImageUploading = false;
    return response;
  }

  initUploadedFiles(images) {
    if (!images) {
      return [];
    }

    if (Array.isArray(images)) {
      this.uploadedFiles = images.map(item => {
        return {
          url: item.smallPath,
          fileName: item.key
        }
      });
    } else {
      this.uploadedFiles = [{
        url: images.smallPath,
        fileName: images.key
      }];
    }
  }
}
