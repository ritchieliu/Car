import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';




@Component({
  selector: 'app-pagination',
  templateUrl: './page.component.html'
})
export class PageComponent implements OnInit {
  listContent;
  listEvaluatedKeys = [''];
  listCurrentPageKey = '';

  @Input()
  set rows(value) {
    if (!value) {
      return;
    }
    this.listContent = value;
    if (this.listContent.LastEvaluatedKey) {
      if (!this.listEvaluatedKeys.includes(this.listContent.LastEvaluatedKey)) {
        this.listEvaluatedKeys.push(this.listContent.LastEvaluatedKey);
      }
    }
  }

  @Output() pageEvent = new EventEmitter();

  ngOnInit() {
  }

  previousPage() {
    this.listCurrentPageKey = this.listEvaluatedKeys[this.listEvaluatedKeys.indexOf(this.listCurrentPageKey) - 1];
    this.pageEvent.emit(this.listCurrentPageKey);
  }

  nextPage() {
    this.listCurrentPageKey = this.listEvaluatedKeys[this.listEvaluatedKeys.indexOf(this.listCurrentPageKey) + 1];
    this.pageEvent.emit(this.listCurrentPageKey);
  }

  isFirstPage() {
    if (this.listCurrentPageKey) {
      return false;
    } else {
      return true;
    }
  }

  isLastPage() {
    if (this.listContent && this.listContent.LastEvaluatedKey) {
      return false;
    } else {
      return true;
    }
  }
}
