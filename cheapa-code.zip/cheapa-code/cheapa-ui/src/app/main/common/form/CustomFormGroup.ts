import {AbstractControl, AsyncValidatorFn, FormGroup, ValidatorFn} from '@angular/forms';

export class CustomFormGroup extends FormGroup {

  successMessage: string;
  errorMessage: string;
  errorCode: string;
  submitting: boolean;
  successSubmitted: boolean;

  constructor(controls: {
    [key: string]: AbstractControl;
  }, validator?: ValidatorFn | null, asyncValidator?: AsyncValidatorFn | null) {
    super(controls, validator, asyncValidator);
  }

  async submit(callback) {
    if (!this.valid) {
      return;
    }
    this.submitting = true;
    try {
      await callback();
      this.successSubmitted = true;
    } catch (err) {
      if (err.error) {
        this.errorMessage = err.error.message;
        this.errorCode = err.error.code;
      } else {
        this.errorMessage = err.message;
        this.errorCode = err.code;
      }
    }

    this.submitting = false;
  }
}
