import {NgModule} from '@angular/core';
import {FuseToolbarComponent} from 'app/main/toolbar/toolbar.component';
import {ResetPasswordModule} from "../accounts/reset-password/reset-password.module";
import {AppSharedModule} from "../common/appShared.module";
import {ToolBarPhoneDialogComponent} from "./phoneDialog/phoneDialog.component";

@NgModule({
  declarations: [
    FuseToolbarComponent,
    ToolBarPhoneDialogComponent
  ],
  entryComponents: [
    ToolBarPhoneDialogComponent
  ],
  imports: [
    ResetPasswordModule,
    AppSharedModule
  ],
  exports: [
    FuseToolbarComponent
  ]
})
export class FuseToolbarModule {
}
