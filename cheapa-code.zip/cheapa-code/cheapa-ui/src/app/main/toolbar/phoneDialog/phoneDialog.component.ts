import {Component, OnInit} from '@angular/core';



import {MatDialogRef} from '@angular/material';
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";

@Component({
  selector: 'toolbar-phone-dialog',
  templateUrl: './phoneDialog.component.html'
})
export class ToolBarPhoneDialogComponent implements OnInit {

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<ToolBarPhoneDialogComponent>) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
  }

  close(): void {
    this.dialogRef.close();
  }
}
