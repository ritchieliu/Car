import {Component} from '@angular/core';
import {NavigationEnd, NavigationStart, Router} from '@angular/router';
import {TranslateService} from '@ngx-translate/core';

import {FuseConfigService} from '@fuse/services/config.service';
import {FuseSidebarService} from '@fuse/components/sidebar/sidebar.service';
import {AccountsService} from "../accounts/accounts.service";
import {MatDialog, MatDialogConfig} from "@angular/material";
import {AccountResetPasswordComponent} from "../accounts/reset-password/reset-password.component";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {locale as english} from "../../i18n/en";
import {locale as chinese} from "../../i18n/cn";
import {ToolBarPhoneDialogComponent} from "./phoneDialog/phoneDialog.component";

@Component({
  selector: 'fuse-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss']
})

export class FuseToolbarComponent {
  languages: any;
  selectedLanguage: any;
  showLoadingBar: boolean;
  horizontalNav: boolean;
  noNav: boolean;

  constructor(private router: Router,
              private fuseConfig: FuseConfigService,
              private sidebarService: FuseSidebarService,
              private translate: TranslateService,
              public accountsService: AccountsService,
              public dialog: MatDialog,
              private fuseTranslationLoader: FuseTranslationLoaderService,) {
    this.languages = [
      {
        'id': '中文',
        'title': '中文',
        'flag': 'cn'
      },
      {
        'id': 'en',
        'title': 'English',
        'flag': 'au'
      }
    ];

    this.selectedLanguage = this.languages[0];

    this.fuseTranslationLoader.loadTranslations(english, chinese);

    router.events.subscribe(
      (event) => {
        if (event instanceof NavigationStart) {
          this.showLoadingBar = true;
        }
        if (event instanceof NavigationEnd) {
          this.showLoadingBar = false;
        }
      });

    this.fuseConfig.onConfigChanged.subscribe((settings) => {
      this.horizontalNav = settings.layout.navigation === 'top';
      this.noNav = settings.layout.navigation === 'none';
    });

  }

  toggleSidebarOpened(key) {
    this.sidebarService.getSidebar(key).toggleOpen();
  }

  setLanguage(lang) {
    // Set the selected language for toolbar
    this.selectedLanguage = lang;

    // Use the selected language for translations
    this.translate.use(lang.id);
  }

  openChangePasswordDialog() {
    const dialogRef = this.dialog.open(AccountResetPasswordComponent, <MatDialogConfig>{
      width: '250px'
    });
  }

  openPhoneDialog() {
    this.dialog.open(ToolBarPhoneDialogComponent);
  }

  signOut() {
    this.accountsService.logout();
  }
}
