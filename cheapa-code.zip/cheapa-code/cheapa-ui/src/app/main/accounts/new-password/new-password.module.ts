import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AccountNewPasswordComponent} from './new-password.component';
import {AppSharedModule} from "../../common/appShared.module";

const routes = [
  {
    path: 'newPassword',
    component: AccountNewPasswordComponent
  }
];

@NgModule({
  declarations: [
    AccountNewPasswordComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule
  ]
})
export class NewPasswordModule {
}
