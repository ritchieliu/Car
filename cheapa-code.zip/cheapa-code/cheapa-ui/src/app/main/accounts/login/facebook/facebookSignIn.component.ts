import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {AccountsService} from '../../accounts.service';
import {FacebookService, InitParams, LoginResponse} from 'ngx-facebook';
import {environment} from 'environments/environment';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-facebook-signin',
  templateUrl: './facebookSignIn.component.html',
  styleUrls: ['facebookSignIn.component.css']
})
export class FacebookSignInComponent implements OnInit {

  @Output()
  submitted = new EventEmitter<boolean>();

  constructor(private fb: FacebookService,
              private accountsService: AccountsService) {
    const initParams: InitParams = {
      appId: environment.facebook.appId,
      xfbml: true,
      version: 'v2.10'
    };

    fb.init(initParams);
  }

  ngOnInit() {
  }

  async login() {
    const response: LoginResponse = await this.fb.login({
      enable_profile_selector: true,
      return_scopes: true,
      scope: 'public_profile,email'
    });
    this.submitted.emit(true);
    await this.accountsService.postToken('facebook', response.authResponse.accessToken);
    await this.accountsService.successRedirect();
  }
}
