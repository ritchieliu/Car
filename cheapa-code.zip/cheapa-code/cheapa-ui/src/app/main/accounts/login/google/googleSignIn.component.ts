import {Component, AfterViewInit, OnInit, Output, EventEmitter} from '@angular/core';
import {AccountsService} from '../../accounts.service';
import {environment} from 'environments/environment';
import {ActivatedRoute} from "@angular/router";

declare const gapi: any;

@Component({
  selector: 'app-google-signin',
  templateUrl: './googleSignIn.component.html',
  styleUrls: ['googleSignIn.component.css']
})
export class GoogleSignInComponent implements OnInit, AfterViewInit {

  public clientId = environment.google.clientId;
  public auth2: any;

  @Output()
  submitted = new EventEmitter<boolean>();

  constructor(private accountService: AccountsService) {
  }

  ngAfterViewInit() {
    gapi.load('auth2', () => {
      this.auth2 = gapi.auth2.init({
        client_id: this.clientId,
        scope: 'profile email'
      });

      this.attachSignIn(document.getElementById('googleBtn'));
    });
  }

  ngOnInit() {
  }

  public attachSignIn(element) {
    this.auth2.attachClickHandler(element, {}, async (googleUser) => {
      this.submitted.emit(true);
      await this.accountService.postToken('google', googleUser.getAuthResponse().id_token);
      await this.accountService.successRedirect();
    }, (error) => {
    });
  }
}
