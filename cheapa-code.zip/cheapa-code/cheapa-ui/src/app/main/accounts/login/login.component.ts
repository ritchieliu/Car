import {Component, OnInit} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {FuseConfigService} from '@fuse/services/config.service';
import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "../../../i18n/en";
import {locale as chinese} from "../../../i18n/cn";
import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';
import {CognitoUserSession} from "amazon-cognito-identity-js";
import {CognitoService} from "../cognito.service";
import {AccountsService} from "../accounts.service";
import {ActivatedRoute} from "@angular/router";
import {CustomFormGroup} from "../../common/form/CustomFormGroup";

@Component({
  selector: 'account-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations: fuseAnimations
})
export class AccountLoginComponent implements OnInit {
  form: CustomFormGroup = new CustomFormGroup({
    email: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required])
  });
  submitting = false;

  constructor(private fuseConfig: FuseConfigService,
              private fuseTranslationLoader: FuseTranslationLoaderService,
              private cognitoService: CognitoService,
              private accountsService: AccountsService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);

    this.fuseConfig.setConfig({
      layout: {
        // navigation: 'none',
        // toolbar: 'none',
      }
    });
  }

  ngOnInit() {
  }

  async onSubmit() {
    await this.form.submit(async () => {
        const cognitoToken = await this.cognitoService.signIn(this.form.value.email, this.form.value.password);
        this.submitting = true;
        await this.accountsService.postToken('cognito', (cognitoToken as CognitoUserSession).getIdToken().getJwtToken());
        await this.accountsService.successRedirect()
      }
    );
  }

  socialSubmitted(value) {
    this.submitting = value;
  }
}
