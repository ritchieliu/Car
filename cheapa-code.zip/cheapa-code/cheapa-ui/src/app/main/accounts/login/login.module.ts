import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AccountLoginComponent} from './login.component';
import {AppSharedModule} from "../../common/appShared.module";
import {FacebookSignInComponent} from "./facebook/facebookSignIn.component";
import {GoogleSignInComponent} from "./google/googleSignIn.component";
import {FacebookModule} from "ngx-facebook";

const routes = [
  {
    path: 'login',
    component: AccountLoginComponent
  }
];

@NgModule({
  declarations: [
    AccountLoginComponent,
    GoogleSignInComponent,
    FacebookSignInComponent,
  ],
  imports: [
    RouterModule.forChild(routes),
    FacebookModule.forRoot(),
    AppSharedModule,
  ]
})
export class LoginModule {
}
