import {NgModule} from '@angular/core';
import {AccountResetPasswordComponent} from './reset-password.component';
import {AppSharedModule} from "../../common/appShared.module";

@NgModule({
  declarations: [
    AccountResetPasswordComponent
  ],
  entryComponents: [
    AccountResetPasswordComponent
  ],
  imports: [
    AppSharedModule
  ]
})
export class ResetPasswordModule {
}
