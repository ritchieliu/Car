import {Component, OnInit} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {fuseAnimations} from '@fuse/animations';
import {CustomFormGroup} from "../../common/form/CustomFormGroup";
import {CustomValidators} from "ng2-validation";
import {MatDialogRef} from "@angular/material";
import {CognitoService} from "../cognito.service";
import {AccountsService} from "../accounts.service";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {locale as chinese} from "../../../i18n/cn";
import {locale as english} from "../../../i18n/en";

@Component({
  selector: 'account-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
  animations: fuseAnimations
})
export class AccountResetPasswordComponent {
  passwordFormControl = new FormControl('', Validators.required);
  form: CustomFormGroup = new CustomFormGroup({
    oldPassword: new FormControl('', Validators.required),
    password: this.passwordFormControl,
    verifyPassword: new FormControl('', [Validators.required, CustomValidators.equalTo(this.passwordFormControl)])
  });

  constructor(public dialogRef: MatDialogRef<AccountResetPasswordComponent>,
              public cognitoService: CognitoService,
              public accountsService: AccountsService,
              private fuseTranslationLoader: FuseTranslationLoaderService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  onSubmit() {
    this.form.submit(async () => {
        await this.cognitoService.changePassword(this.accountsService.getUser().email, this.form.value.oldPassword, this.form.value.password);
        this.dialogRef.close();
      }
    );
  }

  close(): void {
    this.dialogRef.close();
  }
}
