import {Injectable} from '@angular/core';

import {JwtHelperService} from '@auth0/angular-jwt';
import {environment} from '../../../environments/environment';
import {AppSharedService} from '../common/appShared.service';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AccountsService {

  jwtHelper: JwtHelperService = new JwtHelperService();

  baseApiURL = `${environment.apiBaseURL}/accounts`;

  user: any;

  constructor(private httpClient: HttpClient, private commonService: AppSharedService) {
  }

  hasSignedIn() {
    if (this.getIdToken()) {
      return true;
    }

    return false;
  }

  getUser(refresh?) {
    if (!this.hasSignedIn()) {
      return null;
    }

    if (!refresh && this.user) {
      return this.user;
    }
    this.user = this.jwtHelper.decodeToken(this.getIdToken());

    return this.user;
  }

  logout() {
    this.clearStorage();
    window.location.href = `${window.location.origin}/accounts/login`;
  }

  clearStorage() {
    this.commonService.clearLocalStorage();
  }

  signUp(email: string, preferred_username: string, phone_number: string) {
    return this.httpClient
      .request('post', `${this.baseApiURL}/cognito/signUp`, {
        body: {
          email,
          preferred_username,
          phone_number
        }
      })
      .toPromise()
      .catch(err => {
        throw err.error;
      });
  }

  async postToken(name: string, token: string) {
    const response = await this.httpClient
      .request('post', `${this.baseApiURL}/token`, {
        body: {
          name,
          token
        }
      }).toPromise();
    this.setIdToken(response['IdToken']);
    this.setRefreshToken(response['RefreshToken']);
    return response;
  }

  async getToken() {
    const response = await this.request('get', `${this.baseApiURL}/token`);
    this.setIdToken(response['IdToken']);
    return response;
  }

  async refreshToken() {
    const idToken = this.getIdToken();
    const refreshToken = this.getRefreshToken();
    if (!refreshToken || !idToken) {
      return Promise.resolve();
    }

    if (!this.jwtHelper.isTokenExpired(idToken)) {
      return Promise.resolve();
    }

    const response = await this.httpClient
      .request('post', `${this.baseApiURL}/token/refresh`, {
        body: {
          refresh_token: refreshToken
        }
      }).toPromise();
    const newIdToken = response['IdToken'];
    this.setIdToken(newIdToken);
    return newIdToken;
  }

  async request(method, url, options?) {
    await this.refreshToken();

    // Init headers
    if (!options) {
      options = {};
    }

    if (!options.headers) {
      options.headers = {};
    }

    // Set authorization header
    const idToken = this.getIdToken();
    if (idToken) {
      options.headers.authorization = idToken;
    }
    return this.httpClient
      .request(method, url, options)
      .toPromise();
  }

  get(id) {
    return this.request('get', `${this.baseApiURL}/${id}`);
  }

  update(id, data) {
    return this.request('put', `${this.baseApiURL}/${id}`, {
      body: data
    });
  }

  setIdToken(token) {
    this.commonService.setLocalStorage('IdToken', token);
    this.getUser(true);
  }

  getIdToken() {
    return this.commonService.getLocalStorage('IdToken');
  }

  setRefreshToken(token) {
    this.commonService.setLocalStorage('RefreshToken', token);
  }

  getRefreshToken() {
    return this.commonService.getLocalStorage('RefreshToken');
  }

  isAdmin() {
    let user = this.getUser();
    if (user && user.cognito_groups && user.cognito_groups.includes('admin')) {
      return true;
    }
    return false;
  }

  isPartner() {
    let user = this.getUser();
    if (user && user.cognito_groups && user.cognito_groups.includes('partner')) {
      return true;
    }
    return false;
  }

  successRedirect() {
    let targetUrl = this.commonService.getLocalStorage('targetUrl');
    if (targetUrl) {
      window.location.href = targetUrl;
    } else {
      if (this.isAdmin()) {
        window.location.href = `${window.location.origin}/admin/dashboard`;
      } else if (this.isPartner()) {
        window.location.href = `${window.location.origin}/admin/dashboard`;
      }else {
        window.location.href = `${window.location.origin}/orders/list`;
      }
    }
  }

  list(express, limit, startKey, q?) {
    let params = {
      express,
      limit,
      startKey
    };

    if (q) {
      params = Object.assign(params, q);
    }

    return this.request('get', this.baseApiURL, {
      params
    });
  }
}
