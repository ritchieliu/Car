import {Injectable} from '@angular/core';
import {Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot} from '@angular/router';
import {AccountsService} from './accounts.service';

@Injectable({
  providedIn: 'root',
})
export class AccountsCanActivatePartner implements CanActivate {

  constructor(private router: Router, private  accountsService: AccountsService) {
  }

  canActivate(route: ActivatedRouteSnapshot,
              state: RouterStateSnapshot) {
    if (this.accountsService.hasSignedIn() && (this.accountsService.isPartner() || this.accountsService.isAdmin())) {
      return true;
    }

    window.location.href = `/accounts/login?target=${encodeURIComponent(state.url)}`;

    return false;
  }
}
