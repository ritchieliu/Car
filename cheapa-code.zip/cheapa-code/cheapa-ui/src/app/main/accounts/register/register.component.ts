import {Component, OnInit} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {FuseConfigService} from '@fuse/services/config.service';
import {fuseAnimations} from '@fuse/animations';
import {CustomFormGroup} from "../../common/form/CustomFormGroup";
import {AccountsService} from "../accounts.service";

@Component({
  selector: 'account-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  animations: fuseAnimations
})
export class AccountRegisterComponent implements OnInit {
  form: CustomFormGroup = new CustomFormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    terms: new FormControl('', [Validators.requiredTrue])
  });

  constructor(private fuseConfig: FuseConfigService,
              private accountsService: AccountsService) {
    this.fuseConfig.setConfig({
      layout: {
        // navigation: 'none',
        // toolbar   : 'none',
        // footer    : 'none'
      }
    });
  }

  ngOnInit() {
  }

  onSubmit() {
    this.form.successMessage = '';
    this.form.errorMessage = '';
    this.form.submit(async () => {
        try {
          await this.accountsService.signUp(this.form.value.email, null, null);
          this.form.successMessage = 'Invitation letter sent! Please check your email.';
        } catch (e) {
          this.form.errorMessage = e.message;
        }
      }
    );
  }
}
