import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {AccountRegisterComponent} from './register.component';
import {AppSharedModule} from "../../common/appShared.module";

const routes = [
  {
    path: 'register',
    component: AccountRegisterComponent
  }
];

@NgModule({
  declarations: [
    AccountRegisterComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule
  ]
})
export class RegisterModule {
}
