import {Injectable} from '@angular/core';
import {AuthenticationDetails, CognitoUser, CognitoUserAttribute, CognitoUserPool} from 'amazon-cognito-identity-js';
import {environment} from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CognitoService {

  private static POOL_INFO = new CognitoUserPool({
    UserPoolId: environment.cognitoUserPoolId,
    ClientId: environment.cognitoClientId
  });

  constructor() {
  }

  signIn(username: string, password: string, newPassword?: string) {
    return new Promise((resolve, reject) => {
      username = username.toLowerCase().trim();
      const authenticationDetails = new AuthenticationDetails({
        Username: username,
        Password: password,
      });

      const cognitoUser = new CognitoUser({
        Username: username,
        Pool: CognitoService.POOL_INFO
      });

      cognitoUser.authenticateUser(authenticationDetails, {
        newPasswordRequired: function (userAttributes, requiredAttributes) {
          cognitoUser.completeNewPasswordChallenge(newPassword, null, {
            onSuccess: function (result) {
              resolve(result);
            },
            onFailure: function (err) {
              reject(err);
            },
          });
        },
        onSuccess: function (result) {
          resolve(result);
        },
        onFailure: function (err) {
          reject(err);
        },
      });
    });
  }

  forgotPassword(username: string) {
    return new Promise((resolve, reject) => {
      const cognitoUser = new CognitoUser({
        Username: username,
        Pool: CognitoService.POOL_INFO
      });

      cognitoUser.forgotPassword({
        onSuccess: function () {
          resolve();
        },
        onFailure: function (err) {
          reject(err);
        }
      });
    });
  }

  confirmPassword(username: string, verificationCode: string, newPassword: string) {
    return new Promise((resolve, reject) => {
      const cognitoUser = new CognitoUser({
        Username: username,
        Pool: CognitoService.POOL_INFO
      });

      cognitoUser.confirmPassword(verificationCode, newPassword, {
        onSuccess: function () {
          resolve();
        },
        onFailure: function (err) {
          reject(err);
        }
      });
    });
  }

  changePassword(username: string, oldPassword: string, newPassword: string) {
    return new Promise((resolve, reject) => {
      const authenticationDetails = new AuthenticationDetails({
        Username: username,
        Password: oldPassword,
      });

      const cognitoUser = new CognitoUser({
        Username: username,
        Pool: CognitoService.POOL_INFO
      });

      cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function () {
          cognitoUser.changePassword(oldPassword, newPassword, (err, result) => {
            if (err) {
              return reject(err);
            }
            resolve(result);
          });
        },
        onFailure: function (err) {
          reject(err);
        },
      });
    });
  }
}
