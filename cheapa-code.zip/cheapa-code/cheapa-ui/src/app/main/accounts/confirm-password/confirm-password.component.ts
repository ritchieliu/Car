import {Component, OnInit} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {FuseConfigService} from '@fuse/services/config.service';
import {fuseAnimations} from '@fuse/animations';
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {locale as english} from "../../../i18n/en";
import {locale as chinese} from "../../../i18n/cn";
import {CognitoService} from "../cognito.service";
import {CustomFormGroup} from "../../common/form/CustomFormGroup";
import {CustomValidators} from "ng2-validation";
import {ActivatedRoute, Router} from "@angular/router";
import {AccountsService} from "../accounts.service";

@Component({
  selector: 'account-confirm-password',
  templateUrl: './confirm-password.component.html',
  styleUrls: ['./confirm-password.component.scss'],
  animations: fuseAnimations
})
export class AccountConfirmPasswordComponent implements OnInit {
  username: string;
  token: string;
  passwordFormControl = new FormControl('', Validators.required);
  form: CustomFormGroup = new CustomFormGroup({
    password: this.passwordFormControl,
    verifyPassword: new FormControl('', [Validators.required, CustomValidators.equalTo(this.passwordFormControl)])
  });

  constructor(private fuseConfig: FuseConfigService,
              private fuseTranslationLoader: FuseTranslationLoaderService,
              private cognitoService: CognitoService,
              private route: ActivatedRoute,
              private router: Router,
              private accountsService: AccountsService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
    this.fuseConfig.setConfig({
      layout: {
        navigation: 'none',
        toolbar: 'none',
        footer: 'none'
      }
    });
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.username = params['id'];
      this.token = params['token'];
    });
  }

  async onSubmit() {
    this.form.submit(async () => {
        await this.cognitoService.confirmPassword(this.username, this.token, this.form.value.password);
      }
    );
  }
}
