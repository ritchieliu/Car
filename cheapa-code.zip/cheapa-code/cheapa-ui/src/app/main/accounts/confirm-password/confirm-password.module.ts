import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AccountConfirmPasswordComponent} from './confirm-password.component';
import {AppSharedModule} from "../../common/appShared.module";

const routes = [
  {
    path: 'confirmPassword',
    component: AccountConfirmPasswordComponent
  }
];

@NgModule({
  declarations: [
    AccountConfirmPasswordComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule
  ]
})
export class ConfirmPasswordModule {
}
