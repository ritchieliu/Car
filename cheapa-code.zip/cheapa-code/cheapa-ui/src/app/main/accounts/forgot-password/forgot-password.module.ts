import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AccountForgotPasswordComponent} from './forgot-password.component';
import {AppSharedModule} from "../../common/appShared.module";

const routes = [
  {
    path: 'forgotPassword',
    component: AccountForgotPasswordComponent
  }
];

@NgModule({
  declarations: [
    AccountForgotPasswordComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule
  ]
})
export class ForgotPasswordModule {
}
