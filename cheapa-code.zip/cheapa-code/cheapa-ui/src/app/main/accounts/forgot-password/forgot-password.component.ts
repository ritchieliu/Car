import {Component} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import {FuseConfigService} from '@fuse/services/config.service';
import {fuseAnimations} from '@fuse/animations';
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {locale as english} from "../../../i18n/en";
import {locale as chinese} from "../../../i18n/cn";
import {CognitoService} from "../cognito.service";
import {CustomFormGroup} from "../../common/form/CustomFormGroup";

@Component({
  selector: 'account-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
  animations: fuseAnimations
})
export class AccountForgotPasswordComponent {
  form: CustomFormGroup = new CustomFormGroup({
    email: new FormControl('', [Validators.required, Validators.email])
  });

  constructor(private fuseConfig: FuseConfigService,
              private fuseTranslationLoader: FuseTranslationLoaderService,
              private cognitoService: CognitoService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
    this.fuseConfig.setConfig({
      layout: {
        navigation: 'none',
        toolbar: 'none',
        footer: 'none'
      }
    });
  }

  async onSubmit() {
    this.form.submit(async () => {
        await this.cognitoService.forgotPassword(this.form.value.email);
      }
    );
  }
}
