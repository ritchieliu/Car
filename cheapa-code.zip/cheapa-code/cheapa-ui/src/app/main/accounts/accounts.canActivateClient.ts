import {Injectable} from '@angular/core';
import {Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot} from '@angular/router';
import {AccountsService} from './accounts.service';
import {AppSharedService} from "../common/appShared.service";

@Injectable({
  providedIn: 'root',
})
export class AccountsCanActivateClient implements CanActivate {

  constructor(private router: Router, private  accountsService: AccountsService, private appSharedService: AppSharedService) {
  }

  canActivate(route: ActivatedRouteSnapshot,
              state: RouterStateSnapshot) {
    if (this.accountsService.hasSignedIn() && !this.accountsService.isAdmin()) {
      return true;
    }

    this.appSharedService.setLocalStorage('targetUrl', state.url);
    window.location.href = '/accounts/login';

    return false;
  }
}
