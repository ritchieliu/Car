import {NgModule} from '@angular/core';

import {LoginModule} from './login/login.module';
import {ForgotPasswordModule} from './forgot-password/forgot-password.module';
import {NewPasswordModule} from "./new-password/new-password.module";
import {ConfirmPasswordModule} from "./confirm-password/confirm-password.module";
import {RegisterModule} from "./register/register.module";

@NgModule({
  imports: [
    // Auth
    LoginModule,
    RegisterModule,
    ForgotPasswordModule,
    NewPasswordModule,
    ConfirmPasswordModule
  ]
})
export class AccountsModule {

}
