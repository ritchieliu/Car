import {Component, Input, OnDestroy, ViewChild, ViewEncapsulation} from '@angular/core';
import {Subscription} from 'rxjs';

import {FusePerfectScrollbarDirective} from '@fuse/directives/fuse-perfect-scrollbar/fuse-perfect-scrollbar.directive';
import {FuseSidebarService} from '@fuse/components/sidebar/sidebar.service';

import {adminNavigation} from 'app/navigation/adminNavigation';
import {FuseNavigationService} from '@fuse/components/navigation/navigation.service';
import {FuseTranslationLoaderService} from "../../../@fuse/services/translation-loader.service";
import {locale as chinese} from "../../i18n/cn";
import {locale as english} from "../../i18n/en";
import {AccountsService} from "../accounts/accounts.service";
import {getClientNavigation} from "app/navigation/clientNavigation";
import {getPartnerNavigation} from "app/navigation/partnerNavigation";

@Component({
  selector: 'fuse-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FuseNavbarComponent implements OnDestroy {
  private fusePerfectScrollbar: FusePerfectScrollbarDirective;

  @ViewChild(FusePerfectScrollbarDirective, {static: true}) set directive(theDirective: FusePerfectScrollbarDirective) {
    if (!theDirective) {
      return;
    }

    this.fusePerfectScrollbar = theDirective;

    this.navigationServiceWatcher =
      this.navigationService.onItemCollapseToggled.subscribe(() => {
        this.fusePerfectScrollbarUpdateTimeout = setTimeout(() => {
          this.fusePerfectScrollbar.update();
        }, 310);
      });
  }

  @Input() layout;
  navigation: any;
  navigationServiceWatcher: Subscription;
  fusePerfectScrollbarUpdateTimeout;

  constructor(private sidebarService: FuseSidebarService,
              private navigationService: FuseNavigationService,
              private fuseTranslationLoader: FuseTranslationLoaderService,
              private accountsService: AccountsService) {

    // Navigation data
    if (accountsService.isAdmin()) {
      this.navigation = adminNavigation;
    } else if (accountsService.isPartner()) {
      this.navigation = getPartnerNavigation(accountsService);
    } else {
      this.navigation = getClientNavigation(accountsService);
    }

    // Default layout
    this.layout = 'vertical';

    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  ngOnDestroy() {
    if (this.fusePerfectScrollbarUpdateTimeout) {
      clearTimeout(this.fusePerfectScrollbarUpdateTimeout);
    }

    if (this.navigationServiceWatcher) {
      this.navigationServiceWatcher.unsubscribe();
    }
  }

  toggleSidebarOpened(key) {
    this.sidebarService.getSidebar(key).toggleOpen();
  }

  toggleSidebarFolded(key) {
    this.sidebarService.getSidebar(key).toggleFold();
  }
}
