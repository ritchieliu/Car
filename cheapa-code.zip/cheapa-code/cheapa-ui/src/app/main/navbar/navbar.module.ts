import { NgModule } from '@angular/core';
import { FuseNavbarComponent } from 'app/main/navbar/navbar.component';
import { FuseNavigationModule } from '@fuse/components';
import {AppSharedModule} from "../common/appShared.module";

@NgModule({
    declarations: [
        FuseNavbarComponent
    ],
    imports     : [
        AppSharedModule,
        FuseNavigationModule
    ],
    exports     : [
        FuseNavbarComponent
    ]
})
export class FuseNavbarModule
{
}
