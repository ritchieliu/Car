import {Component, Inject, OnInit} from '@angular/core';



import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {FormControl} from '@angular/forms';
import {CustomFormGroup} from "app/main/common/form/CustomFormGroup";
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {OrdersService} from "../orders.service";

@Component({
  selector: 'order-charege-dialog',
  templateUrl: './dialog.component.html'
})
export class OrderChargeDialogComponent implements OnInit {
  form: CustomFormGroup;
  instance: any = {
    amount: 0
  };

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<OrderChargeDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private ordersService: OrdersService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.instance = await this.ordersService.getInstance(this.data.accountId, this.data.createdAt);

    this.form = new CustomFormGroup({
    });
  }

  onSubmit() {
    this.form.submit(async () => {
        let result = await this.ordersService.updateStatus(this.data.accountId, this.data.createdAt, 'COMPLETED');
        this.dialogRef.close(result);
      }
    );
  }

  close(): void {
    this.dialogRef.close();
  }
}
