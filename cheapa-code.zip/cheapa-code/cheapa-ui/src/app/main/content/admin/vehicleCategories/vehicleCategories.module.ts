import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AppSharedModule} from "app/main/common/appShared.module";
import {VehicleCategoryListComponent} from "./list/list.component";
import {VehicleCategoryDialogComponent} from "./dialog/dialog.component";
import {AccountsCanActivateAdmin} from "app/main/accounts/accounts.canActivateAdmin";
import {VehicleCategoryImageDialogComponent} from "./imageDialog/imageDialog.component";
import {ImageUploadService} from "../../../common/imageUpload/imageUpload.service";
import {ImageUploadModule} from "angular2-image-upload";
import {Ng2ImgMaxModule} from "ng2-img-max";
import {CKEditorModule} from "@ckeditor/ckeditor5-angular";

const routes = [
  {
    canActivate: [AccountsCanActivateAdmin],
    path: '',
    component: VehicleCategoryListComponent
  }
];

@NgModule({
  declarations: [
    VehicleCategoryListComponent,
    VehicleCategoryDialogComponent,
    VehicleCategoryImageDialogComponent,
  ],
  entryComponents: [
    VehicleCategoryDialogComponent,
    VehicleCategoryImageDialogComponent
  ],
  providers: [
    ImageUploadService
  ],
  imports: [
    RouterModule.forChild(routes),
    ImageUploadModule.forRoot(),
    Ng2ImgMaxModule,
    AppSharedModule,
    CKEditorModule
  ],
  exports: [
    VehicleCategoryListComponent,
    VehicleCategoryDialogComponent
  ]
})

export class VehicleCategoryesModule {
}
