import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AppSharedModule} from "app/main/common/appShared.module";
import {OrderListComponent} from "./list/list.component";
import {OrderDialogComponent} from "./dialog/dialog.component";
import {AccountsCanActivateAdmin} from "app/main/accounts/accounts.canActivateAdmin";
import {OrderChargeDialogComponent} from "./chargeDialog/dialog.component";
import {OrderInstanceComponent} from "./instance/instance.component";
import {AgmCoreModule} from "@agm/core";
import {environment} from "../../../../../environments/environment";
import {CalendarModule, DateAdapter} from "angular-calendar";
import {adapterFactory} from "angular-calendar/date-adapters/date-fns";
import {AccountsCanActivatePartner} from "../../../accounts/accounts.canActivatePartner";

const routes = [
  {
    canActivate: [AccountsCanActivatePartner],
    path: '',
    component: OrderListComponent
  },
  {
    canActivate: [AccountsCanActivateAdmin],
    path: ':createdAt',
    component: OrderInstanceComponent
  }
];

@NgModule({
  declarations: [
    OrderListComponent,
    OrderDialogComponent,
    OrderChargeDialogComponent,
    OrderInstanceComponent,
  ],
  entryComponents: [
    OrderDialogComponent,
    OrderChargeDialogComponent
  ],
  providers: [],
  imports: [
    RouterModule.forChild(routes),
    AgmCoreModule.forRoot({
      apiKey: environment.googleApiKey
    }),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),
    AppSharedModule
  ],
  exports: [
    OrderListComponent,
    OrderDialogComponent,
    OrderChargeDialogComponent,
    OrderInstanceComponent,
  ]
})

export class OrdersModule {
}
