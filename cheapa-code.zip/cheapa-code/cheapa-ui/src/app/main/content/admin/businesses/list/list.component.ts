import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {DatatableComponent} from "@swimlane/ngx-datatable";
import {ListModel} from "app/main/common/list/ListModel";
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {BusinessesService} from "../businesses.service";
import {MatDialog, MatDialogConfig} from "@angular/material";
import {BusinessDialogComponent} from "../dialog/dialog.component";

@Component({
  selector: 'business-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  animations: fuseAnimations
})
export class BusinessListComponent implements OnInit {
  @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
  list: ListModel;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private businessesService: BusinessesService,
              private dialog: MatDialog) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  ngOnInit() {
    this.list = new ListModel(this.table, 'id,name,email,country,currency,routing_number,account_number,mobile', ['name', 'email', 'mobile']);
    this.getList('');
  }

  getList(listStartKey) {
    this.list.getList(async () => {
        return await this.businessesService.list(this.list.attributes, this.list.pageSize, listStartKey);
      }
    );
  }

  openDialog(id?) {
    const dialogRef = this.dialog.open(BusinessDialogComponent, <MatDialogConfig>{
      width: '300px',
      data: {id}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getList('');
      }
    });
  }
}
