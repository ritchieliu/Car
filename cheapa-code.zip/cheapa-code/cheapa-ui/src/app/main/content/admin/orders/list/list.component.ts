import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {DatatableComponent} from "@swimlane/ngx-datatable";
import {ListModel} from "app/main/common/list/ListModel";
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {OrdersService} from "../orders.service";
import {MatDialog, MatDialogConfig} from "@angular/material";
import {OrderDialogComponent} from "../dialog/dialog.component";
import {OrderChargeDialogComponent} from "../chargeDialog/dialog.component";
import {AccountsService} from "../../../../accounts/accounts.service";
import {BusinessesService} from "../../businesses/businesses.service";

@Component({
  selector: 'order-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  animations: fuseAnimations
})
export class OrderListComponent implements OnInit {
  @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
  list: ListModel;
  businessInstance;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private ordersService: OrdersService,
              public accountsService: AccountsService,
              private businessesService: BusinessesService,
              private dialog: MatDialog) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.list = new ListModel(this.table, 'accountId,vehicleId,email,createdAt,pickUpDate,dropOffDate,payment,status,businessPartnerId,vehicleCategoryName', ['createdAt', 'vehicleId', 'pickUpDate', 'dropOffDate', 'email', 'status']);
    this.getList('');

    if (this.accountsService.isPartner()) {
      this.businessInstance = await this.businessesService.getInstance("partner_id");
    }
  }

  getList(listStartKey) {
    this.list.getList(async () => {
        return await this.ordersService.list(this.list.attributes, this.list.pageSize, listStartKey);
      }
    );
  }

  openOrderDialog(id?) {
    const dialogRef = this.dialog.open(OrderDialogComponent, <MatDialogConfig>{
      width: '300px',
      data: {id}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getList('');
      }
    });
  }

  async updateStatus(accountId, createdAt, status) {
    await this.ordersService.updateStatus(accountId, createdAt, status);
    await this.getList('');
  }

  openOrderChargeDialog(accountId, createdAt) {
    const dialogRef = this.dialog.open(OrderChargeDialogComponent, <MatDialogConfig>{
      width: '300px',
      data: {accountId, createdAt}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getList('');
      }
    });
  }
}
