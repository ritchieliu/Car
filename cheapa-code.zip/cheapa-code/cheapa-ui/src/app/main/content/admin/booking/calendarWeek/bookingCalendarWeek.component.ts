import {Component, EventEmitter, Input, Output} from '@angular/core';
import {CalendarUtils, CalendarWeekViewComponent} from "angular-calendar";

@Component({
  selector: 'booking-calendar-week',
  providers: [
    {
      provide: CalendarUtils,
      useClass: CalendarUtils
    }
  ],
  templateUrl: 'bookingCalendarWeek.component.html'
})
export class BookingCalendarWeekComponent extends CalendarWeekViewComponent {
  @Input()
  vehicles:any = {};

  @Input()
  vehicleCategory:any = {};

  @Output()
  categoryClicked = new EventEmitter<any>();

  @Output()
  dayClicked = new EventEmitter<any>();

  vehiclesInCategory = [];

  ngOnInit(): void {
    super.ngOnInit();
    this.vehiclesInCategory = this.vehicles.Items.filter(vehicle => vehicle.vehicleCategoryId === this.vehicleCategory.id)
  }

  clickCategory(vehicleCategory) {
    this.categoryClicked.emit({vehicleCategory});
  }

  clickDay(day, vehicle) {
    this.dayClicked.emit({day, vehicle});
  }
}
