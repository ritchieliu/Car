import {Injectable} from '@angular/core';
import * as moment from "moment";

@Injectable({
  providedIn: 'root',
})
export class BookingFeeService {

  ORDER_HOURS = Array(24).fill(0).map((x, i) => i);
  ORDER_MINUTES = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];

  AGE_RENTAL = 10;
  ROADSIDE_ASSISTANT = 5.5;
  ADDITIONAL_DRIVER = 5;
  CHILD_SEAT_SMALL = 10;
  CHILD_SEAT_LARGE = 10;
  GPS = 5;
  MOBILE_PHONE_HOLDER = 1;
  TYRE_WINDSCREEN_COVER = 5.5;
  UNLIMITED_DISTANCE = 20;

  INSURANCES: any = [
    {
      type: 'PREMIUM',
      name: 'Premium Cover',
      price: 19,
      bond: 200,
      help: 'Reduce my damage liability fee (DLF)/ Excess to AUD $200'
    },
    {
      type: 'STANDARD',
      name: 'Standard Cover',
      price: 9,
      bond: 800,
      help: 'Reduce my damage liability fee (DLF)/ Excess to AUD $800'
    },
    {
      type: 'BASIC',
      name: 'Basic Cover',
      price: 0,
      bond: 3300,
      help: 'Reduce my damage liability fee (DLF)/ Excess to AUD $3300'
    }
  ];

  LOCATIONS = [
    {
      name: 'NSW - Greenacre',
      city: 'Sydney',
      dropOffCities: [
        {city: 'Sydney', price: 0},
        {city: 'Melbourne', price: 410},
        {city: 'Gold Coast', price: 450},
      ]
    },
    {
      name: 'NSW - Sydney Airport',
      city: 'Sydney',
      dropOffCities: [
        {city: 'Sydney', price: 0},
        {city: 'Melbourne', price: 410},
        {city: 'Gold Coast', price: 450},
      ]
    },
    {
      name: 'NSW - Carlingford',
      city: 'Sydney',
      dropOffCities: [
        {city: 'Sydney', price: 0},
        {city: 'Melbourne', price: 410},
        {city: 'Gold Coast', price: 450},
      ]
    },
    {
      name: 'QLD - Gold Coast Airport',
      city: 'Gold Coast',
      dropOffCities: [
        {city: 'Sydney', price: 450},
        {city: 'Melbourne', price: 530},
        {city: 'Gold Coast', price: 0},
      ]
    },
    {
      name: 'QLD - Gold Coast City',
      city: 'Gold Coast',
      dropOffCities: [
        {city: 'Sydney', price: 450},
        {city: 'Melbourne', price: 530},
        {city: 'Gold Coast', price: 0},
      ]
    },
    {
      name: 'VIC - Melbourne Boxing Hill',
      city: 'Melbourne',
      dropOffCities: [
        {city: 'Sydney', price: 410},
        {city: 'Melbourne', price: 0},
        {city: 'Gold Coast', price: 530},
      ]
    },
    {
      name: 'VIC - Melbourne City',
      city: 'Melbourne',
      dropOffCities: [
        {city: 'Sydney', price: 410},
        {city: 'Melbourne', price: 0},
        {city: 'Gold Coast', price: 530},
      ]
    },
    {
      name: 'VIC - Melbourne Airport',
      city: 'Melbourne',
      dropOffCities: [
        {city: 'Sydney', price: 410},
        {city: 'Melbourne', price: 0},
        {city: 'Gold Coast', price: 530},
      ]
    }
  ];

  constructor() {
  }

  calculateRentDays({pickUpDate, dropOffDate}) {
    let rentHours = Math.round(moment.duration(dropOffDate.diff(pickUpDate)).asHours());

    if (rentHours <= 25) {
      return 1;
    }

    let day = Math.floor(rentHours / 24);

    if (rentHours % 24 === 0) {
    } else if (rentHours % 24 <= 4) {
      day += 0.5;
    } else {
      day += 1;
    }

    return day;
  }

  calculateRentPricePerDay({pickUpDate, dropOffDate, pricing}) {
    let rentDays = this.calculateRentDays({pickUpDate, dropOffDate});
    let pricingItem = pricing.common.find(item => item.day === Math.floor(rentDays));
    if (!pricingItem) {
      pricingItem = pricing.common[pricing.common.length - 1]
    }
    return pricingItem.price;
  }

  calculateRental({pickUpDate, dropOffDate, rentPricePerDay}) {
    let rentDays = this.calculateRentDays({pickUpDate, dropOffDate});
    return rentPricePerDay * rentDays;
  }

  calculateYoungDriverCharge({pickUpDate, dropOffDate, driverAge}) {
    let rentDays = this.calculateRentDays({pickUpDate, dropOffDate});
    if (driverAge) {
      return this.AGE_RENTAL * rentDays;
    }
    return 0;
  }

  calculateChargeByType({pickUpDate, dropOffDate, type, applied}) {
    let rentDays = this.calculateRentDays({pickUpDate, dropOffDate});
    if (!applied) {
      return 0;
    }
    switch (type) {
      case 'AGE_RENTAL_PRICE':
        return this.AGE_RENTAL * rentDays;
      case 'ROADSIDE_ASSISTANT':
        return this.ROADSIDE_ASSISTANT * rentDays;
      case 'ADDITIONAL_DRIVER':
        return this.ADDITIONAL_DRIVER * rentDays;
      case 'CHILD_SEAT_SMALL':
        return this.CHILD_SEAT_SMALL * rentDays;
      case 'CHILD_SEAT_LARGE':
        return this.CHILD_SEAT_LARGE * rentDays;
      case 'GPS':
        return this.GPS * rentDays;
      case 'MOBILE_PHONE_HOLDER':
        return this.MOBILE_PHONE_HOLDER * rentDays;
      case 'TYRE_WINDSCREEN_COVER':
        return this.TYRE_WINDSCREEN_COVER * rentDays;
      case 'UNLIMITED_DISTANCE':
        return this.UNLIMITED_DISTANCE * rentDays;
    }
    return 0;
  }

  calculateInsuranceObject({pickUpDate, dropOffDate, insurance, insuranceApplied}) {
    let rentDays = this.calculateRentDays({pickUpDate, dropOffDate});
    let pricingItem = insurance.find(item => item.day === Math.floor(rentDays));
    if (!pricingItem) {
      pricingItem = insurance[insurance.length - 1]
    }

    if (insuranceApplied) {
      return pricingItem;
    } else {
      return {
        price: 0,
        bond: pricingItem.maxBond
      };
    }
  }

  calculateInsurance({pickUpDate, dropOffDate, insurance}) {
    let rentDays = this.calculateRentDays({pickUpDate, dropOffDate});
    return insurance.price * rentDays;
  }

  calculateTotalBond({insurance}) {
    return insurance.bond;
  }

  calculateTotalPrice({
                        pickUpDate, dropOffDate, rentPricePerDay, driverAge, insurance, pickUpLocation, dropOffLocation,
                        roadSideAssistant, additionalDriver, childSeatSmall, childSeatLarge, gps, mobilePhoneHolder, tyreWindscreenCover, unlimitedDistance
                      }) {
    let rental = this.calculateRental({pickUpDate, dropOffDate, rentPricePerDay});
    let insuranceCharge = this.calculateInsurance({pickUpDate, dropOffDate, insurance});
    let dropOffCharge = this.calculateDropOffPrice({pickUpLocation, dropOffLocation});
    let youngDriverCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'AGE_RENTAL_PRICE', applied: driverAge} as any);
    let extraCharge = this.calculateExtra({pickUpDate, dropOffDate, roadSideAssistant, additionalDriver, childSeatSmall, childSeatLarge, gps, mobilePhoneHolder, tyreWindscreenCover, unlimitedDistance});

    return rental + insuranceCharge + dropOffCharge + youngDriverCharge + extraCharge;
  }

  calculateExtra({pickUpDate, dropOffDate, roadSideAssistant, additionalDriver, childSeatSmall, childSeatLarge, gps, mobilePhoneHolder, tyreWindscreenCover, unlimitedDistance}) {
    let roadSideAssistantCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'ROADSIDE_ASSISTANT', applied: roadSideAssistant} as any);
    let additionalDriverCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'ADDITIONAL_DRIVER', applied: additionalDriver} as any);
    let childSeatSmallCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'CHILD_SEAT_SMALL', applied: childSeatSmall} as any);
    let childSeatLargeCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'CHILD_SEAT_LARGE', applied: childSeatLarge} as any);
    let gpsCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'GPS', applied: gps} as any);
    let mobilePhoneHolderCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'MOBILE_PHONE_HOLDER', applied: mobilePhoneHolder} as any);
    let tyreWindScreenCoverCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'TYRE_WINDSCREEN_COVER', applied: tyreWindscreenCover} as any);
    let unlimitedDistanceCharge = this.calculateChargeByType({pickUpDate, dropOffDate, type: 'UNLIMITED_DISTANCE', applied: unlimitedDistance} as any);

    return roadSideAssistantCharge + additionalDriverCharge + childSeatSmallCharge
      + childSeatLargeCharge + gpsCharge + mobilePhoneHolderCharge + tyreWindScreenCoverCharge + unlimitedDistanceCharge;
  }

  calculateCreditCardCharge({
                              pickUpDate, dropOffDate, rentPricePerDay, driverAge, insurance, discount, pickUpLocation, dropOffLocation,
                              roadSideAssistant, additionalDriver, childSeatSmall, childSeatLarge, gps, mobilePhoneHolder, tyreWindscreenCover, unlimitedDistance
                            }) {
    return this.calculateTotalPriceWithTax({
      pickUpDate, dropOffDate, rentPricePerDay, driverAge, insurance, discount, pickUpLocation, dropOffLocation,
      roadSideAssistant, additionalDriver, childSeatSmall, childSeatLarge, gps, mobilePhoneHolder, tyreWindscreenCover, unlimitedDistance
    }) + this.calculateTotalBond({insurance});
  }

  calculateTotalPriceWithTax({
                               pickUpDate, dropOffDate, rentPricePerDay, driverAge, insurance, discount, pickUpLocation, dropOffLocation,
                               roadSideAssistant, additionalDriver, childSeatSmall, childSeatLarge, gps, mobilePhoneHolder, tyreWindscreenCover, unlimitedDistance
                             }) {
    return this.calculateTotalPrice({
      pickUpDate, dropOffDate, rentPricePerDay, driverAge, insurance, pickUpLocation, dropOffLocation,
      roadSideAssistant, additionalDriver, childSeatSmall, childSeatLarge, gps, mobilePhoneHolder, tyreWindscreenCover, unlimitedDistance
    }) - discount;
  }

  getDropOffLocation(location) {
    let cities: any = location.dropOffCities.map(item => item.city);
    return this.LOCATIONS.filter(item => cities.includes(item.city));
  }

  calculateDropOffPrice({pickUpLocation, dropOffLocation}) {
    return pickUpLocation.dropOffCities.find(item => item.city === dropOffLocation.city).price
  }
}
