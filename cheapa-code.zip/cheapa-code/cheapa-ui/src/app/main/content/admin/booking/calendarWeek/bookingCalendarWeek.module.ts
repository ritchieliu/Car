import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CalendarDateFormatter, CalendarModule, CalendarMomentDateFormatter, DateAdapter, MOMENT} from 'angular-calendar';
import {adapterFactory} from 'angular-calendar/date-adapters/moment';
import {BookingCalendarWeekComponent} from "./bookingCalendarWeek.component";
import * as moment from "moment";
import {AppSharedModule} from "../../../../common/appShared.module";

export function momentAdapterFactory() {
  return adapterFactory(moment);
}

@NgModule({
  imports: [
    CommonModule,
    AppSharedModule,
    CalendarModule.forRoot({
        provide: DateAdapter,
        useFactory: momentAdapterFactory
      },
      {
        dateFormatter: {
          provide: CalendarDateFormatter,
          useClass: CalendarMomentDateFormatter
        }
      }),
  ],
  declarations: [BookingCalendarWeekComponent],
  exports: [BookingCalendarWeekComponent],
  providers: [
    {
      provide: MOMENT,
      useValue: moment
    }
  ]
})
export class BookingCalenderWeekModule {
}
