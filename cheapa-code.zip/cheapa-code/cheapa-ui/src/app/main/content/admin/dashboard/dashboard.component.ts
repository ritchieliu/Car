import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {VehiclesService} from "../vehicles/vehicles.service";
import {VehicleActionsService} from "../vehicles/vehicles.action.service";
import {AccountsService} from "../../../accounts/accounts.service";

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: fuseAnimations
})
export class DashboardComponent implements OnInit {
  vehicleList: any = [];
  markers: any = [];
  filteredMarkers: any = [];
  cities: any = [
    {
      name: 'Sydney',
      longitude: 151.2093,
      latitude: -33.8688,
      zoom: 11
    },
    {
      name: 'Melbourne',
      longitude: 144.9631,
      latitude: -37.8136,
      zoom: 11
    },
    {
      name: 'Brisbane',
      longitude: 153.02809,
      latitude: -27.46794,
      zoom: 11
    },
    {
      name: 'Gold Coast',
      longitude: 153.43088,
      latitude: -28.00029,
      zoom: 11
    },
    {
      name: 'Perth',
      longitude: 115.85704,
      latitude: -31.95351,
      zoom: 11
    }];
  selectedCity: any = this.cities[0];
  operationStatuses = ['AVAILABLE', 'IN_USE', 'MAINTAIN'];
  selectedOperationStatus: any = '';
  mapCenter: any = {
    latitude: this.selectedCity.latitude,
    longitude: this.selectedCity.longitude,
    zoom: this.selectedCity.zoom,
  };
  isLoading;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private vehiclesService: VehiclesService,
              public vehicleActionsService: VehicleActionsService,
              public accountsService: AccountsService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    await this.getVehicleList();
  }

  async getVehicleList() {
    this.isLoading = true;
    if (this.accountsService.isAdmin()) {
      this.vehicleList = await this.vehiclesService.list('id,location,make,model,color,seatNumber,rentPricePerDay,currency,deviceId,operationStatus,images', '', '', {hasLocation: true});
    } else if (this.accountsService.isPartner()) {
      this.vehicleList = await this.vehiclesService.list('id,location,make,model,color,seatNumber,rentPricePerDay,currency,deviceId,operationStatus,images,accountId', '', '', {hasLocation: true, accountId: this.accountsService.getUser().id});
    }
    this.markers = this.vehicleList.Items;
    this.filteredMarkers = this.markers;
    this.isLoading = false;
  }

  async onDeviceActionOpenDoor(marker) {
    marker.openDoorButtonSubmitting = true;
    await this.vehicleActionsService.openDoor(marker);
    marker.openDoorButtonSubmitting = false;
  }

  async onDeviceActionCloseDoor(marker) {
    marker.closeDoorButtonSubmitting = true;
    await this.vehicleActionsService.closeDoor(marker);
    marker.closeDoorButtonSubmitting = false;
  }

  selectCity(city) {
    this.selectedCity = city;
    this.setMapCenter(city.latitude, city.longitude, city.zoom);
  }

  selectOperationStatus(status?) {
    this.selectedOperationStatus = status;
    if (!status) {
      this.filteredMarkers = this.markers;
    } else {
      this.filteredMarkers = this.markers.filter(marker => marker.operationStatus === status);
    }
  }

  filterVehicle(event) {
    let val = event.target.value;
    this.filteredMarkers = this.markers.filter(marker =>
      marker.id.toLowerCase().includes(val.toLowerCase()));

    if (this.filteredMarkers.length === 1) {
      this.setMapCenter(this.filteredMarkers[0].location.latitude, this.filteredMarkers[0].location.longitude);
    }
  }

  setMapCenter(latitude, longitude, zoom = 11) {
    this.mapCenter = {
      latitude,
      longitude,
      zoom
    }
  }

  setMarkerContent(marker) {
    marker.opened = true;
  }
}
