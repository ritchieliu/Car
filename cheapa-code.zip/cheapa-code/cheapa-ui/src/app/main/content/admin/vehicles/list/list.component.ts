import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {DatatableComponent} from "@swimlane/ngx-datatable";
import {ListModel} from "app/main/common/list/ListModel";
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {VehiclesService} from "../vehicles.service";
import {MatDialog, MatDialogConfig} from "@angular/material";
import {VehicleDialogComponent} from "../dialog/dialog.component";
import {VehicleActionsService} from "../vehicles.action.service";
import {VehicleImageDialogComponent} from "../imageDialog/imageDialog.component";
import {AccountsService} from "../../../../accounts/accounts.service";

@Component({
  selector: 'vehicle-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  animations: fuseAnimations
})
export class VehicleListComponent implements OnInit {
  @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
  list: ListModel;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private vehiclesService: VehiclesService,
              public vehicleActionsService: VehicleActionsService,
              public accountsService: AccountsService,
              private dialog: MatDialog) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  ngOnInit() {
    this.list = new ListModel(this.table, 'id,make,model,seatNumber,rentPricePerDay,currency,location,deviceId,operationStatus,images,deviceStatus,accountId,distance', ['id', 'make', 'model', 'make', 'deviceId', 'rentPricePerDay', 'operationStatus', 'vehicleCategoryName']);
    this.getList('');
  }

  getList(listStartKey) {
    this.list.getList(async () => {
        if (this.accountsService.isAdmin()) {
          return await this.vehiclesService.list(this.list.attributes, this.list.pageSize, listStartKey);
        } else if (this.accountsService.isPartner()) {
          return await this.vehiclesService.list(this.list.attributes, this.list.pageSize, listStartKey, {accountId: this.accountsService.getUser().id});
        }
      }
    );
  }

  openVehicleDialog(id?) {
    const dialogRef = this.dialog.open(VehicleDialogComponent, <MatDialogConfig>{
      width: '300px',
      data: {id}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getList('');
      }
    });
  }

  openVehicleImageDialog(id) {
    const dialogRef = this.dialog.open(VehicleImageDialogComponent, <MatDialogConfig>{
      data: {id}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getList('');
      }
    });
  }
}
