import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {DatatableComponent} from "@swimlane/ngx-datatable";
import {ListModel} from "app/main/common/list/ListModel";
import {DevicesService} from "../devices.service";
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {MatDialog, MatDialogConfig} from "@angular/material";
import {DeviceDialogComponent} from "../dialog/dialog.component";

@Component({
  selector: 'device-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  animations: fuseAnimations
})
export class DeviceListComponent implements OnInit {
  @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
  list: ListModel;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private devicesService: DevicesService,
              private dialog: MatDialog) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  ngOnInit() {
    this.list = new ListModel(this.table, 'id,vehicleId,type,password,mobile,mobileExpireDate,comment', ['id', 'vehicleId', 'mobile','type']);
    this.getList('');
  }

  getList(listStartKey) {
    this.list.getList(async () => {
        return await this.devicesService.list(this.list.attributes, this.list.pageSize, listStartKey);
      }
    );
  }

  openDeviceDialog(id?) {
    const dialogRef = this.dialog.open(DeviceDialogComponent, <MatDialogConfig>{
      width: '300px',
      data: {id}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getList('');
      }
    });
  }
}
