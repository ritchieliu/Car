import {Component, Inject, OnInit} from '@angular/core';



import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {ActivatedRoute, Router} from '@angular/router';
import {FormControl} from '@angular/forms';
import {DevicesService} from "../devices.service";
import {CustomFormGroup} from "app/main/common/form/CustomFormGroup";
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {VehiclesService} from "../../vehicles/vehicles.service";

@Component({
  selector: 'device-dialog',
  templateUrl: './dialog.component.html'
})
export class DeviceDialogComponent implements OnInit {
  isNew = false;
  isUpdate = false;
  form: CustomFormGroup;
  instance: any = {
    id: '',
    password: '',
    mobile: '',
    mobileExpireDate: '',
    vehicleId: '',
    comment: '',
    type: 'h6_2',
  };
  vehicleList: any = [];

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<DeviceDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private devicesService: DevicesService,
              private vehiclesService: VehiclesService,
              private router: Router,
              private route: ActivatedRoute) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      if (!this.data.id) {
        this.isNew = true;
      } else {
        this.isUpdate = true;
      }
    });

    if (!this.isNew) {
      this.instance = await this.devicesService.getInstance(this.data.id);
    }

    await this.getVehicleList();

    this.form = new CustomFormGroup({
      id: new FormControl(this.instance.id),
      password: new FormControl(this.instance.password),
      mobile: new FormControl(this.instance.mobile),
      mobileExpireDate: new FormControl(this.instance.mobileExpireDate),
      vehicleId: new FormControl(this.instance.vehicleId),
      type: new FormControl(this.instance.type),
      comment: new FormControl(this.instance.comment)
    });
  }

  async getVehicleList() {
    this.vehicleList = await this.vehiclesService.list('id', '', '');
  }

  onSubmit() {
    this.form.submit(async () => {
        let result;
        if (this.isNew) {
          // Prefix id with 000
          if (this.form.value.type === 'linghang' && !this.form.value.id.startsWith('000')) {
            this.form.value.id = '000' + this.form.value.id;
          }
          if ((this.form.value.type === 'h6' || this.form.value.type === 'h6_2') && !this.form.value.id.startsWith('0')) {
            this.form.value.id = '0' + this.form.value.id;
          }
          result = await this.devicesService.create(this.form.value);
        } else {
          result = await this.devicesService.update(this.data.id, this.form.value);
        }
        this.dialogRef.close(result);
      }
    );
  }

  close(): void {
    this.dialogRef.close();
  }
}
