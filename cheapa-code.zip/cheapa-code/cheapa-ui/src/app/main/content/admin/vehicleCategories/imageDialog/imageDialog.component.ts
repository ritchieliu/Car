import {Component, Inject, OnInit} from '@angular/core';


import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {ImageUploadService} from "../../../../common/imageUpload/imageUpload.service";
import {VehicleCategoriesService} from "../vehicleCategories.service";

@Component({
  selector: 'vehicleCategory-image-dialog',
  templateUrl: './imageDialog.component.html'
})
export class VehicleCategoryImageDialogComponent implements OnInit {

  instance: any;


  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<VehicleCategoryImageDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              public vehicleCategoriesService: VehicleCategoriesService,
              public imageUploadService: ImageUploadService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.instance = await this.vehicleCategoriesService.getInstance(this.data.id);
    this.imageUploadService.initUploadedFiles(this.instance.images)
  }

  getImageUploadRequest() {
    return (result) => {
      return this.vehicleCategoriesService.createImage(this.instance.id, {body: result});
    }
  }
}
