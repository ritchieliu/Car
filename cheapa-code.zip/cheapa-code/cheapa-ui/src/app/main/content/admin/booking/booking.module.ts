import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AppSharedModule} from "app/main/common/appShared.module";
import {AccountsCanActivateAdmin} from "app/main/accounts/accounts.canActivateAdmin";
import {CalendarModule, DateAdapter} from "angular-calendar";
import {adapterFactory} from "angular-calendar/date-adapters/date-fns";
import {BookingComponent} from "./booking.component";
import {BookingCalenderWeekModule} from "./calendarWeek/bookingCalendarWeek.module";
import {AdminBookingDialogComponent} from "./dialog/dialog.component";
import {ImageUploadService} from "../../../common/imageUpload/imageUpload.service";
import {Ng2ImgMaxModule, Ng2ImgMaxService} from "ng2-img-max";
import {ImageUploadModule} from "angular2-image-upload";

const routes = [
  {
    canActivate: [AccountsCanActivateAdmin],
    path: '',
    component: BookingComponent
  }
];

@NgModule({
  declarations: [
    BookingComponent,
    AdminBookingDialogComponent
  ],
  entryComponents: [
    AdminBookingDialogComponent
  ],
  providers: [
    ImageUploadService,
    Ng2ImgMaxService
  ],
  imports: [
    RouterModule.forChild(routes),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),
    BookingCalenderWeekModule,
    ImageUploadModule.forRoot(),
    Ng2ImgMaxModule,
    AppSharedModule
  ],
  exports: [
    BookingComponent,
  ]
})

export class BookingModule {
}
