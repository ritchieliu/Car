import {Injectable} from '@angular/core';
import {environment} from 'environments/environment';
import {AccountsService} from 'app/main/accounts/accounts.service';

@Injectable({
  providedIn: 'root',
})
export class OrdersService {

  baseApiURL = `${environment.apiBaseURL}/orders`;

  constructor(private accountsService: AccountsService) {
  }

  list(express, limit, startKey, q?) {
    return this.accountsService.request('get', this.baseApiURL, {
      params: {
        express,
        limit,
        startKey,
        descending: q ? q.descending : ''
      }
    });
  }

  getInstance(accountId, createdAt) {
    return this.accountsService.request('get', `${this.baseApiURL}/${createdAt}?accountId=${accountId}`);
  }

  create(data) {
    return this.accountsService.request('post', this.baseApiURL, {
      body: data
    });
  }

  booking(data) {
    return this.accountsService.request('post', `${this.baseApiURL}/booking`, {
      body: data
    });
  }

  createVehicleImage(accountId, createdAt, data) {
    return this.accountsService.request('post', `${this.baseApiURL}/${createdAt}/vehicleImages`, {
      params: {
        accountId: accountId
      },
      body: data
    });
  }

  deleteVehicleImage(accountId, createdAt, type) {
    return this.accountsService.request('delete', `${this.baseApiURL}/${createdAt}/vehicleImages`, {
      params: {
        accountId: accountId,
        type: type
      }
    });
  }

  createSignature(accountId, createdAt, data) {
    return this.accountsService.request('post', `${this.baseApiURL}/${createdAt}/signature`, {
      params: {
        accountId: accountId
      },
      body: data
    });
  }

  createDriverLicense(accountId, createdAt, data) {
    return this.accountsService.request('post', `${this.baseApiURL}/${createdAt}/driverLicenses`, {
      params: {
        accountId: accountId
      },
      body: data
    });
  }

  deleteDriverLicense(accountId, createdAt, key) {
    return this.accountsService.request('delete', `${this.baseApiURL}/${createdAt}/driverLicenses`, {
      params: {
        accountId: accountId,
        key: key
      }
    });
  }

  sendOrderConfirmEmail(accountId, createdAt) {
    return this.accountsService.request('post', `${this.baseApiURL}/${createdAt}/confirmEmail`, {
      params: {
        accountId: accountId
      }
    });
  }

  confirmReturn(createdAt, data) {
    return this.accountsService.request('post', `${this.baseApiURL}/${createdAt}/return`, {
      body: data
    });
  }

  update({accountId, createdAt}, data) {
    return this.accountsService.request('put', `${this.baseApiURL}/${createdAt}?accountId=${accountId}`, {
      body: data
    });
  }

  updateStatus(accountId, createdAt, status) {
    return this.accountsService.request('post', `${this.baseApiURL}/status`, {
      body: {
        accountId,
        createdAt,
        status,
      }
    });
  }
}
