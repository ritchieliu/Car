import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {MatDialog, MatDialogConfig} from "@angular/material";
import * as moment from "moment";
import {OrdersService} from "../orders/orders.service";
import {VehiclesService} from "../vehicles/vehicles.service";
import {AdminBookingDialogComponent} from "./dialog/dialog.component";
import {Subject} from "rxjs/Rx";
import {VehicleCategoriesService} from "../vehicleCategories/vehicleCategories.service";

@Component({
  selector: 'booking-calendar',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss'],
  animations: fuseAnimations
})
export class BookingComponent implements OnInit {
  colors: any = {
    CANCELLED: {
      primary: '#ad2121',
      secondary: '#FAE3E3'
    },
    RESERVED: {
      primary: '#1e90ff',
      secondary: '#D1E8FF'
    },
    VEHICLE_RETURNED: {
      primary: '#e3bc08',
      secondary: '#FDF1BA'
    },
    ACTIVE: {
      primary: '#39a139',
      secondary: '#81fd83'
    },
    COMPLETED: {
      primary: '#545441',
      secondary: '#969799'
    }
  };

  vehicleList;
  vehicleCategoryList;
  filteredVehicleList;
  orderList;
  filteredOrderList;
  unallocatedOrderList;

  viewDate = moment();
  selectedDay: any;
  refresh: Subject<any> = new Subject();

  reservationCheck:boolean = true;
  activeCheck:boolean = true;
  returnCheck:boolean = true;
  completeCheck:boolean = true;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private ordersService: OrdersService,
              private vehiclesService: VehiclesService,
              private vehicleCategoriesService: VehicleCategoriesService,
              private dialog: MatDialog) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.getOrders();
    let [vehicleList, vehicleCategoryList] = await Promise.all([
      this.getVehicles(),
      this.vehicleCategoriesService.list('id,name,rentPricePerDay,currency,location', '', '', {isForRent: true, hasInsurance: true, hasPricing: true})
    ]);
    this.vehicleList = vehicleList;
    this.vehicleCategoryList = vehicleCategoryList;
    this.filteredVehicleList = {...this.vehicleList};
    this.selectedDay = {date: moment()};
  }

  async getOrders() {
    let orders: any = await this.ordersService.list('accountId,vehicleId,email,firstName,lastName,mobile,createdAt,pickUpDate,dropOffDate,payment,status,source,vehicleCategoryId,vehicleCategoryName', null, '');
    this.orderList = orders.Items.map(item => {
      let pickUpDate = moment.utc(item.pickUpDate).local().toDate();
      let dropOffDate = moment.utc(item.dropOffDate).local().toDate();
      return {
        start: pickUpDate,
        end: dropOffDate,
        title: `${item.email ? item.email : ''}${item.firstName || item.lastName? ' - ' + item.firstName + ' ' + item.lastName : ''}${item.mobile ? ' - ' + item.mobile : ''}${item.source ? ' - ' + item.source : ''}`,
        color: this.colors[item.status],
        allDay: true,
        meta: item
      };
    });
    this.unallocatedOrderList = orders.Items.filter(item => !item.vehicleId && item.status === 'RESERVED');
    this.filterOrder();
  }

  async getVehicles() {
    return this.vehiclesService.list('id,make,model,seatNumber,rentPricePerDay,currency,location,deviceId,operationStatus,images,deviceStatus,vehicleCategoryId,vehicleCategoryName', null, '');
  }

  showOrder(event) {
    const dialogRef = this.dialog.open(AdminBookingDialogComponent, <MatDialogConfig>{
      width: '95%',
      maxWidth: '100%',
      height: '95%',
      data: Object.assign(event.event.meta, {vehicleList: this.vehicleList, vehicleCategoryList: this.vehicleCategoryList})
    });

    dialogRef.afterClosed().subscribe(async result => {
      if (result) {
        await this.getOrders();
      }
    });
  }

  addOrder(event) {
    const dialogRef = this.dialog.open(AdminBookingDialogComponent, <MatDialogConfig>{
      width: '95%',
      maxWidth: '100%',
      height: '95%',
      data: Object.assign(event, {vehicleList: this.vehicleList, vehicleCategoryList: this.vehicleCategoryList})
    });

    dialogRef.afterClosed().subscribe(async result => {
      if (result) {
        await this.getOrders();
      }
    });
  }

  filterOrder() {
    this.filteredOrderList = this.orderList.filter(item => {
      let status = item.meta.status;
      if (this.reservationCheck && status === 'RESERVED') {
        return true;
      } else if (this.activeCheck && status === 'ACTIVE'){
        return true;
      } else if (this.returnCheck && status === 'VEHICLE_RETURNED'){
        return true;
      } else if (this.completeCheck && status === 'COMPLETED'){
        return true;
      }
      return false;
    });
    this.refresh.next();
  }

  filterVehicles(event) {
    const val = event.target.value.toLowerCase();
    if (!val) {
      this.filteredVehicleList = {...this.vehicleList};
    } else {
      this.filteredVehicleList.Items = this.vehicleList.Items.filter(item => {
        if (item.id.toLowerCase().indexOf(val) !== -1) {
          return true;
        }
        if (item.make.toLowerCase().indexOf(val) !== -1) {
          return true;
        }
        if (item.model.toLowerCase().indexOf(val) !== -1) {
          return true;
        }
        return false;
      });
    }
    this.refresh.next();
  }
}
