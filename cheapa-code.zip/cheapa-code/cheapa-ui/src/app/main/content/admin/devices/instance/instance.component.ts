import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {DevicesService} from "../devices.service";
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {ActivatedRoute} from "@angular/router";
import {CustomFormGroup} from "app/main/common/form/CustomFormGroup";
import {FormControl} from "@angular/forms";

@Component({
  selector: 'device-instance',
  templateUrl: './instance.component.html',
  styleUrls: ['./instance.component.scss'],
  animations: fuseAnimations
})
export class DeviceInstanceComponent implements OnInit {
  id: string;
  isNew = false;
  isUpdate = false;
  loading = true;
  form: CustomFormGroup;
  instance: any = {};

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private devicesService: DevicesService,
              private route: ActivatedRoute) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      if ('new' === params['id']) {
        this.isNew = true;
      } else {
        this.id = params['id'];
        this.isUpdate = true;
      }
    });

    // Construct form
    this.form = new CustomFormGroup({
      name: new FormControl(this.instance.name),
    });

    if (!this.isNew) {
      this.instance = await this.devicesService.getInstance(this.id);
    }
  }

}
