import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {DashboardComponent} from './dashboard.component';
import {AppSharedModule} from "app/main/common/appShared.module";
import {AgmCoreModule} from "@agm/core";
import {environment} from "environments/environment";
import {AgmSnazzyInfoWindowModule} from "@agm/snazzy-info-window";
import {AgmJsMarkerClustererModule} from "@agm/js-marker-clusterer";
import {AccountsCanActivatePartner} from "../../../accounts/accounts.canActivatePartner";

const routes = [
  {
    canActivate: [AccountsCanActivatePartner],
    path: '',
    component: DashboardComponent
  }
];

@NgModule({
  declarations: [
    DashboardComponent
  ],
  providers: [],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule,
    AgmCoreModule.forRoot({
      apiKey: environment.googleApiKey
    }),
    AgmSnazzyInfoWindowModule,
    AgmJsMarkerClustererModule
  ]
})

export class DashboardModule {
}
