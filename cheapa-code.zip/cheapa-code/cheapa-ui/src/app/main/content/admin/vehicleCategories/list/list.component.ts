import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {DatatableComponent} from "@swimlane/ngx-datatable";
import {ListModel} from "app/main/common/list/ListModel";
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {VehicleCategoriesService} from "../vehicleCategories.service";
import {MatDialog, MatDialogConfig} from "@angular/material";
import {VehicleCategoryDialogComponent} from "../dialog/dialog.component";
import {VehicleCategoryImageDialogComponent} from "../imageDialog/imageDialog.component";

@Component({
  selector: 'vehicleCategory-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  animations: fuseAnimations
})
export class VehicleCategoryListComponent implements OnInit {
  @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
  list: ListModel;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private vehicleCategoriesService: VehicleCategoriesService,
              private dialog: MatDialog) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  ngOnInit() {
    this.list = new ListModel(this.table, 'id,name,rentPricePerDay,currency,location,isForRent,images', ['name', 'location']);
    this.getList('');
  }

  getList(listStartKey) {
    this.list.getList(async () => {
        return await this.vehicleCategoriesService.list(this.list.attributes, this.list.pageSize, listStartKey);
      }
    );
  }

  openDialog(id?) {
    const dialogRef = this.dialog.open(VehicleCategoryDialogComponent, <MatDialogConfig>{
      width: '600px',
      data: {id}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getList('');
      }
    });
  }

  openImageDialog(id) {
    const dialogRef = this.dialog.open(VehicleCategoryImageDialogComponent, <MatDialogConfig>{
      data: {id}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getList('');
      }
    });
  }
}
