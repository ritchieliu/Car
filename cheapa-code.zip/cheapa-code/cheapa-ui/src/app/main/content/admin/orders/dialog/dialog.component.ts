import {Component, Inject, OnInit} from '@angular/core';



import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {ActivatedRoute, Router} from '@angular/router';
import {FormControl, FormGroup} from '@angular/forms';
import {CustomFormGroup} from "app/main/common/form/CustomFormGroup";
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {OrdersService} from "../orders.service";
import {VehiclesService} from "../../vehicles/vehicles.service";
import * as _ from 'lodash';

@Component({
  selector: 'order-dialog',
  templateUrl: './dialog.component.html'
})
export class OrderDialogComponent implements OnInit {
  isNew = false;
  isUpdate = false;
  form: CustomFormGroup;
  instance: any = {
    email: '',
    vehicleId: '',
    pickUpDate: '',
    dropOffDate: '',
    payment: {
      amount: '',
      currency: "AUD"
    }
  };
  vehicleList: any = [];

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<OrderDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private ordersService: OrdersService,
              private vehiclesService: VehiclesService,
              private router: Router,
              private route: ActivatedRoute) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      if (!this.data.id) {
        this.isNew = true;
      } else {
        this.isUpdate = true;
      }
    });

    if (!this.isNew) {
      this.instance = await this.ordersService.getInstance(null, null);
    }

    await this.getVehicleList();

    this.form = new CustomFormGroup({
      email: new FormControl(this.instance.email),
      vehicleId: new FormControl(this.instance.vehicleId),
      pickUpDate: new FormControl(this.instance.pickUpDate),
      dropOffDate: new FormControl(this.instance.dropOffDate),
      payment: new FormGroup({
        amount: new FormControl(this.instance.payment.amount),
        currency: new FormControl(this.instance.payment.currency)
      }),
    });
  }

  async getVehicleList() {
    let vehicleList: any = await this.vehiclesService.list('id,operationStatus', '', '');
    this.vehicleList = _.sortBy(vehicleList.Items.filter(item => item.operationStatus === 'AVAILABLE'), o => o.id);
  }

  onSubmit() {
    this.form.submit(async () => {
        let result;
        if (this.isNew) {
          result = await this.ordersService.create(this.form.value);
        } else {
          result = await this.ordersService.update(this.data.id, this.form.value);
        }
        this.dialogRef.close(result);
      }
    );
  }

  close(): void {
    this.dialogRef.close();
  }
}
