import {Injectable} from '@angular/core';
import {environment} from 'environments/environment';
import {AccountsService} from 'app/main/accounts/accounts.service';

@Injectable({
  providedIn: 'root',
})
export class VehicleCategoriesService {

  baseApiURL = `${environment.apiBaseURL}/vehicleCategories`;

  constructor(private accountsService: AccountsService) {
  }

  list(express, limit, startKey, q?) {
    let params = {
      express,
      limit,
      startKey
    };

    if (q) {
      params = Object.assign(params, q);
    }

    return this.accountsService.request('get', this.baseApiURL, {
      params
    });
  }

  getInstance(id) {
    return this.accountsService.request('get', `${this.baseApiURL}/${id}`);
  }

  create(data) {
    return this.accountsService.request('post', this.baseApiURL, {
      body: data
    });
  }

  update(id, data) {
    return this.accountsService.request('put', `${this.baseApiURL}/${id}`, {
      body: data
    });
  }

  createImage(id, data) {
    return this.accountsService.request('post', `${this.baseApiURL}/${id}/images`, {
      body: data
    });
  }

  deleteImage(id, key) {
    return this.accountsService.request('delete', `${this.baseApiURL}/${id}/images`, {
      params: {
        key: key
      }
    });
  }
}
