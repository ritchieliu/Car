import {Component, Inject, OnInit} from '@angular/core';


import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {ActivatedRoute, Router} from '@angular/router';
import {FormControl} from '@angular/forms';
import {CustomFormGroup} from "app/main/common/form/CustomFormGroup";
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {VehiclesService} from "../../vehicles/vehicles.service";
import * as moment from "moment";
import {BookingFeeService} from "../booking.fee.service";
import {OrdersService} from "../../orders/orders.service";
import {ImageUploadService} from "../../../../common/imageUpload/imageUpload.service";
import {AccountsService} from "../../../../accounts/accounts.service";
import {SnackService} from "../../../../common/snack/snack.service";

@Component({
  selector: 'admin-booking-dialog',
  templateUrl: './dialog.component.html'
})
export class AdminBookingDialogComponent implements OnInit {
  isNew = false;
  isUpdate = false;
  form: CustomFormGroup;
  vehicle: any = {};
  vehicleCategory: any = {};
  vehicleCategoryList;
  vehicleList;
  vehicleListInCategory;
  instance: any;
  order: any;
  account: any;
  now = moment();

  statusForm: CustomFormGroup;

  driverLicenseImageUploadService: ImageUploadService;
  imageUploadServiceFrontRight: any;
  imageUploadServiceFrontLeft: any;
  imageUploadServiceBackLeft: any;
  imageUploadServiceBackRight: any;
  imageUploadServiceDashboard: any;
  imageUploadServiceKey: any;

  isOrderEmailSending = false;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<AdminBookingDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private vehiclesService: VehiclesService,
              private ordersService: OrdersService,
              private router: Router,
              private route: ActivatedRoute,
              public bookingFeeService: BookingFeeService,
              public imageUploadService: ImageUploadService,
              private snackService: SnackService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.vehicleCategoryList = this.data.vehicleCategoryList;
    this.vehicleList = this.data.vehicleList;

    if (this.data.accountId && this.data.createdAt) {
      this.isUpdate = true;

      let [vehicle, vehicleCategory, order] = await Promise.all([
        this.vehicleList.Items.find(vehicle => this.data.vehicleId === vehicle.id),
        this.vehicleCategoryList.Items.find(vehicleCategory => this.data.vehicleCategoryId === vehicleCategory.id),
        this.ordersService.getInstance(this.data.accountId, this.data.createdAt),
      ]);
      this.vehicleCategory = vehicleCategory;
      this.vehicle = vehicle;
      this.vehicleListInCategory = this.vehicleList.Items.filter(vehicle => vehicle.vehicleCategoryId === this.vehicleCategory.id);
      if (!this.vehicle) {
        this.vehicle = {};
      }

      this.order = order;

      this.instance = {
        vehicleId: this.order.vehicleId,
        vehicleCategoryId: this.order.vehicleCategoryId,
        vehicleCategoryName: this.order.vehicleCategoryName,
        vehicleOdometerStart: this.order.vehicleOdometerStart,
        vehicleOdometerEnd: this.order.vehicleOdometerEnd,
        status: this.order.status,
        email: this.order.email,
        mobile: this.order.mobile,
        firstName: this.order.firstName,
        lastName: this.order.lastName,
        pickUpDate: moment(this.order.pickUpDate).local().set({
          minute: 0,
          second: 0
        }),
        pickUpHour: moment(this.order.pickUpDate).local().get('hour'),
        pickUpMinute: moment(this.order.pickUpDate).local().get('minute'),
        dropOffDate: moment(this.order.dropOffDate).local().set({
          minute: 0,
          second: 0
        }),
        dropOffHour: moment(this.order.dropOffDate).local().get('hour'),
        dropOffMinute: moment(this.order.dropOffDate).local().get('minute'),
        pickUpLocation: this.bookingFeeService.LOCATIONS.find(location => location.name === this.order.pickUpLocation.name),
        dropOffLocation: this.bookingFeeService.LOCATIONS.find(location => location.name === this.order.dropOffLocation.name),

        driverAge: this.order.driverAge,

        insurance: this.order.insurance,
        roadSideAssistant: this.order.roadSideAssistant,
        additionalDriver: this.order.additionalDriver,
        childSeatSmall: this.order.childSeatSmall,
        childSeatLarge: this.order.childSeatLarge,
        gps: this.order.gps,
        mobilePhoneHolder: this.order.mobilePhoneHolder,
        tyreWindscreenCover: this.order.tyreWindscreenCover,
        unlimitedDistance: this.order.unlimitedDistance,

        discount: this.order.payment.discount / 100 || 0,
        signature: this.order.signature,
        driverLicenses: this.order.driverLicenses,
        source: this.order.source,
        comment: this.order.comment,
        businessPartnerId: this.order.businessPartnerId,
      };

      if (this.order.pickUpLocation.name) {
        this.instance.pickUpLocation = this.bookingFeeService.LOCATIONS.find(location => location.name === this.order.pickUpLocation.name);
        this.instance.dropOffLocation = this.bookingFeeService.LOCATIONS.find(location => location.name === this.order.dropOffLocation.name);
      } else {
        this.instance.pickUpLocation = this.order.pickUpLocation;
        this.instance.dropOffLocation = this.order.dropOffLocation;
      }

      this.statusForm = new CustomFormGroup({
        status: new FormControl(this.instance.status),
      });

      // Driver license init
      this.driverLicenseImageUploadService = this.imageUploadService.getInstance();
      this.driverLicenseImageUploadService.initUploadedFiles(this.instance.driverLicenses);

      // Vehicle photo
      this.imageUploadServiceFrontRight = this.imageUploadService.getInstance();
      this.imageUploadServiceFrontLeft = this.imageUploadService.getInstance();
      this.imageUploadServiceBackLeft = this.imageUploadService.getInstance();
      this.imageUploadServiceBackRight = this.imageUploadService.getInstance();
      this.imageUploadServiceDashboard = this.imageUploadService.getInstance();
      this.imageUploadServiceKey = this.imageUploadService.getInstance();

      if (!this.order.vehicleImages) {
        this.order.vehicleImages = {};
      }
      this.imageUploadServiceFrontRight.initUploadedFiles(this.order.vehicleImages.FRONT_RIGHT);
      this.imageUploadServiceFrontLeft.initUploadedFiles(this.order.vehicleImages.FRONT_LEFT);
      this.imageUploadServiceBackLeft.initUploadedFiles(this.order.vehicleImages.BACK_LEFT);
      this.imageUploadServiceBackRight.initUploadedFiles(this.order.vehicleImages.BACK_RIGHT);
      this.imageUploadServiceDashboard.initUploadedFiles(this.order.vehicleImages.DASHBOARD);
      this.imageUploadServiceKey.initUploadedFiles(this.order.vehicleImages.KEY);
    } else {
      this.isNew = true;
      let day = new Date();

      if (this.data.vehicle) {
        this.vehicle = this.data.vehicle;
        this.vehicleCategory = this.vehicleCategoryList.Items.find(vehicleCategory => this.data.vehicle.vehicleCategoryId === vehicleCategory.id);
        day = this.data.day.date;
      } else if (this.data.vehicleCategory) {
        this.vehicle = {};
        this.vehicleCategory = this.vehicleCategoryList.Items.find(vehicleCategory => this.data.vehicleCategory.id === vehicleCategory.id);
      }

      this.vehicleListInCategory = this.vehicleList.Items.filter(vehicle => vehicle.vehicleCategoryId === this.vehicleCategory.id);

      this.instance = {
        vehicleId: this.vehicle.id,
        vehicleCategoryId: this.vehicleCategory.id,
        vehicleCategoryName: this.vehicleCategory.vehicleCategoryName,
        vehicleOdometerStart: null,
        vehicleOdometerEnd: null,
        email: null,
        mobile: null,
        firstName: null,
        lastName: null,
        pickUpDate: moment(day).set({
          minute: 0,
          second: 0
        }),
        pickUpHour: moment(day).get('hour'),
        pickUpMinute: 0,
        dropOffDate: moment(day).add(1, 'day').set({
          minute: 0,
          second: 0
        }),
        dropOffHour: moment(day).get('hour'),
        dropOffMinute: 0,
        pickUpLocation: this.bookingFeeService.LOCATIONS[0],
        dropOffLocation: this.bookingFeeService.LOCATIONS[0],

        driverAge: false,
        insurance: true,
        roadSideAssistant: false,
        additionalDriver: false,
        childSeatSmall: false,
        childSeatLarge: false,
        gps: false,
        mobilePhoneHolder: false,
        tyreWindscreenCover: false,
        unlimitedDistance: false,

        discount: 0,
        source: '',
        comment: ''
      };
    }

    this.form = new CustomFormGroup({
      vehicleId: new FormControl(this.instance.vehicleId),
      vehicleCategoryId: new FormControl(this.instance.vehicleCategoryId),
      vehicleCategoryName: new FormControl(this.instance.vehicleCategoryName),
      vehicleOdometerStart: new FormControl(this.instance.vehicleOdometerStart),
      vehicleOdometerEnd: new FormControl(this.instance.vehicleOdometerEnd),
      mobile: new FormControl(this.instance.mobile),
      firstName: new FormControl(this.instance.firstName),
      lastName: new FormControl(this.instance.lastName),
      pickUpDate: new FormControl(this.instance.pickUpDate),
      pickUpHour: new FormControl(this.instance.pickUpHour),
      pickUpMinute: new FormControl(this.instance.pickUpMinute),
      dropOffDate: new FormControl(this.instance.dropOffDate),
      dropOffHour: new FormControl(this.instance.dropOffHour),
      dropOffMinute: new FormControl(this.instance.dropOffMinute),
      pickUpLocation: new FormControl(this.instance.pickUpLocation),
      dropOffLocation: new FormControl(this.instance.dropOffLocation),
      driverAge: new FormControl(this.instance.driverAge),
      insurance: new FormControl(this.instance.insurance),
      roadSideAssistant: new FormControl(this.instance.roadSideAssistant),
      additionalDriver: new FormControl(this.instance.additionalDriver),
      childSeatSmall: new FormControl(this.instance.childSeatSmall),
      childSeatLarge: new FormControl(this.instance.childSeatLarge),
      gps: new FormControl(this.instance.gps),
      mobilePhoneHolder: new FormControl(this.instance.mobilePhoneHolder),
      tyreWindscreenCover: new FormControl(this.instance.tyreWindscreenCover),
      unlimitedDistance: new FormControl(this.instance.unlimitedDistance),
      email: new FormControl(this.instance.email),
      discount: new FormControl(this.instance.discount),
      source: new FormControl(this.instance.source),
      businessPartnerId: new FormControl(this.instance.businessPartnerId),
      comment: new FormControl(this.instance.comment),
    });
  }

  onSubmit() {
    this.form.submit(async () => {
        let result;
        let payload = {
          vehicleId: this.form.get('vehicleId').value,
          vehicleCategoryId: this.form.get('vehicleCategoryId').value,
          vehicleOdometerStart: this.form.get('vehicleOdometerStart').value,
          vehicleOdometerEnd: this.form.get('vehicleOdometerEnd').value,
          email: this.form.get('email').value,
          mobile: this.form.get('mobile').value,
          firstName: this.form.get('firstName').value,
          lastName: this.form.get('lastName').value,
          pickUpDate: this.form.get('pickUpDate').value.utc().toISOString(),
          dropOffDate: this.form.get('dropOffDate').value.utc().toISOString(),
          pickUpLocation: {
            name: this.form.get('pickUpLocation').value.name,
            city: this.form.get('pickUpLocation').value.city
          },
          dropOffLocation: {
            name: this.form.get('dropOffLocation').value.name,
            city: this.form.get('dropOffLocation').value.city,
          },
          driverAge: this.form.get('driverAge').value,
          insurance: this.form.get('insurance').value,
          roadSideAssistant: this.form.get('roadSideAssistant').value,
          additionalDriver: this.form.get('additionalDriver').value,
          childSeatSmall: this.form.get('childSeatSmall').value,
          childSeatLarge: this.form.get('childSeatLarge').value,
          gps: this.form.get('gps').value,
          mobilePhoneHolder: this.form.get('mobilePhoneHolder').value,
          tyreWindscreenCover: this.form.get('tyreWindscreenCover').value,
          unlimitedDistance: this.form.get('unlimitedDistance').value,
          discount: this.form.get('discount').value,
          source: this.form.get('source').value,
          comment: this.form.get('comment').value,
          businessPartnerId: this.form.get('businessPartnerId').value,
        };
        if (this.isNew) {
          result = await this.ordersService.create(payload);
        } else {
          result = await this.ordersService.update({accountId: this.data.accountId, createdAt: this.data.createdAt}, payload);
        }
        this.dialogRef.close(result);
      }
    );
  }

  close(): void {
    this.dialogRef.close();
  }

  onVehicleCategoryChange() {
    let vehicleCategoryIdControl = this.form.get('vehicleCategoryId');
    let vehicleCategory = this.vehicleCategoryList.Items.find(vehicleCategory => vehicleCategory.id === vehicleCategoryIdControl.value);
    this.vehicleCategory = vehicleCategory;
    this.vehicleListInCategory = this.vehicleList.Items.filter(vehicle => vehicle.vehicleCategoryId === vehicleCategory.id);
    this.form.get('vehicleId').setValue(null)
  }

  onOrderDateChange() {
    let pickUpDateControl = this.form.get('pickUpDate');
    let dropOffDateControl = this.form.get('dropOffDate');
    pickUpDateControl.updateValueAndValidity();
    pickUpDateControl.value.set({
      hour: this.form.get('pickUpHour').value,
      minute: this.form.get('pickUpMinute').value,
      second: 0
    });
    dropOffDateControl.updateValueAndValidity();
    dropOffDateControl.value.set({
      hour: this.form.get('dropOffHour').value,
      minute: this.form.get('dropOffMinute').value,
      second: 0
    });

    if (dropOffDateControl.value.isBefore(pickUpDateControl.value)) {
      dropOffDateControl.setErrors({'datePickerMin': true});
    }
  }

  getFeeModel() {
    return {
      pickUpDate: this.form.get('pickUpDate').value,
      dropOffDate: this.form.get('dropOffDate').value,
      pickUpLocation: this.form.get('pickUpLocation').value,
      dropOffLocation: this.form.get('dropOffLocation').value,
      rentPricePerDay: this.bookingFeeService.calculateRentPricePerDay({
        pickUpDate: this.form.get('pickUpDate').value,
        dropOffDate: this.form.get('dropOffDate').value,
        pricing: this.vehicleCategory.pricing
      }),
      driverAge: this.form.get('driverAge').value,
      insurance: this.bookingFeeService.calculateInsuranceObject({
        pickUpDate: this.form.get('pickUpDate').value,
        dropOffDate: this.form.get('dropOffDate').value,
        insurance: this.vehicleCategory.insurance,
        insuranceApplied: this.form.get('insurance').value,
      }),
      roadSideAssistant: this.form.get('roadSideAssistant').value,
      additionalDriver: this.form.get('additionalDriver').value,
      childSeatSmall: this.form.get('childSeatSmall').value,
      childSeatLarge: this.form.get('childSeatLarge').value,
      gps: this.form.get('gps').value,
      mobilePhoneHolder: this.form.get('mobilePhoneHolder').value,
      tyreWindscreenCover: this.form.get('tyreWindscreenCover').value,
      unlimitedDistance: this.form.get('unlimitedDistance').value,
      discount: this.form.get('discount').value
    }
  }

  calculateChargeByType({type, applied}) {
    return this.bookingFeeService.calculateChargeByType({
      pickUpDate: this.getFeeModel().pickUpDate,
      dropOffDate: this.getFeeModel().dropOffDate,
      type: type,
      applied: applied
    })
  }

  // Status start
  onStatusFormSubmit() {
    this.statusForm.submit(async () => {
        let result = await this.ordersService.updateStatus(this.data.accountId, this.data.createdAt, this.statusForm.get('status').value);
        this.dialogRef.close(result);
      }
    );
  }

  // Status end

  // Driver license start
  async onDriverLicenseRemoved($event) {
    await this.driverLicenseImageUploadService.onRemoved($event, this.ordersService.deleteDriverLicense(this.order.accountId, this.order.createdAt, $event.file.name));
  }

  getDriverLicenseUploadRequest() {
    return async (result) => {
      let response: any = await this.ordersService.createDriverLicense(this.order.accountId, this.order.createdAt, {body: result});
      return response
    }
  }

  async sendOrderConfirmEmail() {
    this.isOrderEmailSending = true;
    await this.ordersService.sendOrderConfirmEmail(this.data.accountId, this.data.createdAt);
    this.snackService.openSnack('Email Sent', this.snackService.SUCCESS_SNACK_CLASS);
    this.isOrderEmailSending = false;
  }
  // Driver license end

  // Vehicle images start
  getVehicleImageUploadRequest(type) {
    return async (result) => {
      let image = await this.ordersService.createVehicleImage(this.order.accountId, this.order.createdAt, {body: result, type: type});
      this.order.vehicleImages[type] = image;
      return image;
    }
  }

  async deleteVehicleImage($event, imageService, type) {
    await imageService.onRemoved($event, this.ordersService.deleteVehicleImage(this.order.accountId, this.order.createdAt, type));
    delete this.order.vehicleImages[type];
  }

  // Vehicle images end


}
