import {Injectable} from '@angular/core';
import {DevicesService} from "../devices/devices.service";
import * as moment from "moment";
import {SnackService} from "../../../common/snack/snack.service";

@Injectable({
  providedIn: 'root',
})
export class VehicleActionsService {

  constructor(private devicesService: DevicesService,
              private snackService: SnackService) {
  }

  async openDoor(vehicle, orderCreatedAt?) {
    const commandName = 'Open Door';
    try {
      await this.snackService.openSnack(`'${commandName}' for ${vehicle.id}.`, this.snackService.IN_PROGRESS_SNACK_CLASS);
      await this.devicesService.setAction(vehicle.deviceId, {
        action: 'OPEN_DOOR',
        orderCreatedAt: orderCreatedAt,
        vehicleId: vehicle.id
      });
      await this.checkActionStatus(vehicle, ['MSG_COMMAND_DEVICE_CONFIRM_OPEN_DOOR', 'MSG_COMMAND_DEVICE_CONFIRM_OIL_ACTION'], commandName, moment().utc().toISOString())
    } catch (e) {
      this.openActionFailedSnack(commandName, vehicle)
    }
  }

  async closeDoor(vehicle, orderCreatedAt?) {
    const commandName = 'Close Door';
    try {
      await this.snackService.openSnack(`'${commandName}' for ${vehicle.id}.`, this.snackService.IN_PROGRESS_SNACK_CLASS);
      await this.devicesService.setAction(vehicle.deviceId, {
        action: 'CLOSE_DOOR',
        orderCreatedAt: orderCreatedAt,
        vehicleId: vehicle.id
      });
      await this.checkActionStatus(vehicle, ['MSG_COMMAND_DEVICE_CONFIRM_CLOSE_DOOR', 'MSG_COMMAND_DEVICE_CONFIRM_OIL_ACTION'], commandName, moment().utc().toISOString())
    } catch (e) {
      this.openActionFailedSnack(commandName, vehicle)
    }
  }

  async controlCircuitOn(vehicle) {
    const commandName = 'Circuit On';
    try {
      await this.snackService.openSnack(`'${commandName}' for ${vehicle.id}.`, this.snackService.IN_PROGRESS_SNACK_CLASS);
      await this.devicesService.setAction(vehicle.deviceId, {
        action: 'CONTROL_CIRCUIT_ON',
        vehicleId: vehicle.id
      });
      await this.checkActionStatus(vehicle, 'MSG_COMMAND_DEVICE_CONFIRM_CIRCUIT_ACTION', commandName, moment().utc().toISOString())
    } catch (e) {
      this.openActionFailedSnack(commandName, vehicle)
    }
  }

  async controlCircuitOff(vehicle) {
    const commandName = 'Circuit Off';
    try {
      await this.snackService.openSnack(`'${commandName}' for ${vehicle.id}.`, this.snackService.IN_PROGRESS_SNACK_CLASS);
      await this.devicesService.setAction(vehicle.deviceId, {
        action: 'CONTROL_CIRCUIT_OFF',
        vehicleId: vehicle.id
      });
      await this.checkActionStatus(vehicle, 'MSG_COMMAND_DEVICE_CONFIRM_CIRCUIT_ACTION', commandName, moment().utc().toISOString())
    } catch (e) {
      this.openActionFailedSnack(commandName, vehicle)
    }
  }

  async checkActionStatus(vehicle, action, commandName, requestTime) {
    let hasConfirmed = false;
    let hasTimeout = false;
    let self = this;
    setTimeout(() => {
      if (hasConfirmed) {
        return;
      }
      hasTimeout = true;
      self.snackService.openSnack(`Failed to '${commandName}' for ${vehicle.id}.`, self.snackService.FAIL_SNACK_CLASS)
    }, 20000);

    async function checkAction() {
      if (hasTimeout) {
        return;
      }
      const reportList: any = await self.devicesService.listReport(vehicle.deviceId, 'id,createdAt,payload,type', 25, '', {descending: true});
      reportList.Items.forEach(item => {
        if (item.createdAt > requestTime && (item.payload.action === action || action.includes(item.payload.action))) {
          hasConfirmed = true;
          self.snackService.openSnack(`Success to '${commandName}' for ${vehicle.id}`, self.snackService.SUCCESS_SNACK_CLASS)
        }
      });

      if (!hasConfirmed) {
        setTimeout(async () => {
          await checkAction();
        }, 5000);
      }
    }

    setTimeout(async () => {
      await checkAction();
    }, 5000);
  }

  openActionFailedSnack(commandName, vehicle) {
    this.snackService.openSnack(`Failed to '${commandName}' for ${vehicle.id}`, this.snackService.FAIL_SNACK_CLASS)
  }
}
