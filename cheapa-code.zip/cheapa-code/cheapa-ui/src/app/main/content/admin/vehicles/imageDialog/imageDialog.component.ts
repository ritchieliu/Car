import {Component, Inject, OnInit} from '@angular/core';



import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {VehiclesService} from "../vehicles.service";
import {ImageUploadService} from "../../../../common/imageUpload/imageUpload.service";

@Component({
  selector: 'vehicle-image-dialog',
  templateUrl: './imageDialog.component.html'
})
export class VehicleImageDialogComponent implements OnInit {

  instance: any;


  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<VehicleImageDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              public vehiclesService: VehiclesService,
              public imageUploadService: ImageUploadService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.instance = await this.vehiclesService.getInstance(this.data.id);
    this.imageUploadService.initUploadedFiles(this.instance.images)
  }

  getImageUploadRequest() {
    return (result) => {
      return this.vehiclesService.createImage(this.instance.id, {body: result});
    }
  }
}
