import {Injectable} from '@angular/core';
import {environment} from 'environments/environment';
import {AccountsService} from 'app/main/accounts/accounts.service';

@Injectable({
  providedIn: 'root',
})
export class DevicesService {

  baseApiURL = `${environment.apiBaseURL}/devices`;

  constructor(private accountsService: AccountsService) {
  }

  list(express, limit, startKey) {
    return this.accountsService.request('get', this.baseApiURL, {
      params: {
        express,
        limit,
        startKey
      }
    });
  }

  getInstance(id) {
    return this.accountsService.request('get', `${this.baseApiURL}/${id}`);
  }

  create(data) {
    return this.accountsService.request('post', this.baseApiURL, {
      body: data
    });
  }

  update(id, data) {
    return this.accountsService.request('put', `${this.baseApiURL}/${id}`, {
      body: data
    });
  }

  listReport(id, express, limit, startKey, q) {
    return this.accountsService.request('get', `${this.baseApiURL}/${id}/reports`, {
      params: {
        express,
        limit,
        startKey: startKey ? JSON.stringify(startKey) : startKey,
        descending: q.descending,
        startDate: q.startDate ? q.startDate : '',
        endDate: q.startDate ? q.endDate : ''
      }
    });
  }

  setAction(id, body) {
    return this.accountsService.request('post', `${this.baseApiURL}/${id}/action`, {
      body: body
    });
  }
}
