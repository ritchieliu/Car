import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AppSharedModule} from "app/main/common/appShared.module";
import {BusinessListComponent} from "./list/list.component";
import {BusinessDialogComponent} from "./dialog/dialog.component";
import {AccountsCanActivateAdmin} from "app/main/accounts/accounts.canActivateAdmin";

const routes = [
  {
    canActivate: [AccountsCanActivateAdmin],
    path: '',
    component: BusinessListComponent
  }
];

@NgModule({
  declarations: [
    BusinessListComponent,
    BusinessDialogComponent,
  ],
  entryComponents: [
    BusinessDialogComponent,
  ],
  providers: [],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule
  ],
  exports: [
    BusinessListComponent,
    BusinessDialogComponent
  ]
})

export class BusinessesModule {
}
