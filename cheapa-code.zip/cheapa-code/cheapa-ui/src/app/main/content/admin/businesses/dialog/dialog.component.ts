import {Component, Inject, OnInit} from '@angular/core';



import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {ActivatedRoute, Router} from '@angular/router';
import {FormControl} from '@angular/forms';
import {CustomFormGroup} from "app/main/common/form/CustomFormGroup";
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {BusinessesService} from "../businesses.service";

@Component({
  selector: 'business-dialog',
  templateUrl: './dialog.component.html'
})
export class BusinessDialogComponent implements OnInit {
  isNew = false;
  isUpdate = false;
  form: CustomFormGroup;
  instance: any = {
    name: '',
    email: '',
    mobile: '',
    country: 'AU',
    currency: 'AUD',
    routingNumber: '',
    accountNumber: '',
    commissionRate: ''
  };

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<BusinessDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private businessesService: BusinessesService,
              private router: Router,
              private route: ActivatedRoute) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      if (!this.data.id) {
        this.isNew = true;
      } else {
        this.isUpdate = true;
      }
    });

    if (!this.isNew) {
      this.instance = await this.businessesService.getInstance(this.data.id);
    }

    this.form = new CustomFormGroup({
      name: new FormControl(this.instance.name),
      email: new FormControl(this.instance.email),
      mobile: new FormControl(this.instance.mobile),
      country: new FormControl(this.instance.country),
      currency: new FormControl(this.instance.currency),
      routingNumber: new FormControl(this.instance.routingNumber),
      accountNumber: new FormControl(this.instance.accountNumber),
      commissionRate: new FormControl(this.instance.commissionRate),
    });
  }

  onSubmit() {
    this.form.submit(async () => {
        let result;
        if (this.isNew) {
          result = await this.businessesService.create(this.form.value);
        } else {
          result = await this.businessesService.update(this.data.id, this.form.value);
        }
        this.dialogRef.close(result);
      }
    );
  }

  close(): void {
    this.dialogRef.close();
  }
}
