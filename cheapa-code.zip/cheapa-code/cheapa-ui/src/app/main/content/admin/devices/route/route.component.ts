import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations/index';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {DevicesService} from "../devices.service";
import {ActivatedRoute} from "@angular/router";
import * as moment from "moment";
import {CustomFormGroup} from "../../../../common/form/CustomFormGroup";
import {FormControl} from "@angular/forms";
import {AccountsService} from "../../../../accounts/accounts.service";

@Component({
  selector: 'device-route',
  templateUrl: './route.component.html',
  styleUrls: ['./route.component.scss'],
  animations: fuseAnimations
})
export class DeviceRouteComponent implements OnInit {
  id: string;
  list: any = [];
  points: any = [];
  isLoading;
  form: CustomFormGroup;
  startDate: any = moment().subtract(1, 'day');
  maxDateRange: any = moment();

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private devicesService: DevicesService,
              private route: ActivatedRoute,
              public accountsService: AccountsService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    });

    this.form = new CustomFormGroup({
      dateRange: new FormControl([this.startDate, this.maxDateRange])
    });

    await this.getDeviceReport(this.form.value.dateRange[0], this.form.value.dateRange[1]);
  }

  async getDeviceReport(startDate, endDate) {
    this.isLoading = true;
    this.list = await this.devicesService.listReport(this.id, 'id,createdAt,payload,type', '', '', {
      descending: true,
      startDate: moment(startDate).utc().toISOString(),
      endDate: moment(endDate).utc().toISOString()
    });
    this.points = this.list.Items.filter(item => item.type === 'LOCATION').map(item => {
      return {
        latitude: item.payload.latitude,
        longitude: item.payload.longitude,
        createdAt: moment(item.createdAt).local()
      }
    });
    this.isLoading = false;
  }

  onSubmit() {
    this.form.submit(async () => {
        await this.getDeviceReport(this.form.value.dateRange[0], this.form.value.dateRange[1])
      }
    );
  }
}
