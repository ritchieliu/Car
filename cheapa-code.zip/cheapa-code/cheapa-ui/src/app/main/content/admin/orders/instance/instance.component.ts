import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {ActivatedRoute} from "@angular/router";
import {OrdersService} from "../orders.service";

@Component({
  selector: 'order-instance',
  templateUrl: './instance.component.html',
  styleUrls: ['./instance.component.scss'],
  animations: fuseAnimations
})
export class OrderInstanceComponent implements OnInit {
  instance: any = {};
  account: any = {};
  accountId;
  createdAt;
  isLoading;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private ordersService: OrdersService,
              private route: ActivatedRoute) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    await this.route.params.subscribe(params => {
      this.createdAt = params['createdAt'];
    });

    await this.route.queryParams.subscribe(async params => {
      this.accountId = params['accountId']
    });

    this.isLoading = true;
    this.instance = await this.ordersService.getInstance(this.accountId, this.createdAt);
    this.isLoading = false;
  }

}
