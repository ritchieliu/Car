import {Component, Inject, OnInit} from '@angular/core';


import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {ActivatedRoute, Router} from '@angular/router';
import {FormControl} from '@angular/forms';
import {CustomFormGroup} from "app/main/common/form/CustomFormGroup";
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {VehiclesService} from "../vehicles.service";
import {VehicleCategoriesService} from "../../vehicleCategories/vehicleCategories.service";
import {AccountsService} from "../../../../accounts/accounts.service";

@Component({
  selector: 'vehicle-dialog',
  templateUrl: './dialog.component.html'
})
export class VehicleDialogComponent implements OnInit {
  isNew = false;
  isUpdate = false;
  form: CustomFormGroup;
  instance: any = {
    id: '',
    make: '',
    model: '',
    seatNumber: '',
    transmission: '',
    color: '',
    year: '',
    operationStatus: 'AVAILABLE',
    accountId: ''
  };
  accountList;
  vehicleCategoryList;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<VehicleDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private vehiclesService: VehiclesService,
              private accountsService: AccountsService,
              private vehicleCategoriesService: VehicleCategoriesService,
              private router: Router,
              private route: ActivatedRoute) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      if (!this.data.id) {
        this.isNew = true;
      } else {
        this.isUpdate = true;
      }
    });

    if (!this.isNew) {
      this.instance = await this.vehiclesService.getInstance(this.data.id);
    }

    this.accountList = await this.accountsService.list('id,friendly_id,family_name,given_name,name', '', '', {
      cognito_groups: 'partner'
    });
    this.vehicleCategoryList = await this.vehicleCategoriesService.list('id,name,rentPricePerDay,currency,location', '', '');

    this.form = new CustomFormGroup({
      id: new FormControl(this.instance.id),
      make: new FormControl(this.instance.make),
      model: new FormControl(this.instance.model),
      seatNumber: new FormControl(this.instance.seatNumber),
      transmission: new FormControl(this.instance.transmission),
      color: new FormControl(this.instance.color),
      year: new FormControl(this.instance.year),
      operationStatus: new FormControl(this.instance.operationStatus),
      accountId: new FormControl(this.instance.accountId),
      vehicleCategoryId: new FormControl(this.instance.vehicleCategoryId)
    });
  }

  onSubmit() {
    this.form.submit(async () => {
        let result;
        if (this.isNew) {
          result = await this.vehiclesService.create(this.form.value);
        } else {
          result = await this.vehiclesService.update(this.data.id, this.form.value);
        }
        this.dialogRef.close(result);
      }
    );
  }

  close(): void {
    this.dialogRef.close();
  }
}
