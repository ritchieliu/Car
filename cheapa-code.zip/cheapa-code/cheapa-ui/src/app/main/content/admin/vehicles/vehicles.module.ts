import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AppSharedModule} from "app/main/common/appShared.module";
import {VehicleListComponent} from "./list/list.component";
import {VehicleDialogComponent} from "./dialog/dialog.component";
import {ImageUploadModule} from "angular2-image-upload";
import {VehicleImageDialogComponent} from "./imageDialog/imageDialog.component";
import {Ng2ImgMaxModule} from "ng2-img-max";
import {ImageUploadService} from "../../../common/imageUpload/imageUpload.service";
import {AccountsCanActivatePartner} from "../../../accounts/accounts.canActivatePartner";

const routes = [
  {
    canActivate: [AccountsCanActivatePartner],
    path: '',
    component: VehicleListComponent
  }
];

@NgModule({
  declarations: [
    VehicleListComponent,
    VehicleDialogComponent,
    VehicleImageDialogComponent,
  ],
  entryComponents: [
    VehicleDialogComponent,
    VehicleImageDialogComponent,
  ],
  providers: [
    ImageUploadService
  ],
  imports: [
    RouterModule.forChild(routes),
    ImageUploadModule.forRoot(),
    Ng2ImgMaxModule,
    AppSharedModule
  ],
  exports: [
    VehicleListComponent,
    VehicleDialogComponent
  ]
})

export class VehiclesModule {
}
