import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AppSharedModule} from "app/main/common/appShared.module";
import {DeviceListComponent} from "./list/list.component";
import {DeviceInstanceComponent} from "./instance/instance.component";
import {DeviceReportListComponent} from "./reports/list/list.component";
import {DeviceDialogComponent} from "./dialog/dialog.component";
import {DeviceRouteComponent} from "./route/route.component";
import {environment} from "environments/environment";
import {AgmSnazzyInfoWindowModule} from "@agm/snazzy-info-window";
import {AgmCoreModule} from "@agm/core";
import {AccountsCanActivateAdmin} from "app/main/accounts/accounts.canActivateAdmin";
import {AgmJsMarkerClustererModule} from "@agm/js-marker-clusterer";
import {AccountsCanActivatePartner} from "../../../accounts/accounts.canActivatePartner";

const routes = [
  {
    canActivate: [AccountsCanActivateAdmin],
    path: '',
    component: DeviceListComponent
  },
  {
    canActivate: [AccountsCanActivateAdmin],
    path: ':id/report',
    component: DeviceReportListComponent
  },
  {
    canActivate: [AccountsCanActivatePartner],
    path: ':id/route',
    component: DeviceRouteComponent
  }
];

@NgModule({
  declarations: [
    DeviceListComponent,
    DeviceInstanceComponent,
    DeviceDialogComponent,
    DeviceReportListComponent,
    DeviceRouteComponent
  ],
  entryComponents: [
    DeviceDialogComponent
  ],
  providers: [],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule,
    AgmCoreModule.forRoot({
      apiKey: environment.googleApiKey
    }),
    AgmSnazzyInfoWindowModule,
    AgmJsMarkerClustererModule
  ],
  exports: [
    DeviceListComponent,
    DeviceInstanceComponent,
    DeviceReportListComponent,
    DeviceRouteComponent
  ]
})

export class DevicesModule {
}
