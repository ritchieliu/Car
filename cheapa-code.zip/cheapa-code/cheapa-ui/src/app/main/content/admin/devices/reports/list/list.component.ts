import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations/index';
import {DatatableComponent} from "@swimlane/ngx-datatable";
import {ListModel} from "app/main/common/list/ListModel";
import {DevicesService} from "../../devices.service";
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'device-report-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  animations: fuseAnimations
})
export class DeviceReportListComponent implements OnInit {
  id: string;
  @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
  list: ListModel;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private devicesService: DevicesService,
              private route: ActivatedRoute) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    });

    this.list = new ListModel(this.table, 'id,createdAt,payload,type', [], 25);
    this.getList('');
  }

  getList(listStartKey) {
    this.list.getList(async () => {
        return await this.devicesService.listReport(this.id, this.list.attributes, this.list.pageSize, listStartKey, {descending: true});
      }
    );
  }
}
