import {Component, Inject, OnInit} from '@angular/core';



import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {ActivatedRoute, Router} from '@angular/router';
import {FormControl} from '@angular/forms';
import {CustomFormGroup} from "app/main/common/form/CustomFormGroup";
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";
import {VehicleCategoriesService} from "../vehicleCategories.service";
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
  selector: 'vehicleCategory-dialog',
  templateUrl: './dialog.component.html'
})
export class VehicleCategoryDialogComponent implements OnInit {
  isNew = false;
  isUpdate = false;
  form: CustomFormGroup;
  instance: any = {
    name: '',
    description: null,
    location: null,
    isForRent: true,
    rentPricePerDay: null,
    currency: 'AUD',
  };

  cities: any = [
    {
      name: 'Sydney',
    },
    {
      name: 'Melbourne',
    },
    {
      name: 'Brisbane',
    },
    {
      name: 'Gold Coast',
    },
    {
      name: 'Perth',
    }];


  public descriptionEditor = ClassicEditor;
  public descriptionConfig = {
    placeholder: 'Description'
  };

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<VehicleCategoryDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private vehicleCategoriesService: VehicleCategoriesService,
              private router: Router,
              private route: ActivatedRoute) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      if (!this.data.id) {
        this.isNew = true;
      } else {
        this.isUpdate = true;
      }
    });

    if (!this.isNew) {
      this.instance = await this.vehicleCategoriesService.getInstance(this.data.id);
    }

    this.form = new CustomFormGroup({
      name: new FormControl(this.instance.name),
      description: new FormControl(this.instance.description),
      location: new FormControl(this.instance.location),
      isForRent: new FormControl(this.instance.isForRent),
      rentPricePerDay: new FormControl(this.instance.rentPricePerDay),
      currency: new FormControl(this.instance.currency)
    });
  }

  onSubmit() {
    this.form.submit(async () => {
        let result;
        if (this.isNew) {
          result = await this.vehicleCategoriesService.create(this.form.value);
        } else {
          result = await this.vehicleCategoriesService.update(this.data.id, this.form.value);
        }
        this.dialogRef.close(result);
      }
    );
  }

  close(): void {
    this.dialogRef.close();
  }
}
