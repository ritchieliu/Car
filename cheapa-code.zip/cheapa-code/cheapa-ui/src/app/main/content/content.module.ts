import {NgModule} from '@angular/core';
import {FuseContentComponent} from 'app/main/content/content.component';
import {AppSharedModule} from "../common/appShared.module";

@NgModule({
  declarations: [
    FuseContentComponent
  ],
  imports: [
    AppSharedModule,
  ],
  exports: [
    FuseContentComponent,
    AppSharedModule
  ]
})
export class FuseContentModule {
}
