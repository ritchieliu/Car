import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {VehiclesService} from "../admin/vehicles/vehicles.service";
import {VehicleActionsService} from "../admin/vehicles/vehicles.action.service";
import {GooglePlaceDirective} from "ngx-google-places-autocomplete";
import {Address} from "ngx-google-places-autocomplete/objects/address";
import {ClusterStyle} from "@agm/js-marker-clusterer/services/google-clusterer-types";
import {Router} from "@angular/router";
import {FindCarsImageService} from "./imageDialog/imageDialog.service";
import {environment} from "../../../../environments/environment";

@Component({
  selector: 'findCars',
  templateUrl: './findCars.component.html',
  styleUrls: ['./findCars.component.scss'],
  animations: fuseAnimations
})
export class FindCarsComponent implements OnInit {
  vehicleList: any = [];
  markers: any = [];
  filteredMarkers: any = [];
  mapCenter: any = {
    longitude: 151.2093,
    latitude: -33.8688,
    zoom: 5
  };
  isLoading;
  selectedMarker: any = {};
  agmMarkerClusterStyle: ClusterStyle[] = [
    {
      textColor: '#FFFFFF',
      url: "assets/images/map_cluster1.png",
      height: 53,
      width: 53
    },
    {
      textColor: '#FFFFFF',
      url: "assets/images/map_cluster2.png",
      height: 53,
      width: 53
    }];

  @ViewChild("placesRef", {static: true}) placesRef: GooglePlaceDirective;

  options = {
    types: ['(regions)'],
    componentRestrictions: {country: 'AU'}
  };

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private vehiclesService: VehiclesService,
              public vehicleActionsService: VehicleActionsService,
              private router: Router,
              public findCarsImageService: FindCarsImageService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    await this.getVehicleList();
  }

  async getVehicleList() {
    this.isLoading = true;

    if (environment.production) {
      this.vehicleList = await this.vehiclesService.list('id,location,make,model,color,seatNumber,rentPricePerDay,currency,operationStatus,images,year,deviceStatus', '', '', {operationStatus: 'AVAILABLE', deviceStatus: 'NORMAL', hasLocation: true, nullAccountId: true});
    } else {
      this.vehicleList = await this.vehiclesService.list('id,location,make,model,color,seatNumber,rentPricePerDay,currency,operationStatus,images,year', '', '', {operationStatus: 'AVAILABLE', hasLocation: true, nullAccountId: true});
    }

    this.markers = this.vehicleList.Items;
    this.filteredMarkers = this.markers;
    this.isLoading = false;
  }

  onMarkerClicked(marker) {
    this.selectedMarker = marker;
    marker.opened = true;
  }

  async handleAddressChange(address: Address) {
    let latitude = address.geometry.location.lat();
    let longitude = address.geometry.location.lng();
    this.mapCenter = {
      longitude,
      latitude,
      zoom: 14
    };
  }

  onOrderButtonClick(marker) {
    this.router.navigateByUrl(`/booking?vehicleId=${marker.id}`);
  }
}
