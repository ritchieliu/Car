import {Component, Inject, OnInit} from '@angular/core';



import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {locale as chinese} from "app/i18n/cn";
import {locale as english} from "app/i18n/en";
import {FuseTranslationLoaderService} from "@fuse/services/translation-loader.service";

@Component({
  selector: 'findCars-imageDialog',
  templateUrl: './imageDialog.component.html'
})
export class FindCardImageDialogComponent implements OnInit {
  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              public dialogRef: MatDialogRef<FindCardImageDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
  }

  close(): void {
    this.dialogRef.close();
  }
}
