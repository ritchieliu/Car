import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {AppSharedModule} from "app/main/common/appShared.module";
import {AgmCoreModule} from "@agm/core";
import {environment} from "environments/environment";
import {AgmSnazzyInfoWindowModule} from "@agm/snazzy-info-window";
import {AgmJsMarkerClustererModule} from "@agm/js-marker-clusterer";
import {FindCarsComponent} from "./findCars.component";
import {GooglePlaceModule} from "ngx-google-places-autocomplete";
import {FindCarsImageModule} from "./imageDialog/imageDialog.module";

const routes = [
  {
    canActivate: [],
    path: '',
    component: FindCarsComponent
  }
];

@NgModule({
  declarations: [
    FindCarsComponent
  ],
  entryComponents: [],
  providers: [],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule,
    AgmCoreModule.forRoot({
      apiKey: environment.googleApiKey
    }),
    AgmSnazzyInfoWindowModule,
    AgmJsMarkerClustererModule,
    GooglePlaceModule,
    FindCarsImageModule
  ]
})

export class FindCarsModule {
}
