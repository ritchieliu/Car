import {Injectable} from '@angular/core';
import {MatDialog, MatDialogConfig} from "@angular/material";
import {FindCardImageDialogComponent} from "./imageDialog.component";

@Injectable()
export class FindCarsImageService {

  constructor(private dialog: MatDialog) {
  }

  openDialog(images) {
    let width = (window.screen.width) * 0.5;
    if (window.screen.width < 1024) {
      width = window.screen.width * 0.75;
    }
    if (window.screen.width < 400) {
      width = window.screen.width;
    }
    const dialogRef = this.dialog.open(FindCardImageDialogComponent, <MatDialogConfig>{
      panelClass: 'imageDialogPanel',
      maxWidth: `${width}px`,
      width: `${width}px`,
      height: `${width * 3 / 4}px`,
      data: {images}
    });
  }
}
