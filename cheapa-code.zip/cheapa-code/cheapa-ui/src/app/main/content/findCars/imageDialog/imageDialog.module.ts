import {NgModule} from '@angular/core';

import {AppSharedModule} from "app/main/common/appShared.module";
import {FindCardImageDialogComponent} from "./imageDialog.component";
import {UICarouselModule} from "ui-carousel";
import {FindCarsImageService} from "./imageDialog.service";

@NgModule({
  declarations: [
    FindCardImageDialogComponent
  ],
  entryComponents: [
    FindCardImageDialogComponent
  ],
  providers: [
    FindCarsImageService
  ],
  imports: [
    AppSharedModule,
    UICarouselModule,
  ]
})

export class FindCarsImageModule {
}
