import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {FormControl} from "@angular/forms";
import {CustomFormGroup} from "../../common/form/CustomFormGroup";
import {VehiclesService} from "../admin/vehicles/vehicles.service";
import {ActivatedRoute, Router} from "@angular/router";
import {NgxGalleryImage, NgxGalleryOptions} from "ngx-gallery";
import * as moment from "moment";
import {OrdersService} from "../admin/orders/orders.service";
import {SnackService} from "../../common/snack/snack.service";
import {BookingFeeService} from "../admin/booking/booking.fee.service";

@Component({
  selector: 'booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss'],
  animations: fuseAnimations
})
export class BookingComponent implements OnInit {

  submitting = false;
  errorMessage = null;

  vehicleImageGalleryOptions: NgxGalleryOptions[];
  vehicleGalleryImages: NgxGalleryImage[];

  vehicle: any;
  vehicleId;
  orderForm: CustomFormGroup;
  ageForm: CustomFormGroup;
  insuranceForm: CustomFormGroup;
  confirmForm: CustomFormGroup;
  paymentForm: CustomFormGroup;
  now = moment();

  instance: any = {
    vehicleId: '',
    dropOffDate: moment().add(1, 'day').set({
      minute: 0,
      second: 0
    }),
    dropOffTime: moment().get('hour'),

    driverAge: '25+',

    insurance: 'PREMIUM',

    cardNumber: '',
    expMonth: null,
    expYear: null,
    ccv: null,
    terms: false
  };

  insurances: any = [
    {
      type: 'PREMIUM',
      name: 'Premium Cover',
      price: 19,
      bond: 200,
      help: 'Reduce my damage liability fee (DLF)/ Excess to AUD $200'
    },
    {
      type: 'STANDARD',
      name: 'Standard Cover',
      price: 9,
      bond: 800,
      help: 'Reduce my damage liability fee (DLF)/ Excess to AUD $800'
    },
    {
      type: 'BASIC',
      name: 'Basic Cover',
      price: 0,
      bond: 3300,
      help: 'Reduce my damage liability fee (DLF)/ Excess to AUD $3300'
    }
  ];

  DROP_OFF_HOURS = Array(24).fill(0).map((x, i) => i);

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private vehiclesService: VehiclesService,
              private ordersService: OrdersService,
              private route: ActivatedRoute,
              private router: Router,
              private snackService: SnackService,
              public bookingFeeService: BookingFeeService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);

  }

  async ngOnInit() {

    this.route.queryParams.subscribe(params => {
      this.vehicleId = params['vehicleId'];
    });

    this.orderForm = new CustomFormGroup({
      dropOffDate: new FormControl(this.instance.dropOffDate),
      dropOffTime: new FormControl(this.instance.dropOffTime),
    });
    this.ageForm = new CustomFormGroup({
      driverAge: new FormControl(this.instance.driverAge),
    });
    this.insuranceForm = new CustomFormGroup({
      insurance: new FormControl(this.instance.insurance),
    });
    this.confirmForm = new CustomFormGroup({
      terms: new FormControl(false),
    });
    this.paymentForm = new CustomFormGroup({
      cardHolderName: new FormControl(this.instance.cardHolderName),
      cardNumber: new FormControl(this.instance.cardNumber),
      expMonth: new FormControl(this.instance.expMonth),
      expYear: new FormControl(this.instance.expYear),
      ccv: new FormControl(this.instance.ccv),
    });

    this.vehicle = await this.vehiclesService.getInstance(this.vehicleId);

    this.vehicleImageGalleryOptions = [
      {
        width: '100%',
        height: '400px',
        preview: false,
        imageSwipe: true
      },
      {
        breakpoint: 1440,
        width: '100%',
        height: '350px',
      }
    ];

    if (this.vehicle.images) {
      this.vehicleGalleryImages = this.vehicle.images.map(image => {
        return {
          small: image.smallPath,
          medium: image.path,
          big: image.path,
        }
      });
    }

    this.bookingFeeService.calculateTotalPrice(this.getFeeModel());
  }

  onDropOffDateChange() {
    let dropOffDateControl = this.orderForm.get('dropOffDate');
    dropOffDateControl.updateValueAndValidity();
    dropOffDateControl.value.set({
      hour: this.orderForm.get('dropOffTime').value,
      minute: 0,
      second: 0
    });

    if (dropOffDateControl.value.isBefore(moment())) {
      dropOffDateControl.setErrors({'datePickerMin': true});
    }
    this.bookingFeeService.calculateTotalPrice(this.getFeeModel());
  }

  getFeeModel() {
    return {
      pickUpDate: moment(),
      dropOffDate: this.orderForm.get('dropOffDate').value,
      rentPricePerDay: this.vehicle.rentPricePerDay,
      driverAge: this.ageForm.get('driverAge').value,
      insurance: this.insuranceForm.get('insurance').value,
      discount: 0
    } as any;
  }

  async createOrder() {
    this.submitting = true;
    this.snackService.openSnack('Sending Order... Please wait', this.snackService.IN_PROGRESS_SNACK_CLASS);
    try {
      await this.ordersService.create({
        vehicleId: this.vehicleId,
        pickUpDate: moment().utc().toISOString(),
        dropOffDate: this.orderForm.get('dropOffDate').value.utc().toISOString(),
        driverAge: this.ageForm.get('driverAge').value,
        insurance: this.insuranceForm.get('insurance').value,
        payment: {
          amount: Math.round(this.bookingFeeService.calculateCreditCardCharge(this.getFeeModel()) * 100),
          currency: this.vehicle.currency,
          cardNumber: this.paymentForm.get('cardNumber').value,
          cardExpMonth: this.paymentForm.get('expMonth').value,
          cardExpYear: this.paymentForm.get('expYear').value,
          cardCvc: this.paymentForm.get('ccv').value
        }
      });
    } catch (e) {
      this.submitting = false;
      if (e.status < 500) {
        this.errorMessage = e.error.message;
      } else {
        this.errorMessage = 'Unexpected error. Please contact system admin.';
      }
      throw e;
    }
    this.snackService.openSnack('Payment success', this.snackService.SUCCESS_SNACK_CLASS);
    this.router.navigate(['/orders/active']);
  }
}
