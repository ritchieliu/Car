import {ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {FormControl, Validators} from "@angular/forms";
import {CustomFormGroup} from "../../common/form/CustomFormGroup";
import {VehiclesService} from "../admin/vehicles/vehicles.service";
import {ActivatedRoute, Router} from "@angular/router";
import * as moment from "moment";
import {OrdersService} from "../admin/orders/orders.service";
import {SnackService} from "../../common/snack/snack.service";
import {BookingFeeService} from "../admin/booking/booking.fee.service";
import {VehicleCategoriesService} from "../admin/vehicleCategories/vehicleCategories.service";
import {FusePerfectScrollbarDirective} from "../../../../@fuse/directives/fuse-perfect-scrollbar/fuse-perfect-scrollbar.directive";

@Component({
  selector: 'reserve',
  templateUrl: './reserve.component.html',
  styleUrls: ['./reserve.component.scss'],
  animations: fuseAnimations
})
export class ReserveComponent implements OnInit {

  @ViewChild(FusePerfectScrollbarDirective, {static: true})
  fusePerfectScrollbar?: FusePerfectScrollbarDirective;

  submitting = false;
  errorMessage = null;

  instance: any;
  allVehicleCategoryList;
  vehicleCategoryList;
  selectedVehicleCategory;
  selectedPickUpLocation;
  orderForm: CustomFormGroup;
  vehicleCategoryForm: CustomFormGroup;
  ageForm: CustomFormGroup;
  insuranceForm: CustomFormGroup;
  extraForm: CustomFormGroup;
  contactForm: CustomFormGroup;
  confirmForm: CustomFormGroup;
  now = moment();
  businessPartnerId;

  bookingSuccess = false;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private vehiclesService: VehiclesService,
              private ordersService: OrdersService,
              private route: ActivatedRoute,
              private router: Router,
              private snackService: SnackService,
              public bookingFeeService: BookingFeeService,
              private vehicleCategoriesService: VehicleCategoriesService,
              private cdr: ChangeDetectorRef) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);

  }

  async ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.businessPartnerId = params['b'];
    });

    this.allVehicleCategoryList = (await this.vehicleCategoriesService.list('id,name,rentPricePerDay,currency,location,description,images', '', '', {isForRent: true, hasInsurance: true, hasPricing: true}) as any).Items.sort((a, b) => a.rentPricePerDay - b.rentPricePerDay);
    this.selectedPickUpLocation = this.bookingFeeService.LOCATIONS[0];
    this.vehicleCategoryList = this.allVehicleCategoryList.filter(category => this.selectedPickUpLocation.city === category.location);
    this.selectedVehicleCategory = this.vehicleCategoryList[0];
    this.instance = {
      vehicleCategoryId: this.selectedVehicleCategory.id,
      email: null,
      mobile: null,
      firstName: null,
      lastName: null,
      pickUpDate: moment(this.now).set({
        minute: 0,
        second: 0
      }),
      pickUpHour: moment(this.now).get('hour'),
      pickUpMinute: 0,
      dropOffDate: moment(this.now).add(1, 'day').set({
        minute: 0,
        second: 0
      }),
      dropOffHour: moment(this.now).get('hour'),
      dropOffMinute: 0,
      pickUpLocation: this.selectedPickUpLocation,
      dropOffLocation: this.bookingFeeService.LOCATIONS[0],

      driverAge: false,
      insurance: true,
      roadSideAssistant: false,
      additionalDriver: false,
      childSeatSmall: false,
      childSeatLarge: false,
      gps: false,
      mobilePhoneHolder: false,
      tyreWindscreenCover: false,
      unlimitedDistance: false,
    };

    this.orderForm = new CustomFormGroup({
      pickUpDate: new FormControl(this.instance.pickUpDate),
      pickUpHour: new FormControl(this.instance.pickUpHour),
      pickUpMinute: new FormControl(this.instance.pickUpMinute),
      dropOffDate: new FormControl(this.instance.dropOffDate),
      dropOffHour: new FormControl(this.instance.dropOffHour),
      dropOffMinute: new FormControl(this.instance.dropOffMinute),
      pickUpLocation: new FormControl(this.instance.pickUpLocation),
      dropOffLocation: new FormControl(this.instance.dropOffLocation),
    });
    this.vehicleCategoryForm = new CustomFormGroup({
      vehicleCategoryId: new FormControl(this.selectedVehicleCategory.id)
    });
    this.ageForm = new CustomFormGroup({
      driverAge: new FormControl(this.instance.driverAge),
    });
    this.insuranceForm = new CustomFormGroup({
      insurance: new FormControl(this.instance.insurance),
    });
    this.extraForm = new CustomFormGroup({
      roadSideAssistant: new FormControl(this.instance.roadSideAssistant),
      additionalDriver: new FormControl(this.instance.additionalDriver),
      childSeatSmall: new FormControl(this.instance.childSeatSmall),
      childSeatLarge: new FormControl(this.instance.childSeatLarge),
      gps: new FormControl(this.instance.gps),
      mobilePhoneHolder: new FormControl(this.instance.mobilePhoneHolder),
      tyreWindscreenCover: new FormControl(this.instance.tyreWindscreenCover),
      unlimitedDistance: new FormControl(this.instance.unlimitedDistance),
    });
    this.contactForm = new CustomFormGroup({
      email: new FormControl(this.instance.email, [Validators.email]),
      mobile: new FormControl(this.instance.mobile),
      firstName: new FormControl(this.instance.firstName),
      lastName: new FormControl(this.instance.lastName)
    });
    this.confirmForm = new CustomFormGroup({
      terms: new FormControl(false),
    });

    this.bookingFeeService.calculateTotalPrice(this.getFeeModel());
  }

  onBookingDateChange() {
    let pickUpDateControl = this.orderForm.get('pickUpDate');
    pickUpDateControl.value.set({
      hour: this.orderForm.get('pickUpHour').value,
      minute: this.orderForm.get('pickUpMinute').value,
      second: 0
    });
    let dropOffDateControl = this.orderForm.get('dropOffDate');
    dropOffDateControl.updateValueAndValidity();
    dropOffDateControl.value.set({
      hour: this.orderForm.get('dropOffHour').value,
      minute: this.orderForm.get('dropOffMinute').value,
      second: 0
    });

    if (dropOffDateControl.value.isBefore(pickUpDateControl.value)) {
      dropOffDateControl.setErrors({'datePickerMin': true});
    }
    this.bookingFeeService.calculateTotalPrice(this.getFeeModel());
  }

  onPickUpLocationChange() {
    let pickUpLocationControl = this.orderForm.get('pickUpLocation');
    this.vehicleCategoryList = this.allVehicleCategoryList.filter(vehicleCategory => pickUpLocationControl.value.city === vehicleCategory.location);
    this.vehicleCategoryForm.get('vehicleCategoryId').setValue(this.vehicleCategoryList[0].id);
    this.onVehicleCategoryChange();
  }

  onVehicleCategoryChange() {
    let vehicleCategoryIdControl = this.vehicleCategoryForm.get('vehicleCategoryId');
    this.selectedVehicleCategory = this.allVehicleCategoryList.find(vehicleCategory => vehicleCategory.id === vehicleCategoryIdControl.value);
  }

  getRentDate() {
    return {
      pickUpDate: this.orderForm.get('pickUpDate').value,
      dropOffDate: this.orderForm.get('dropOffDate').value
    }
  }

  getFeeModel() {
    return {
      pickUpDate: this.orderForm.get('pickUpDate').value,
      dropOffDate: this.orderForm.get('dropOffDate').value,
      pickUpLocation: this.orderForm.get('pickUpLocation').value,
      dropOffLocation: this.orderForm.get('dropOffLocation').value,
      rentPricePerDay: this.bookingFeeService.calculateRentPricePerDay({
        pickUpDate: this.orderForm.get('pickUpDate').value,
        dropOffDate: this.orderForm.get('dropOffDate').value,
        pricing: this.selectedVehicleCategory.pricing
      }),
      driverAge: this.ageForm.get('driverAge').value,
      insurance: this.bookingFeeService.calculateInsuranceObject({
        pickUpDate: this.orderForm.get('pickUpDate').value,
        dropOffDate: this.orderForm.get('dropOffDate').value,
        insurance: this.selectedVehicleCategory.insurance,
        insuranceApplied: this.insuranceForm.get('insurance').value,
      }),
      roadSideAssistant: this.extraForm.get('roadSideAssistant').value,
      additionalDriver: this.extraForm.get('additionalDriver').value,
      childSeatSmall: this.extraForm.get('childSeatSmall').value,
      childSeatLarge: this.extraForm.get('childSeatLarge').value,
      gps: this.extraForm.get('gps').value,
      mobilePhoneHolder: this.extraForm.get('mobilePhoneHolder').value,
      tyreWindscreenCover: this.extraForm.get('tyreWindscreenCover').value,
      unlimitedDistance: this.extraForm.get('unlimitedDistance').value,
      discount: 0
    }
  }

  calculateChargeByType({type, applied}) {
    return this.bookingFeeService.calculateChargeByType({
      pickUpDate: this.getFeeModel().pickUpDate,
      dropOffDate: this.getFeeModel().dropOffDate,
      type: type,
      applied: applied
    })
  }

  async createOrder() {
    this.submitting = true;
    this.snackService.openSnack('Sending... Please wait', this.snackService.IN_PROGRESS_SNACK_CLASS);
    try {
      await this.ordersService.booking({
        pickUpDate: this.orderForm.get('pickUpDate').value.utc().toISOString(),
        dropOffDate: this.orderForm.get('dropOffDate').value.utc().toISOString(),
        pickUpLocation: {
          name: this.orderForm.get('pickUpLocation').value.name,
          city: this.orderForm.get('pickUpLocation').value.city
        },
        dropOffLocation: {
          name: this.orderForm.get('dropOffLocation').value.name,
          city: this.orderForm.get('dropOffLocation').value.city,
        },
        vehicleCategoryId: this.vehicleCategoryForm.get('vehicleCategoryId').value,
        driverAge: this.ageForm.get('driverAge').value,
        insurance: this.insuranceForm.get('insurance').value,
        roadSideAssistant: this.extraForm.get('roadSideAssistant').value,
        additionalDriver: this.extraForm.get('additionalDriver').value,
        childSeatSmall: this.extraForm.get('childSeatSmall').value,
        childSeatLarge: this.extraForm.get('childSeatLarge').value,
        gps: this.extraForm.get('gps').value,
        mobilePhoneHolder: this.extraForm.get('mobilePhoneHolder').value,
        tyreWindscreenCover: this.extraForm.get('tyreWindscreenCover').value,
        unlimitedDistance: this.extraForm.get('unlimitedDistance').value,
        email: this.contactForm.get('email').value,
        firstName: this.contactForm.get('firstName').value,
        lastName: this.contactForm.get('lastName').value,
        mobile: this.contactForm.get('mobile').value,
        source: 'platform',
        discount: 0,
        businessPartnerId: this.businessPartnerId
      });
    } catch (e) {
      this.submitting = false;
      if (e.status < 500) {
        this.errorMessage = e.error.message;
      } else {
        this.errorMessage = 'Unexpected error. Please contact system admin.';
      }
      throw e;
    }
    this.snackService.openSnack('Booking success', this.snackService.SUCCESS_SNACK_CLASS);
    this.bookingSuccess = true;
    this.fusePerfectScrollbar.scrollToTop();
  }
}
