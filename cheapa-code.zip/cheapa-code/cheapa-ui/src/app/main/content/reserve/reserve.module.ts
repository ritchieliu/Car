import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {AppSharedModule} from "app/main/common/appShared.module";
import {AgmCoreModule} from "@agm/core";
import {environment} from "environments/environment";
import {UICarouselModule} from "ui-carousel";
import {ReserveComponent} from "./reserve.component";
import {NgxGalleryModule} from "ngx-gallery";
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from "@angular/material";
import {MomentDateAdapter} from "@angular/material-moment-adapter";

const routes = [
  {
    path: '',
    component: ReserveComponent
  }
];

@NgModule({
  declarations: [
    ReserveComponent
  ],
  entryComponents: [],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {
      provide: MAT_DATE_FORMATS, useValue: {
        parse: {
          dateInput: 'DD/MM/YYYY',
        },
        display: {
          dateInput: 'DD/MM/YYYY',
          monthYearLabel: 'MMM YYYY',
          dateA11yLabel: 'DD/MM/YYYY',
          monthYearA11yLabel: 'MMMM YYYY',
        },
      }
    },
  ],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule,
    AgmCoreModule.forRoot({
      apiKey: environment.googleApiKey
    }),
    UICarouselModule,
    NgxGalleryModule,
  ]
})

export class ReserveModule {
}
