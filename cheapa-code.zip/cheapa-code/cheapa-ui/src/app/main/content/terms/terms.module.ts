import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {AppSharedModule} from "app/main/common/appShared.module";
import {TermsComponent} from "./terms.component";

const routes = [
  {
    path: '',
    component: TermsComponent
  }
];

@NgModule({
  declarations: [
    TermsComponent
  ],
  entryComponents: [],
  providers: [],
  imports: [
    RouterModule.forChild(routes),
    AppSharedModule,
  ]
})

export class TermsModule {
}
