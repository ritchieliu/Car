import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";

@Component({
  selector: 'terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.scss'],
  animations: fuseAnimations
})
export class TermsComponent implements OnInit {

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);

  }

  async ngOnInit() {
  }
}
