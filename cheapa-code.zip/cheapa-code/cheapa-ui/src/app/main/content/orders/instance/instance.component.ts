import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {ActivatedRoute} from "@angular/router";
import {OrdersService} from "../../admin/orders/orders.service";
import {AccountsService} from "../../../accounts/accounts.service";
import {VehiclesService} from "../../admin/vehicles/vehicles.service";
import {SignaturePad} from "angular2-signaturepad/signature-pad";
import {SnackService} from "../../../common/snack/snack.service";
import {DevicesService} from "../../admin/devices/devices.service";
import {DeviceService} from "../../../common/device/device.service";

@Component({
  selector: 'order-instance',
  templateUrl: './instance.component.html',
  styleUrls: ['./instance.component.scss'],
  animations: fuseAnimations
})
export class OrderInstanceComponent implements OnInit {
  instance: any = {};
  vehicle;
  createdAt;
  isLoading;
  isSignatureSubmitting = false;
  startSignature = false;

  @ViewChild(SignaturePad, {static: false}) signaturePad: SignaturePad;

  signaturePadOptions;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private ordersService: OrdersService,
              private vehiclesService: VehiclesService,
              private accountsService: AccountsService,
              private snackService: SnackService,
              private route: ActivatedRoute,
              private deviceService: DeviceService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);

    if (this.deviceService.isMobile()) {
      this.signaturePadOptions = {
        'minWidth': 1,
        'canvasWidth': 250,
        'canvasHeight': 200
      };
    } else {
      this.signaturePadOptions = {
        'minWidth': 1,
        'canvasWidth': 400,
        'canvasHeight': 200
      };
    }
  }

  async ngOnInit() {
    await this.route.params.subscribe(params => {
      this.createdAt = params['createdAt'];
    });

    this.isLoading = true;
    this.instance = await this.ordersService.getInstance(this.accountsService.getUser().id, this.createdAt);

    if (this.instance.vehicleId) {
      this.vehicle = await this.vehiclesService.getInstance(this.instance.vehicleId);
    }

    this.isLoading = false;
  }

  ngAfterViewInit() {
    this.signaturePad.clear();
  }

  clearSignature() {
    this.signaturePad.clear();
  }

  startSigning() {
    this.startSignature = true;
  }

  async saveSignature() {
    this.isSignatureSubmitting = true;
    await this.ordersService.createSignature(this.instance.accountId, this.instance.createdAt, {body: this.signaturePad.toDataURL()});
    this.snackService.openSnack('Signature Submitted', this.snackService.SUCCESS_SNACK_CLASS);
    this.isSignatureSubmitting = false;
    await this.ngOnInit();
  }

}
