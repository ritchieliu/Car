import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations/index';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {ActivatedRoute, Router} from "@angular/router";
import {OrdersService} from "../../admin/orders/orders.service";
import {AccountsService} from "../../../accounts/accounts.service";
import {ImageUploadService} from "../../../common/imageUpload/imageUpload.service";
import {SnackService} from "../../../common/snack/snack.service";

@Component({
  selector: 'order-return',
  templateUrl: './return.component.html',
  styleUrls: ['./return.component.scss'],
  animations: fuseAnimations
})
export class OrderReturnComponent implements OnInit {
  isLoadingOrder;
  isSubmitting;
  instance;

  isReturnedToLocation = true;
  isClean = true;
  isFullFuel = true;
  imageUploadServiceFrontRight: any;
  imageUploadServiceFrontLeft: any;
  imageUploadServiceBackLeft: any;
  imageUploadServiceBackRight: any;
  imageUploadServiceDashboard: any;
  imageUploadServiceKey: any;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private route: ActivatedRoute,
              public ordersService: OrdersService,
              private accountsService: AccountsService,
              public imageUploadService: ImageUploadService,
              private router: Router,
              private snackService: SnackService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.imageUploadServiceFrontRight = this.imageUploadService.getInstance();
    this.imageUploadServiceFrontLeft = this.imageUploadService.getInstance();
    this.imageUploadServiceBackLeft = this.imageUploadService.getInstance();
    this.imageUploadServiceBackRight = this.imageUploadService.getInstance();
    this.imageUploadServiceDashboard = this.imageUploadService.getInstance();
    this.imageUploadServiceKey = this.imageUploadService.getInstance();
    this.route.queryParams.subscribe(async params => {
      await this.getOrder(params['orderCreatedAt']);

      if (this.instance.status !== 'ACTIVE') {
        this.router.navigateByUrl('/orders/active');
      }

      this.imageUploadServiceFrontRight.initUploadedFiles(this.instance.vehicleImages.FRONT_RIGHT);
      this.imageUploadServiceFrontLeft.initUploadedFiles(this.instance.vehicleImages.FRONT_LEFT);
      this.imageUploadServiceBackLeft.initUploadedFiles(this.instance.vehicleImages.BACK_LEFT);
      this.imageUploadServiceBackRight.initUploadedFiles(this.instance.vehicleImages.BACK_RIGHT);
      this.imageUploadServiceDashboard.initUploadedFiles(this.instance.vehicleImages.DASHBOARD);
      this.imageUploadServiceKey.initUploadedFiles(this.instance.vehicleImages.KEY);
    });
  }

  async getOrder(orderCreatedAt) {
    this.isLoadingOrder = true;
    this.instance = await this.ordersService.getInstance(this.accountsService.getUser().id, orderCreatedAt);
    if (!this.instance.vehicleImages) {
      this.instance.vehicleImages = {};
    }
    this.isLoadingOrder = false;
  }

  getImageUploadRequest(type) {
    return async (result) => {
      let image = await this.ordersService.createVehicleImage(this.instance.accountId, this.instance.createdAt, {body: result, type: type});
      this.instance.vehicleImages[type] = image;
      return image;
    }
  }

  async deleteVehicleImage($event, imageService, type) {
    await imageService.onRemoved($event, this.ordersService.deleteVehicleImage(this.instance.accountId, this.instance.createdAt, type));
    delete this.instance.vehicleImages[type];
  }

  async confirmReturn() {
    this.isSubmitting = true;
    await this.snackService.openSnack('Your car is returning', this.snackService.IN_PROGRESS_SNACK_CLASS);
    await this.ordersService.confirmReturn(this.instance.createdAt, {
      isReturnedToLocation: this.isReturnedToLocation,
      isClean: this.isClean,
      isFullFuel: this.isFullFuel
    });
    await this.snackService.openSnack('Your car has been returned.', this.snackService.SUCCESS_SNACK_CLASS);
    this.isSubmitting = false;
    this.router.navigateByUrl('/orders/complete?createdAt=' + this.instance.createdAt);
  }
}
