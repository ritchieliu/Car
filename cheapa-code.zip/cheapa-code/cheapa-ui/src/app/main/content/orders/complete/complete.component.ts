import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations/index';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {VehiclesService} from "../../admin/vehicles/vehicles.service";
import {ActivatedRoute} from "@angular/router";
import {OrdersService} from "../../admin/orders/orders.service";
import {AccountsService} from "../../../accounts/accounts.service";
import {VehicleActionsService} from "../../admin/vehicles/vehicles.action.service";

@Component({
  selector: 'order-complete',
  templateUrl: './complete.component.html',
  styleUrls: ['./complete.component.scss'],
  animations: fuseAnimations
})
export class OrderCompleteComponent implements OnInit {

  orderCreatedAt;
  order: any;
  vehicle: any;
  isLoading;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private ordersService: OrdersService,
              private accountsService: AccountsService,
              private vehiclesService: VehiclesService,
              public vehicleActionsService: VehicleActionsService,
              private route: ActivatedRoute,) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.orderCreatedAt = params['createdAt'];
    });
    this.isLoading = true;
    this.order = await this.ordersService.getInstance(this.accountsService.getUser().accountId, this.orderCreatedAt);
    this.vehicle = await this.vehiclesService.getInstance(this.order.vehicleId);
    this.isLoading = false;
  }

  async onDeviceActionOpenDoor(vehicle) {
    this.vehicle.openDoorButtonSubmitting = true;
    await this.vehicleActionsService.openDoor(vehicle, this.order.createdAt);
    this.vehicle.openDoorButtonSubmitting = false;
  }

  async onDeviceActionCloseDoor(vehicle) {
    this.vehicle.closeDoorButtonSubmitting = true;
    await this.vehicleActionsService.closeDoor(vehicle, this.order.createdAt);
    this.vehicle.closeDoorButtonSubmitting = false;
  }

}
