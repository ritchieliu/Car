import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {AccountsCanActivateClient} from "app/main/accounts/accounts.canActivateClient";
import {AppSharedModule} from "app/main/common/appShared.module";
import {OrderListComponent} from "./list/list.component";
import {OrderActiveComponent} from "./active/active.component";
import {environment} from "../../../../environments/environment";
import {AgmCoreModule} from "@agm/core";
import {AgmSnazzyInfoWindowModule} from "@agm/snazzy-info-window";
import {ImageUploadModule} from "angular2-image-upload";
import {Ng2ImgMaxModule, Ng2ImgMaxService} from "ng2-img-max";
import {OrderReturnComponent} from "./return/return.component";
import {OrderCompleteComponent} from "./complete/complete.component";
import {FindCarsImageModule} from "../findCars/imageDialog/imageDialog.module";
import {ImageUploadService} from "../../common/imageUpload/imageUpload.service";
import {OrderInstanceComponent} from "./instance/instance.component";
import {SignaturePadModule} from "angular2-signaturepad";

const routes = [
  {
    canActivate: [AccountsCanActivateClient],
    path: 'active',
    component: OrderActiveComponent
  },
  {
    canActivate: [AccountsCanActivateClient],
    path: 'return',
    component: OrderReturnComponent
  },
  {
    canActivate: [AccountsCanActivateClient],
    path: 'complete',
    component: OrderCompleteComponent
  },
  {
    canActivate: [AccountsCanActivateClient],
    path: 'list',
    component: OrderListComponent
  },
  {
    canActivate: [AccountsCanActivateClient],
    path: 'list/:createdAt',
    component: OrderInstanceComponent
  }
];

@NgModule({
  declarations: [
    OrderActiveComponent,
    OrderReturnComponent,
    OrderCompleteComponent,
    OrderListComponent,
    OrderInstanceComponent
  ],
  entryComponents: [],
  providers: [
    ImageUploadService,
    Ng2ImgMaxService
  ],
  imports: [
    RouterModule.forChild(routes),
    AgmCoreModule.forRoot({
      apiKey: environment.googleApiKey
    }),
    AgmSnazzyInfoWindowModule,
    ImageUploadModule.forRoot(),
    Ng2ImgMaxModule,
    AppSharedModule,
    FindCarsImageModule,
    SignaturePadModule
  ],
  exports: [
    OrderListComponent,
    OrderReturnComponent,
    OrderCompleteComponent,
  ]
})

export class OrdersModule {
}
