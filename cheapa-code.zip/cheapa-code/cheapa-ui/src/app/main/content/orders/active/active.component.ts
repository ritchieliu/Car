import {Component, OnInit} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {VehiclesService} from "app/main/content/admin/vehicles/vehicles.service";
import {OrdersService} from "app/main/content/admin/orders/orders.service";
import {VehicleActionsService} from "app/main/content/admin/vehicles/vehicles.action.service";
import {AccountsService} from "../../../accounts/accounts.service";
import {FormControl} from "@angular/forms";
import {CustomFormGroup} from "../../../common/form/CustomFormGroup";
import {ImageUploadService} from "../../../common/imageUpload/imageUpload.service";
import {Router} from "@angular/router";
import {FindCarsImageService} from "../../findCars/imageDialog/imageDialog.service";

@Component({
  selector: 'active',
  templateUrl: './active.component.html',
  styleUrls: ['./active.component.scss'],
  animations: fuseAnimations
})
export class OrderActiveComponent implements OnInit {
  orderList: any = [];
  activeOrder: any = {};
  hasActiveOrder: boolean = null;
  vehicle: any = {};
  markers: any = [];
  isLoading;

  loadAccountForm;
  accountForm: CustomFormGroup;

  account: any = {
    given_name: this.accountsService.getUser().given_name,
    family_name: this.accountsService.getUser().family_name,
    phone_number: this.accountsService.getUser().phone_number
  };

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private vehiclesService: VehiclesService,
              private ordersService: OrdersService,
              public vehicleActionsService: VehicleActionsService,
              public accountsService: AccountsService,
              public imageUploadService: ImageUploadService,
              private router: Router,
              public findCarsImageService: FindCarsImageService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  async ngOnInit() {
    await this.getOrderList();
  }

  async getOrderList() {
    this.isLoading = true;
    this.orderList = await this.ordersService.list('accountId,vehicleId,email,createdAt,pickUpDate,dropOffDate,payment,status,pickUpLocation,dropOffLocation,firstName,lastName,mobile,driverLicenses', 10, '', {descending: true});
    if (this.orderList.Items.length > 0) {
      this.activeOrder = this.orderList.Items.find(order => order.status === 'ACTIVE');
      if (this.activeOrder) {
        this.hasActiveOrder = true;

        let firstName = this.account.given_name || this.activeOrder.firstName;
        let lastName = this.account.family_name || this.activeOrder.lastName;
        let mobile = this.account.phone_number || this.activeOrder.mobile;
        if (!firstName
          || !lastName
          || !mobile
          || !this.activeOrder.driverLicenses
          || this.activeOrder.driverLicenses.length < 2) {
          this.accountForm = new CustomFormGroup({
            given_name: new FormControl(this.account.given_name || this.activeOrder.firstName),
            family_name: new FormControl(this.account.family_name || this.activeOrder.lastName),
            phone_number: new FormControl(this.account.phone_number || this.activeOrder.mobile)
          });

          this.imageUploadService.initUploadedFiles(this.activeOrder.driverLicenses);
          this.loadAccountForm = true;
        }

        this.vehicle = await this.vehiclesService.getInstance(this.activeOrder.vehicleId);
        this.markers = [this.vehicle];
      } else if (this.orderList.Items[0].status === 'VEHICLE_RETURNED') {
        this.router.navigateByUrl('/orders/complete?createdAt=' + this.orderList.Items[0].createdAt);
      } else {
        this.hasActiveOrder = false;
      }
    } else {
      this.hasActiveOrder = false;
    }
    this.isLoading = false;
  }

  async onDeviceActionOpenDoor(vehicle) {
    this.vehicle.openDoorButtonSubmitting = true;
    await this.vehicleActionsService.openDoor(vehicle, this.activeOrder.createdAt);
    this.vehicle.openDoorButtonSubmitting = false;
  }

  async onDeviceActionCloseDoor(vehicle) {
    this.vehicle.closeDoorButtonSubmitting = true;
    await this.vehicleActionsService.closeDoor(vehicle, this.activeOrder.createdAt);
    this.vehicle.closeDoorButtonSubmitting = false;
  }

  async onReturnCar(order) {
    this.router.navigateByUrl(`/orders/return?orderCreatedAt=${order.createdAt}`);
  }

  getImageUploadRequest() {
    return async (result) => {
      let response: any = await this.ordersService.createDriverLicense(this.activeOrder.accountId, this.activeOrder.createdAt, {body: result});
      if (!this.activeOrder.driverLicenses) {
        this.activeOrder.driverLicenses = [];
      }
      this.activeOrder.driverLicenses.push(response);
      return response;
    }
  }

  async onRemoved($event) {
    this.activeOrder.driverLicenses = this.activeOrder.driverLicenses.filter(item => {
      return item.key !== $event.file.name
    })
    await this.imageUploadService.onRemoved($event, this.ordersService.deleteDriverLicense(this.activeOrder.accountId, this.activeOrder.createdAt, $event.file.name));
  }

  accountFormSubmit() {
    this.accountForm.submit(async () => {
        let response: any = await this.accountsService.update(this.activeOrder.accountId, this.accountForm.value);
        this.accountsService.setIdToken(response.IdToken);
        this.loadAccountForm = false;
      }
    );
  }
}
