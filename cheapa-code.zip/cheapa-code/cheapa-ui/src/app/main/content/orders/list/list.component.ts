import {Component, OnInit, ViewChild} from '@angular/core';

import {FuseTranslationLoaderService} from '@fuse/services/translation-loader.service';

import {fuseAnimations} from '@fuse/animations';
import {DatatableComponent} from "@swimlane/ngx-datatable";
import {ListModel} from "app/main/common/list/ListModel";
import {locale as english} from "app/i18n/en";
import {locale as chinese} from "app/i18n/cn";
import {OrdersService} from "app/main/content/admin/orders/orders.service";
import {MatDialog, MatDialogConfig} from "@angular/material";
import {Platform} from "@angular/cdk/platform";
import {DeviceService} from "../../../common/device/device.service";

@Component({
  selector: 'order-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  animations: fuseAnimations
})
export class OrderListComponent implements OnInit {
  @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
  list: ListModel;

  constructor(private fuseTranslationLoader: FuseTranslationLoaderService,
              private ordersService: OrdersService,
              private dialog: MatDialog,
              public deviceService: DeviceService) {
    this.fuseTranslationLoader.loadTranslations(english, chinese);
  }

  ngOnInit() {
    this.list = new ListModel(this.table, 'accountId,vehicleId,email,createdAt,pickUpDate,dropOffDate,payment,status,vehicleCategoryName', ['createdAt', 'vehicleId', 'pickUpDate', 'dropOffDate']);
    this.getList('');
  }

  getList(listStartKey) {
    this.list.getList(async () => {
        return await this.ordersService.list(this.list.attributes, this.list.pageSize, listStartKey);
      }
    );
  }
}
