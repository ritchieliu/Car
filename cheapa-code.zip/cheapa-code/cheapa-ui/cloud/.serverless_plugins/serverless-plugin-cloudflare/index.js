'use strict'

const Bb = require('bluebird')
const cloudflareService = require('../../modules/cloud/lib/cloudflareService')
const ServerlessUtil = require('../../modules/cloud/lib/ServerlessUtil')
const CloudFrontService = require('../../modules/cloud/lib/CloudFrontService')

class ServerlessPlugin {
  constructor (serverless, options) {
    this.serverless = serverless
    this.options = options

    this.commands = {
      deploy: {
        usage: 'Deploy to S3 and create CNAME in cloudflare',
        lifecycleEvents: [],
        options: {},
      },
    }

    this.hooks = {
      'after:deploy:deploy': () => Bb.bind(this).then(this.afterDeploy)
    }
  }

  async afterDeploy () {
    const cloudFlare = this.serverless.service.custom.cloudflare
    const profile = this.serverless.service.provider.profile
    const region = this.serverless.service.provider.region

    let stack = await ServerlessUtil.fetchCloudFormationStack(this.serverless)
    await cloudflareService.syncDNSToCloudFlare(cloudFlare, 'CNAME', stack.domainName, stack.cloudfrontdistributionDomainName)
    await CloudFrontService.invalidate(profile, region, stack.cloudfrontdistributionId)
  }
}

module.exports = ServerlessPlugin
