'use strict'

const path = require('path')

module.exports.getModuleName = () => {
  let folders = __dirname.split(path.sep)
  return folders[folders.length - 2]
}
