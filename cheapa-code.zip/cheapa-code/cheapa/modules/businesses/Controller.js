import ApiLambdaHandler from '../lib/lambda/ApiLambdaHandler'
import { BusinessService } from './Service'

const runner = {
  '/businesses': {},
  '/businesses/{id}': {}
}

runner['/businesses'].GET = async (request) => {
  if (request.isAdmin) {
    return BusinessService.getAll(request.q)
  }
}

runner['/businesses/{id}'].GET = async (request) => {
  if (request.isAdmin) {
    return BusinessService.getInstance(request.path.id)
  }

  if (request.isPartner) {
    return BusinessService.getInstanceByEmail(request.authorizer.email)
  }
}

runner['/businesses'].POST = async (request) => {
  if (request.isAdmin) {
    return BusinessService.create(request.body)
  }
}

runner['/businesses/{id}'].PUT = async (request) => {
  if (request.isAdmin) {
    return BusinessService.update(request.path.id, request.body)
  }
}

runner['/businesses/{id}'].DELETE = async (request) => {
  if (request.isAdmin) {
    return BusinessService.delete(request.path.id)
  }
}

module.exports.handler = ApiLambdaHandler(runner)
