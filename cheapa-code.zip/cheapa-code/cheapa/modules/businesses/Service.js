import Exception from '../lib/Exception'
import JoiUtil from '../lib/util/JoiUtil'
import { BusinessRepo } from './Repo'
import { BusinessSchema } from './Schema'
import UuidUtil from '../lib/util/UuidUtil'
import PaymentService from '../lib/payment/PaymentService'

const repo = new BusinessRepo()

export class BusinessService {
  static async getAll (q) {
    return repo.getAll(q)
  }

  static async getInstance (id) {
    let instance = await repo.getInstance(id)
    if (!instance) {
      throw Exception.notFound()
    }
    return instance
  }

  static async getInstanceByEmail (email) {
    let instance = await repo.getAll({email: email, express: 'id,email'})
    if (!instance || !instance.Items[0]) {
      throw Exception.notFound()
    }
    return instance.Items[0]
  }

  static async create (body) {
    JoiUtil.validate(body, BusinessSchema.getViewSchema())
    body.id = UuidUtil.get()

    if (body.routingNumber || body.accountNumber) {
      let stripeAccount = await PaymentService.createAccount(process.env.LAMBDA_PAYMENT_FUNCTION_ARN, {
        country: body.country,
        email: body.email,
        business_name: body.name,
        currency: body.currency,
        external_account: {
          routing_number: body.routingNumber,
          account_number: body.accountNumber
        }
      })
      body.stripeAccountId = stripeAccount.id
    }

    return repo.create(body)
  }

  static async update (id, body) {
    JoiUtil.validate(body, BusinessSchema.getViewSchema())
    let instance = await this.getInstance(id)

    if (body.routingNumber || body.accountNumber) {
      await PaymentService.updateAccount(process.env.LAMBDA_PAYMENT_FUNCTION_ARN, {
        stripeAccountId: instance.stripeAccountId,
        country: body.country,
        email: body.email,
        business_name: body.name,
        currency: body.currency,
        external_account: {
          routing_number: body.routingNumber,
          account_number: body.accountNumber
        }
      })
    }

    return repo.update(Object.assign(instance, body))
  }

  static async delete (id) {
    await this.getInstance(id)
    return repo.destroy(id)
  }
}
