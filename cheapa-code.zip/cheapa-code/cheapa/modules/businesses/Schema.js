import Joi from 'joi'

export class BusinessSchema {
  static getDynamoSchema () {
    return Joi.object().keys({
      id: Joi.string().required(),
      name: Joi.string().required(),
      email: Joi.string().required(),
      mobile: Joi.string().allow('', null),
      country: Joi.string().required(),
      currency: Joi.string().required(),
      routingNumber: Joi.string().allow('', null),
      accountNumber: Joi.string().allow('', null),
      commissionRate: Joi.number().allow(null),
      stripeAccountId: Joi.string().allow('', null),
      createdAt: Joi.date().iso().required(),
      updatedAt: Joi.date().iso()
    })
  }

  static getViewSchema () {
    return Joi.object().keys({
      name: Joi.string().required(),
      email: Joi.string().required(),
      mobile: Joi.string().allow('', null),
      country: Joi.string().required(),
      currency: Joi.string().required(),
      routingNumber: Joi.string().allow('', null),
      accountNumber: Joi.string().allow('', null),
      commissionRate: Joi.number().allow(null)
    })
  }
}
