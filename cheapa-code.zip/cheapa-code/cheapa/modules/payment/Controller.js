import LambdaHandler from '../lib/lambda/LambdaHandler'
import Service from './Service'

const runner = {
  '/charges': {},
  '/charges/capture': {},
  '/refund': {},
  '/cards': {},
  '/accounts': {}
}

runner['/charges'].POST = async (request) => {
  return Service.charge(request.body)
}

runner['/charges/capture'].POST = async (request) => {
  return Service.captureCharge(request.body)
}

runner['/refund'].POST = async (request) => {
  return Service.refund(request.body)
}

runner['/cards'].GET = async (request) => {
  return Service.getCards(request.body)
}

runner['/cards'].POST = async (request) => {
  return Service.createCard(request.body)
}

runner['/cards'].DELETE = async (request) => {
  return Service.deleteCards(request.body)
}

runner['/accounts'].POST = async (request) => {
  return Service.createAccount(request.body)
}

runner['/accounts'].PUT = async (request) => {
  return Service.updateAccount(request.body)
}

module.exports.handler = LambdaHandler(runner)
