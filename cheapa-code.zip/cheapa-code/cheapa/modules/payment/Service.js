import stripePackage from 'stripe'
import DateUtil from '../lib/util/DateUtil'

const stripe = stripePackage(process.env.STRIPE_SECRET_KEY)

export default class Service {
  static async charge (body) {
    let customer
    if (!body.stripeCustomerId) {
      customer = await stripe.customers.create({
        email: body.email
      })
    } else {
      customer = await stripe.customers.retrieve(body.stripeCustomerId)
    }

    let card
    if (!body.stripeCardId) {
      card = await this.createCard({
        stripeCustomerId: customer.id,
        card: body.card
      })
    } else {
      card = await this.getCard({
        stripeCustomerId: customer.id,
        stripeCardId: body.stripeCardId
      })
    }

    let charge = await stripe.charges.create({
      amount: body.amount,
      currency: body.currency,
      description: body.description,
      customer: customer.id,
      source: card.id,
      statement_descriptor: body.statement_descriptor.substring(0, 22),
      receipt_email: body.receipt_email,
      destination: body.destination,
      capture: false
    })
    return charge
  }

  static async captureCharge (body) {
    let charge = await stripe.charges.capture(body.stripeChargeId, {
      amount: body.amount
    })
    return charge
  }

  static async refund (body) {
    let charge = await stripe.refunds.create({charge: body.stripeChargeId})
    return charge
  }

  static async getCards (body) {
    return stripe.customers.listCards(body.stripeCustomerId)
  }

  static async getCard (body) {
    return stripe.customers.retrieveCard(body.stripeCustomerId, body.stripeCardId)
  }

  static async createCard (body) {
    let token = await stripe.tokens.create({
      card: body.card
    })

    return stripe.customers.createSource(body.stripeCustomerId, {
      source: token.id
    })
  }

  static async deleteCards (body) {
    return stripe.customers.deleteCard(body.stripeCustomerId, body.stripeCardId)
  }

  static async createAccount (body) {
    return stripe.accounts.create({
      type: 'custom',
      country: body.country,
      email: body.email,
      business_name: body.business_name,
      external_account: {
        object: 'bank_account',
        country: body.country,
        currency: body.currency,
        routing_number: body.external_account.routing_number,
        account_number: body.external_account.account_number
      },
      tos_acceptance: {
        date: Math.floor(DateUtil.now().valueOf() / 1000),
        ip: '0.0.0.0'
      }
    })
  }

  static async updateAccount (body) {
    return stripe.accounts.update(body.stripeAccountId, {
      email: body.email,
      business_name: body.business_name,
      external_account: {
        object: 'bank_account',
        country: body.country,
        currency: body.currency,
        routing_number: body.external_account.routing_number,
        account_number: body.external_account.account_number
      }
    })
  }
}
