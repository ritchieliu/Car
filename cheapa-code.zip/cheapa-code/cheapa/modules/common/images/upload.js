import * as Jimp from 'jimp'
import ImageService from '../../lib/image/ImageService'
import S3Service from '../../lib/s3/S3Service'

// await LambdaService.invoke({
//   FunctionName: process.env.IMAGE_UPLOAD_FUNCTION_ARN,
//   InvocationType: 'RequestResponse',
//   Payload: JSON.stringify({
//     key: fileName,
//     imageBody: body.body
//   })
// })
//
// await LambdaService.invoke({
//   FunctionName: process.env.IMAGE_UPLOAD_FUNCTION_ARN,
//   InvocationType: 'Event',
//   Payload: JSON.stringify({
//     key: smallFileName,
//     srcImageKey: fileName,
//     resize: {
//       width: -1,
//       height: 150
//     }
//   })
// })
module.exports.handler = async (event, context, done) => {
  try {
    let buffer
    if (event.srcImageKey) {
      buffer = (await S3Service.getFile({
        Bucket: process.env.IMAGE_BUCKET,
        Key: event.srcImageKey
      })).Body
    } else if (event.imageBody) {
      buffer = Buffer.from(event.imageBody.replace(/^data:.*;base64,/, ''), 'base64')
    }

    if (event.resize) {
      buffer = await ImageService.resize(buffer, event.resize.width, event.resize.height, Jimp.MIME_JPEG)
    }
    await S3Service.uploadFile({
      Bucket: process.env.IMAGE_BUCKET,
      Key: event.key,
      Body: buffer,
      ContentEncoding: 'base64',
      ContentType: 'image/jpeg',
      ACL: 'public-read'
    })
    return done(null, {})
  } catch (error) {
    console.log(error)
    return done(error)
  }
}
