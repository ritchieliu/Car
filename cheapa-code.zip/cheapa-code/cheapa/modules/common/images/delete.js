import S3Service from '../../lib/s3/S3Service'

// await LambdaService.invoke({
//   FunctionName: process.env.IMAGE_DELETE_FUNCTION_ARN,
//   InvocationType: 'Event',
//   Payload: JSON.stringify({
//     key: image.key
//   })
// })
module.exports.handler = async (event, context, done) => {
  try {
    await S3Service.deletedFile({
      Bucket: process.env.IMAGE_BUCKET,
      Key: event.key
    })

    return done(null, {})
  } catch (error) {
    console.log(error)
    return done(error)
  }
}
