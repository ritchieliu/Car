'use strict'

const Bb = require('bluebird')
const AWS = require('aws-sdk')

module.exports = {
  setup (profile, domain, certificateBody, certificatePrivateKey, certificateChain, region) {
    AWS.config.credentials = new AWS.SharedIniFileCredentials({profile: profile})
    AWS.config.region = region
    const acm = new AWS.ACM()

    return get()
      .then(importCertificate)

    function get () {
      return new Bb((resolve, reject) => {
        let params = {
          CertificateStatuses: [
            'PENDING_VALIDATION', 'ISSUED', 'INACTIVE', 'EXPIRED', 'VALIDATION_TIMED_OUT', 'REVOKED', 'FAILED'
          ],
          MaxItems: 100
        }
        return acm.listCertificates(params, function (err, data) {
          if (err) {
            console.log(err, err.stack)
            reject(err)
          }
          resolve(data)
        })
      }).then(certificates => certificates.CertificateSummaryList.filter(c => c.DomainName === `*.${domain}`)[0])
    }

    function importCertificate (certificate) {
      if (certificate) {
        return certificate.CertificateArn
      }

      return new Bb((resolve, reject) => {
        let params = {
          Certificate: certificateBody,
          PrivateKey: certificatePrivateKey,
          CertificateChain: certificateChain
        }
        return acm.importCertificate(params, function (err, data) {
          if (err) {
            console.log(err, err.stack)
            reject(err)
          }
          resolve(data)
        })
      }).then(data => {
        return data.CertificateArn
      })
    }
  }
}
