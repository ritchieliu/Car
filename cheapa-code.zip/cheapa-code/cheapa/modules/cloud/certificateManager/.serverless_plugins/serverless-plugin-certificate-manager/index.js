'use strict'

const Bb = require('bluebird')
const CertificateManagerSetup = require('./setup')

class ServerlessPlugin {
  constructor (serverless, options) {
    this.serverless = serverless
    this.options = options

    this.commands = {
      deploy: {
        usage: 'Deploy Certificate Manager',
        lifecycleEvents: [],
        options: {}
      }
    }

    this.hooks = {
      'before:aws:package:finalize:mergeCustomProviderResources': () => Bb.bind(this).then(this.beforePackage)
    }
  }

  beforePackage () {
    const certificateManager = this.serverless.service.custom.certificateManager
    const profile = this.serverless.service.provider.profile
    // region has to be us-east-1
    const region = 'us-east-1'

    return Bb.resolve()
      .then(() => {
        return CertificateManagerSetup.setup(profile, certificateManager.domain, certificateManager.certificateBody, certificateManager.certificatePrivateKey, certificateManager.certificateChain, region)
      })
      .then((arn) => {
        this.serverless.service.provider.compiledCloudFormationTemplate.Outputs.certificateARN = {
          'Value': arn
        }
      })
  }
}

module.exports = ServerlessPlugin
