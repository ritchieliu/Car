import CodeBuild from 'aws-sdk/clients/codebuild'

const codeBuild = new CodeBuild()

module.exports.handler = async (event, context, done) => {
  for (let r of event.Records) {
    let message = JSON.parse(r.Sns.Message)
    for (let record of message.Records) {
      for (let reference of record.codecommit.references) {
        console.log(reference)
        let commit = reference.commit
        let ref = reference.ref
        let environmentVariables = []

        if (ref.includes('refs/heads/release')) {
          environmentVariables.push({
            name: 'STAGE',
            value: 'prod'
          })
        } else if (ref.includes('refs/heads/feature')) {
          environmentVariables.push({
            name: 'STAGE',
            value: 'dev'
          })
        }

        if (environmentVariables) {
          let params = {
            projectName: process.env.PROJECT_NAME,
            artifactsOverride: {
              type: 'NO_ARTIFACTS'
            },
            environmentVariablesOverride: environmentVariables,
            sourceVersion: commit
          }
          codeBuild.startBuild(params, (err, data) => {
            if (err) {
              console.log(err, err.stack)
              return
            }
            console.log(data)
          })
          console.log(JSON.stringify(params))
        }
      }
    }
  }
  return done(null, event)
}
