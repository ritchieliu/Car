import mailparser from 'mailparser'
import SesService from './Service'

const simpleParser = mailparser.simpleParser

module.exports.handler = async (event, context, done) => {
  try {
    event.Records.forEach(async record => {
      console.log(record)
      let message = JSON.parse(record.Sns.Message)
      await simpleParser(message.content, async (error, mail) => {
        if (error) {
          console.log(error)
          throw new Error(error.message)
        }
        await SesService.sendEmail(process.env.INFO_EMAIL, process.env.RECEIVER_EMAIL, mail.subject, mail.html)
      })
    })
    return done(null, event)
  } catch (error) {
    return done(null, error)
  }
}
