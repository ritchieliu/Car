import SesService from './Service'

module.exports.handler = async (event, context, done) => {
  try {
    let mail = await SesService.renderTemplate(event.templateName, event.templateData)
    return done(null, mail)
  } catch (error) {
    console.log(error)
    return done(error)
  }
}
