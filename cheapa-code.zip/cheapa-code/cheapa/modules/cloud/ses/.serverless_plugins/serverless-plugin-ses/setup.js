'use strict'

const Bb = require('bluebird')
const AWS = require('aws-sdk')
const cloudflareService = require('../../../lib/cloudflareService')

module.exports = {
  setup (profile, accountId, domain, emails, cloudFlare) {
    let region = 'us-east-1'

    AWS.config.credentials = new AWS.SharedIniFileCredentials({profile: profile})
    AWS.config.region = region
    const ses = new AWS.SES()

    return isIdentityVerified(domain)
      .then(verifyDomainIdentity)
      .then(() => {
        emails.forEach(email => {
          return Promise.resolve()
            .then(() => isIdentityVerified(email))
            .then(isVerified => verifyEmailAddress(isVerified, email))
            .then(() => getIdentityDkim(email))
            .then(isVerified => verifyIdentityDkim(isVerified))
            .then(() => createPolicy(email))
        })
      })

    function isIdentityVerified (identity) {
      return new Bb((resolve, reject) => {
        ses.getIdentityVerificationAttributes({
          Identities: [
            identity
          ]
        }, function (err, data) {
          if (err) {
            console.log(err)
            return reject(err)
          }

          if (!data.VerificationAttributes || !data.VerificationAttributes[identity] || data.VerificationAttributes[identity].VerificationStatus !== 'Success') {
            console.log(`SES: ${identity} is not verified.`)
            resolve(false)
          } else {
            console.log(`SES: ${identity} is verified.`)
            resolve(true)
          }
        })
      })
    }

    function verifyDomainIdentity (isVerified) {
      if (!isVerified) {
        return new Bb((resolve, reject) => {
          ses.verifyDomainIdentity({
            Domain: domain
          }, function (err, data) {
            if (err) {
              console.log(err)
              return reject(err)
            }

            console.log('Error: Please re-run until your website is verified.')

            resolve(data)
          })
        }).then((data) => {
          return cloudflareService.syncDNSToCloudFlare(cloudFlare, 'TXT', `_amazonses.${domain}`, `${data.VerificationToken}`)
        })
      }

      return Bb.resolve()
    }

    function verifyEmailAddress (isVerified, email) {
      if (!isVerified) {
        return new Bb((resolve, reject) => {
          ses.verifyEmailAddress({
            EmailAddress: email
          }, function (err) {
            if (err) {
              console.log(err)
              return reject(err)
            }

            console.log(`Error: Unverified email: ${email}. Please check your inbox for an email to this address, and click on the link provided to complete verification.`)
            return reject
          })
        })
      }

      return Bb.resolve()
    }

    function getIdentityDkim (email) {
      return new Bb((resolve, reject) => {
        ses.getIdentityDkimAttributes({
          Identities: [
            domain,
            email
          ]
        }, function (err, data) {
          if (err) {
            console.log(err)
            return reject(err)
          }

          if (!data.DkimAttributes ||
            !data.DkimAttributes[domain] ||
            data.DkimAttributes[domain].DkimVerificationStatus !== 'Success' ||
            !data.DkimAttributes[email] ||
            data.DkimAttributes[email].DkimVerificationStatus !== 'Success') {
            console.log(`SES: ${domain} or ${email} DKIM is not verified.`)
            resolve(false)
          } else {
            console.log(`SES: ${domain} or ${email} DKIM is verified.`)
            resolve(true)
          }
        })
      })
    }

    function verifyIdentityDkim (isVerified) {
      if (!isVerified) {
        return new Bb((resolve, reject) => {
          ses.verifyDomainDkim({
            Domain: domain
          }, function (err, data) {
            if (err) {
              console.log(err)
              return reject(err)
            }

            return resolve(data.DkimTokens)
          })
        }).then(tokens => {
          let p = []
          tokens.forEach((token) => {
            p.push(cloudflareService.syncDNSToCloudFlare(cloudFlare, 'CNAME', `${token}._domainkey.${domain}`, `${token}.dkim.amazonses.com`))
          })

          return Bb.all(p)
        })
      }

      return Bb.resolve()
    }

    function createPolicy (email) {
      return new Bb((resolve, reject) => {
        ses.putIdentityPolicy({
          Identity: email,
          PolicyName: 'policy',
          Policy: '{\n' +
          '    "Version": "2008-10-17",\n' +
          '    "Statement": [\n' +
          '        {\n' +
          '            "Sid": "stmt1522888900898",\n' +
          '            "Effect": "Allow",\n' +
          '            "Principal": "*",\n' +
          '            "Action": [\n' +
          '                "ses:SendEmail",\n' +
          '                "ses:SendRawEmail"\n' +
          '            ],\n' +
          '            "Resource": "arn:aws:ses:' + region + ':' + accountId + ':identity/' + email + '"\n' +
          '        }\n' +
          '    ]\n' +
          '}'
        }, function (err, data) {
          if (err) {
            console.log(err)
            return reject(err)
          }

          resolve(data)
        })
      })
    }
  }
}
