'use strict'

const Bb = require('bluebird')
const SesSetup = require('./setup')

class ServerlessPlugin {
  constructor (serverless, options) {
    this.serverless = serverless
    this.options = options

    this.commands = {
      deploy: {
        usage: 'Deploy SES',
        lifecycleEvents: [],
        options: {}
      }
    }

    this.hooks = {
      'after:deploy:deploy': () => Bb.bind(this).then(this.afterDeploy)
    }
  }

  afterDeploy () {
    const ses = this.serverless.service.custom.ses
    const profile = this.serverless.service.provider.profile

    return Bb.resolve()
      .then(() => {
        return SesSetup.setup(profile, ses.accountId, ses.domain, ses.emails, ses.cloudFlare)
      })
  }
}

module.exports = ServerlessPlugin
