import SesService from './Service'

/**
 *
 * Simple email
    {
      'fromAddress': 'grant@51life.com.au',
      'toAddress': 'cmddnst@gmail.com',
      'subject': 'test_subject',
      'text': 'test',
      'templateName': 'name',
      'templateData': {
        'key': 'value'
      }
    }
 * Attachment
 * {
    "fromAddress": "grant@51life.com.au",
    "toAddress": "cmddnst@gmail.com",
    "subject": "test_subject",
    "text": "test",
    "attachments": [{
      "path": "https://www.51life.com.au/resources/img/51sign140.png",
      "type": "application/pdf",
      "name": "51sign140.png"
    }]
  }
 * @param event
 * @param context
 * @param done
 * @returns {Promise.<*>}
 */
module.exports.handler = async (event, context, done) => {
  try {
    await SesService.sendEmail(event.fromAddress, event.toAddress, event.subject, event.text, event.templateName, event.templateData, event.attachments)
    return done(null, event)
  } catch (error) {
    console.log(error)
    return done(error)
  }
}
