import Bb from 'bluebird'
import AWS from 'aws-sdk'
import fs from 'fs'
import https from 'https'
import mailparser from 'mailparser'

const simpleParser = mailparser.simpleParser
const ses = new AWS.SES({region: 'us-east-1'})
const Buffer = AWS.util.Buffer

export default class Service {
  static async renderTemplate (templateName, templateData) {
    let params = {
      TemplateName: templateName,
      TemplateData: JSON.stringify(templateData)
    }
    return Bb.fromCallback(cb => ses.testRenderTemplate(params, cb))
      .then(result => {
        return this.parseEmail(result.RenderedTemplate)
      })
      .catch(error => {
        console.log(error)
        throw new Error(error.message)
      })
  }

  static async sendEmail (fromAddress, toAddress, subject, text, templateName, templateData, attachments) {
    let boundary = 'boundary'
    let nl = '\n'

    if (templateName) {
      let mail = await this.renderTemplate(templateName, templateData)
      subject = mail.subject
      text = mail.html
    }

    let str =
      'MIME-Version: 1.0' + nl +
      'From: ' + fromAddress + nl +
      'To: ' + toAddress + nl +
      'subject: ' + subject + nl +
      'Content-Type: multipart/alternative; boundary="' + boundary + '"' + nl +
      'Content-Transfer-Encoding: quoted-printable' + nl +
      nl +
      '--' + boundary + nl +
      'Content-Type: text/html; charset=UTF-8' + nl +
      'Content-Transfer-Encoding: 7bit' + nl +
      nl +
      text + nl

    if (attachments && attachments.length > 0) {
      for (const attachment of attachments) {
        await this.download(attachment.path, '/tmp/' + attachment.name)
        let attach = new Buffer(fs.readFileSync('/tmp/' + attachment.name)).toString('base64')

        str +=
          '--' + boundary + nl +
          'Content-Type: ' + attachment.type + '; name=' + attachment.name + nl +
          'Content-Disposition: attachment; filename=' + attachment.name + nl +
          'Content-Transfer-Encoding: base64' + nl +
          attach + nl
      }
    }

    str += '--' + boundary + '--'

    let params = {
      RawMessage: {
        Data: new Buffer(str)
      },
      FromArn: process.env.MAIL_SOURCE_ARN,
      SourceArn: process.env.MAIL_SOURCE_ARN,
      Source: fromAddress
    }

    await ses.sendRawEmail(params, (error) => {
      if (error) {
        console.log(error)
        throw new Error(error.message)
      }
      console.log('Email has sent to ' + toAddress)
    })
  }

  static async download (url, dest) {
    return new Bb((resolve, reject) => {
      let file = fs.createWriteStream(dest)
      https.get(url, function (response) {
        response.pipe(file)
        file.on('finish', () => {
          file.close(() => {
            resolve()
          })
        })
      }).on('error', function (err) {
        console.log(err)
        reject(err)
      })
    })
  }

  static async parseEmail (src) {
    return new Bb((resolve, reject) => {
      simpleParser(src, (err, mail) => {
        if (err) {
          console.log(err)
          reject(err)
        }
        resolve(mail)
      })
    })
  }
}
