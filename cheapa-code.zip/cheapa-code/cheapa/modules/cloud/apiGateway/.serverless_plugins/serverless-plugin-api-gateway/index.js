'use strict'

const Bb = require('bluebird')
const cloudflareService = require('../../../lib/cloudflareService')
const ServerlessUtil = require('../../../lib/ServerlessUtil')

class ServerlessPlugin {
  constructor (serverless, options) {
    this.serverless = serverless
    this.options = options

    this.commands = {
      deploy: {
        usage: 'Deploy to API Gateway and create custom domain CNAME in cloudflare',
        lifecycleEvents: [],
        options: {}
      }
    }

    this.hooks = {
      'after:deploy:deploy': () => Bb.bind(this).then(this.afterDeploy)
    }
  }

  afterDeploy () {
    const cloudFlare = this.serverless.service.custom.apiGateway.cloudFlare
    return Bb.resolve()
      .then(() => {
        return ServerlessUtil.fetchCloudFormationStack(this.serverless)
      })
      .then((stack) => {
        return cloudflareService.syncDNSToCloudFlare(cloudFlare, 'CNAME', stack.domainID, stack.domainDistributionDomainName)
      })
  }
}

module.exports = ServerlessPlugin
