'use strict'

const Bb = require('bluebird')
const ServerlessUtil = require('../../../lib/ServerlessUtil')
const S3Service = require('../../../lib/S3Service')
const request = require('request')
const jwktopem = require('jwk-to-pem')

class ServerlessPlugin {
  constructor (serverless, options) {
    this.serverless = serverless
    this.options = options

    this.commands = {
      deploy: {
        usage: 'Deploy Cognito',
        lifecycleEvents: [],
        options: {}
      }
    }

    this.hooks = {
      'after:deploy:deploy': () => Bb.bind(this).then(this.afterDeploy)
    }
  }

  afterDeploy () {
    let stack
    const profile = this.serverless.service.provider.profile
    const region = this.serverless.service.provider.region

    return Bb.resolve()
      .then(() => {
        return ServerlessUtil.fetchCloudFormationStack(this.serverless)
      })
      .then((stackResult) => stack = stackResult)
      .then(() => {
        let url = `${stack.userPoolProviderURL}/.well-known/jwks.json`
        return jwkToPem(url)
      })
      .then((pems) => {
        return S3Service.uploadFile(profile, region, stack.bucketName, stack.userPoolId, JSON.stringify(pems), 'public-read')
      })
  }
}

function jwkToPem (url) {
  return new Bb((resolve, reject) => {
    request(
      {
        url: url,
        json: true
      },
      function (error, response, body) {
        if (error) {
          reject(error)
        }

        let keys = body.keys
        let pems = {}
        for (let i = 0; i < keys.length; i++) {
          // Convert each key to PEM
          let keyId = keys[i].kid
          let modulus = keys[i].n
          let exponent = keys[i].e
          let keyType = keys[i].kty
          let jwk = {kty: keyType, n: modulus, e: exponent}
          let pem = jwktopem(jwk)
          pems[keyId] = pem
        }

        resolve(pems)
      }
    )
  })
}

module.exports = ServerlessPlugin
