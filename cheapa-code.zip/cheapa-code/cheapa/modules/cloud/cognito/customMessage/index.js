import LambdaService from '../../../lib/lambda/LambdaService'

module.exports.handler = async (event, context, done) => {
  try {
    await constructMailContent()
    return done(null, event)
  } catch (error) {
    console.log(error)
    return done(error)
  }

  async function constructMailContent () {
    let payload = {}
    if (event.triggerSource === 'CustomMessage_AdminCreateUser') {
      payload = {
        templateName: process.env.CREATE_USER_TEMPLATE_NAME,
        templateData: {
          confirmUrl: process.env.CREATE_USER_EMAIL_CONFIRM_URL
        }
      }
    } else if (event.triggerSource === 'CustomMessage_ForgotPassword') {
      payload = {
        templateName: process.env.FORGOT_PASSWORD_TEMPLATE_NAME,
        templateData: {
          confirmUrl: process.env.FORGOT_PASSWORD_EMAIL_CONFIRM_URL + ';id=' + event.userName
        }
      }
    }
    let mail = await LambdaService.invoke({
      FunctionName: process.env.SES_RENDER_TEMPLATE_FUNCTION_ARN,
      InvocationType: 'RequestResponse',
      Payload: JSON.stringify(payload)
    }, 'us-east-1')
    event.response.emailSubject = mail.subject
    event.response.emailMessage = mail.html
  }
}
