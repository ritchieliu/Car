'use strict'

const Bb = require('bluebird')
const Joi = require('joi')
const dynogels = require('dynogels')
dynogels.AWS.config.update({
  accessKeyId: 'AKIAIH4I6WBLK35H4ZTA',
  secretAccessKey: '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',
  region: 'us-east-1'
})
/// //////////////////

const chatQna = dynogels.define('chat_qna', {
  hashKey: 'accountId',
  tableName: 'chat_qna',
  schema: Joi.object().keys({
    accountId: Joi.string(),
    id: Joi.string()
  }).options({allowUnknown: true})
})

const chatBotsQna = dynogels.define('chat_bots_qna', {
  hashKey: 'accountBotId',
  tableName: 'chat_bots_qna',
  schema: Joi.object().keys({
    accountBotId: Joi.string(),
    id: Joi.string()
  }).options({allowUnknown: true})
})

getOrig().then(save)

/// //////////////////

function getOrig () {
  return new Bb((resolve, reject) => {
    chatQna
      .scan()
      .loadAll()
      .exec((err, results) => {
        if (err) {
          console.log('ERROR:', err)
          return
        }

        results.Items = results.Items.map((item) => item.attrs)
        results.Items.forEach(item => {
          item.accountBotId = item.accountId + '_BRKQsjrDVFKnRmuSpiXQiorLCKFAgwuv'
          delete item.accountId
        })
        resolve(results.Items)
      })
  })
}

function save (results) {
  console.log(results)
  chatBotsQna.create(results, (err, result) => {
    if (err) {
      console.log(err)
    }
    console.log(result)
  })
}
