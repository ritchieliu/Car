const request = require('request')
const net = require('net')

const SERVER_BASE_API_URL = 'https://api.cheapacarrental.com'
const PORT = 8802
const MSG_HEAD = '('
const MSG_END = ')'
const MSG_COMMAND_DEVICE_ONLINE = 'BP05'
const MSG_COMMAND_DEVICE_LOCATION = 'BR00'
const MSG_COMMAND_DEVICE_CONFIRM_OPEN_DOOR = 'BV15'
const MSG_COMMAND_DEVICE_CONFIRM_CLOSE_DOOR = 'BV26'
const MSG_COMMAND_DEVICE_CONFIRM_OIL_ACTION = 'BV01'
const MSG_COMMAND_DEVICE_CONFIRM_CIRCUIT_ACTION = 'BV00'
const MSG_COMMAND_SERVER_CONFIRM = 'AP05'
const MSG_COMMAND_SERVER_ACTION_OPEN_DOOR = 'AV15'
const MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR = 'AV26'
const MSG_COMMAND_SERVER_ACTION_OIL_CONTROL = 'AV01'
const MSG_COMMAND_SERVER_ACTION_CIRCUIT_CONTROL = 'AV00'

const sockets = {}

const server = net.createServer(socket => {
  try {
    socket.on('data', function (data) {
      console.log(`Received: ${data}`)
      data = data.toString().toUpperCase()

      // Validate message head
      if (getMsgHead(data) !== MSG_HEAD) {
        return
      }

      let deviceId = getDeviceId(data)

      let received = {
        remoteAddress: socket.remoteAddress + ' ' + socket.remotePort,
        deviceId: deviceId,
        command: getMsgCommandName(data)
      }

      let command = getMsgCommand(data)

      try {
        switch (command) {
          case MSG_COMMAND_DEVICE_ONLINE:
            setSocket(deviceId, socket)
            sendOnlineConfirm(socket, deviceId)
            sendServerMessage(deviceId, {
              type: 'ONLINE',
              payload: {
                message: data
              }
            })
            break
          case MSG_COMMAND_DEVICE_LOCATION:
            setSocket(deviceId, socket)
            received.latitude = getLocationLatitude(data)
            received.longitude = getLocationLongitude(data)
            received.mileage = getLocationMileage(data)
            sendServerMessage(deviceId, {
              type: 'LOCATION',
              payload: {
                message: data,
                latitude: received.latitude,
                longitude: received.longitude,
                mileage: received.mileage
              }
            })
            break
          case MSG_COMMAND_SERVER_ACTION_OPEN_DOOR:
          case MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR:
          case MSG_COMMAND_SERVER_ACTION_OIL_CONTROL:
          case MSG_COMMAND_SERVER_ACTION_CIRCUIT_CONTROL:
            disconnect(socket)
            sendDeviceMessage(deviceId, data)
            break
          case MSG_COMMAND_DEVICE_CONFIRM_OIL_ACTION:
          case MSG_COMMAND_DEVICE_CONFIRM_CIRCUIT_ACTION:
          case MSG_COMMAND_DEVICE_CONFIRM_OPEN_DOOR:
          case MSG_COMMAND_DEVICE_CONFIRM_CLOSE_DOOR:
            setSocket(deviceId, socket)
            sendServerMessage(deviceId, {
              type: 'CONFIRMATION',
              payload: {
                message: data,
                action: getMsgCommandName(data)
              }
            })
            break
        }
      } catch (e) {
        console.log(e)
        console.log(`Error happened. Remove device socket from server: ${deviceId}`)
        delete sockets[deviceId]
      }

      console.log(received)
    })

    socket.on('error', function (e) {
      console.log('ERROR: ')
      console.log(e)
    })

    socket.on('timeout', () => {
      console.log('socket timeout')
      disconnect(socket)
    })

    socket.on('close', function () {
      console.log('CLOSED: ' + socket.remoteAddress + ' ' + socket.remotePort)
    })

    socket.on('end', function () {
      console.log('ENDED: ' + socket.remoteAddress + ' ' + socket.remotePort)
    })
  } catch (e) {
    console.log(new Date())
    console.log(e)
  }
})

server.on('error', (err) => {
  console.log(err)
})

server.on('connection', (socket) => {
  console.log(`connection: ${socket.remoteAddress}`)
  socket.setTimeout(1000 * 60 * 30)
})

server.listen(PORT)

function disconnect (socket) {
  if (!socket) {
    return
  }

  console.log('Disconnect socket')
  socket.end()
  socket.destroy()
  socket.unref()
}

function sendOnlineConfirm (socket, deviceId) {
  let message = `${MSG_HEAD}${deviceId}${MSG_COMMAND_SERVER_CONFIRM}${MSG_END}`
  socket.write(message)
  console.log(`Online Confirm from device ${deviceId}: ${message}`)
}

function getMsgHead (data) {
  return data.substr(0, 1)
}

function getDeviceId (data) {
  return data.substr(1, 12)
}

function getMsgCommand (data) {
  return data.substr(13, 4)
}

function getMsgCommandName (data) {
  switch (getMsgCommand(data)) {
    case MSG_COMMAND_SERVER_CONFIRM:
      return 'MSG_COMMAND_SERVER_CONFIRM'
    case MSG_COMMAND_DEVICE_ONLINE:
      return 'MSG_COMMAND_DEVICE_ONLINE'
    case MSG_COMMAND_DEVICE_LOCATION:
      return 'MSG_COMMAND_DEVICE_LOCATION'
    case MSG_COMMAND_SERVER_ACTION_OPEN_DOOR:
      return 'MSG_COMMAND_SERVER_ACTION_OPEN_DOOR'
    case MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR:
      return 'MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR'
    case MSG_COMMAND_SERVER_ACTION_OIL_CONTROL:
      return 'MSG_COMMAND_SERVER_ACTION_OIL_CONTROL'
    case MSG_COMMAND_SERVER_ACTION_CIRCUIT_CONTROL:
      return 'MSG_COMMAND_SERVER_ACTION_CIRCUIT_CONTROL'
    case MSG_COMMAND_DEVICE_CONFIRM_OPEN_DOOR:
      return 'MSG_COMMAND_DEVICE_CONFIRM_OPEN_DOOR'
    case MSG_COMMAND_DEVICE_CONFIRM_CLOSE_DOOR:
      return 'MSG_COMMAND_DEVICE_CONFIRM_CLOSE_DOOR'
    case MSG_COMMAND_DEVICE_CONFIRM_OIL_ACTION:
      return 'MSG_COMMAND_DEVICE_CONFIRM_OIL_ACTION'
    case MSG_COMMAND_DEVICE_CONFIRM_CIRCUIT_ACTION:
      return 'MSG_COMMAND_DEVICE_CONFIRM_CIRCUIT_ACTION'
  }
}

function getLocationLatitude (data) {
  let result = data.substr(24, 10)
  let degree = parseInt(result.substr(0, 2))
  let minute = parseFloat(result.substr(2, 7)) / 60
  return parseFloat((degree + minute).toFixed(6)) * -1
}

function getLocationLongitude (data) {
  let result = data.substr(34, 11)
  let degree = parseInt(result.substr(0, 3))
  let minute = parseFloat(result.substr(3, 7)) / 60
  return parseFloat((degree + minute).toFixed(6))
}

function getLocationMileage (data) {
  let result = data.substr(72, 8)
  return parseInt(result, 16)
}

function sendServerMessage (deviceId, data) {
  request({
    url: `${SERVER_BASE_API_URL}/devices/${deviceId}/reports`,
    method: 'POST',
    headers: {},
    body: JSON.stringify(data),
    pool: {maxSockets: Infinity}
  }, function (error) {
    if (error) {
      console.log(error)
    }

    console.log('Sent to server response success')
  })
}

function sendDeviceMessage (deviceId, data) {
  sockets[deviceId].write(data)
  console.log(`Sent command to device ${deviceId}: ${data}`)
}

function setSocket (deviceId, socket) {
  sockets[deviceId] = socket
}
