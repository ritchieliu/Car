const net = require('net')

const client = new net.Socket()
client.setEncoding('hex')

// const SERVER_IP = '52.73.59.221'
const SERVER_IP = '52.22.186.165'
// const SERVER_IP = '127.0.0.1'
const PORT = 8801
const MSG_HEAD = '4C44'
const MSG_END = 'AA'
const MSG_COMMAND_DEVICE_ONLINE = '6B'
const MSG_COMMAND_DEVICE_LOCATION = '80'
const MSG_COMMAND_DEVICE_CONFIRM = '60'
const MSG_COMMAND_SERVER_CONFIRM = '30'
const MSG_COMMAND_SERVER_ACTION = '33'
const MSG_COMMAND_SERVER_ACTION_OPEN_DOOR = '0100'
const MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR = '0200'
const DEVICE_ID = '00018666000765'

// Shenzhen
// const LATITUDE = '222382709'
// const LONGITUDE = '11356648'

// Greenacre
const LATITUDE = '33541575'
const LONGITUDE = '15102353'

connect()

setInterval(() => {
  sendLocation()
  // sendConfirmation()
}, 5000)

function connect () {
  client.connect(PORT, SERVER_IP, () => {
    console.log('Connected')
    online()
  })

  client.on('data', function (data) {
    console.log(data)
    data = data.toUpperCase()
    let response = {
      received: data,
      deviceId: getDeviceId(data),
      command: getMsgCommandName(data)
    }

    console.log('Response:')
    console.log(response)
  })

  client.on('close', function () {
    console.log('Connection closed')
  })
}

function online () {
  let message = `${MSG_HEAD}${MSG_COMMAND_DEVICE_ONLINE}${DEVICE_ID}001901094C4431303356322E35020C34344136453531344345333601${MSG_END}`
  client.write(message, 'hex')
  console.log('Request:')
  console.log({
    command: 'MSG_COMMAND_DEVICE_ONLINE',
    message: message,
    deviceId: getDeviceId(message)
  })
}

function sendLocation () {
  let message = `${MSG_HEAD}${MSG_COMMAND_DEVICE_LOCATION}${DEVICE_ID}0020180410210602${LATITUDE}${LONGITUDE}000000000000FC00000000007B1F000000001E${MSG_END}`
  client.write(message, 'hex')
  console.log('Request:')
  console.log({
    command: 'MSG_COMMAND_DEVICE_LOCATION',
    message: message,
    deviceId: getDeviceId(message),
    time: getLocationDateTime(message),
    latitude: getLocationLatitude(message),
    longitude: getLocationLongitude(message)
  })
}

function sendConfirmation () {
  let message = `${MSG_HEAD}${MSG_COMMAND_DEVICE_CONFIRM}${DEVICE_ID}0003320300CRC${MSG_END}`
  client.write(message, 'hex')
  console.log('Request:')
  console.log({
    command: 'MSG_COMMAND_DEVICE_CONFIRM',
    message: message,
    deviceId: getDeviceId(message)
  })
}

function getMsgHead (data) {
  return data.substr(0, 4)
}

function getMsgCommand (data) {
  return data.substr(4, 2)
}

function getMsgCommandName (data) {
  switch (getMsgCommand(data)) {
    case MSG_COMMAND_SERVER_CONFIRM:
      return 'MSG_COMMAND_SERVER_CONFIRM'
    case MSG_COMMAND_SERVER_ACTION:
      return 'MSG_COMMAND_SERVER_ACTION'
  }
}

function getDeviceId (data) {
  return data.substr(6, 14)
}

function getLocationDateTime (data) {
  return data.substr(24, 12)
}

function getLocationLatitude (data) {
  let result = data.substr(36, 8)
  let degree = parseInt(result.substr(0, 2))
  let minute = parseInt(result.substr(2, 6)) / 10000 / 60
  return parseFloat((degree + minute).toFixed(6))
}

function getLocationLongitude (data) {
  let result = data.substr(44, 8)
  let degree = parseInt(result.substr(0, 3))
  let minute = parseInt(result.substr(3, 5)) / 1000 / 60
  return parseFloat((degree + minute).toFixed(6))
}

function getActionCode (data) {
  return data.substr(24, 4)
}

function getActionCodeName (data) {
  switch (getActionCode(data)) {
    case MSG_COMMAND_SERVER_ACTION_OPEN_DOOR:
      return 'MSG_COMMAND_SERVER_ACTION_OPEN_DOOR'
    case MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR:
      return 'MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR'
  }
}

// online
// 4C446B00013900000001001901094C4431303356322E35020C34344136453531344345333601AA
// 4C44300001390000000100026B0068AA

// location
// 4C44800001390000000100201804102106022238270911356648000000000000FC00000000007B1F000000001EAA
// 4C44800001390000000100201804102106022238270911356648000000000000FC00000000007B1F000000001EAA
// 4C4430000139000000010002800083AA
