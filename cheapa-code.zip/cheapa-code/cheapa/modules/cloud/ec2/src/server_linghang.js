const request = require('request')
const net = require('net')

const SERVER_BASE_API_URL = 'https://apidev.cheapacarrental.com'
const PORT = 8803
const MSG_HEAD = '4C44'
const MSG_END = 'AA'
const MSG_COMMAND_DEVICE_ONLINE = '6B'
const MSG_COMMAND_DEVICE_LOCATION = '80'
const MSG_COMMAND_DEVICE_CONFIRM = '60'
const MSG_COMMAND_SERVER_CONFIRM = '30'
const MSG_COMMAND_SERVER_ACTION = '33'
const MSG_COMMAND_DEVICE_CONFIRM_OPEN_DOOR = '3301'
const MSG_COMMAND_DEVICE_CONFIRM_CLOSE_DOOR = '3302'

const sockets = {}

const server = net.createServer(socket => {
  try {
    socket.setEncoding('hex')

    socket.on('data', function (data) {
      console.log(`Received: ${data}`)
      data = data.toUpperCase()

      // Validate message head
      if (getMsgHead(data) !== MSG_HEAD) {
        return
      }

      let deviceId = getDeviceId(data)

      let received = {
        remoteAddress: socket.remoteAddress + ' ' + socket.remotePort,
        deviceId: deviceId,
        command: getMsgCommandName(data)
      }

      let command = getMsgCommand(data)

      try {
        switch (command) {
          case MSG_COMMAND_DEVICE_ONLINE:
            setSocket(deviceId, socket)
            sendOnlineConfirm(socket, deviceId)
            sendServerMessage(deviceId, {
              type: 'ONLINE',
              payload: {
                message: data
              }
            })
            break
          case MSG_COMMAND_DEVICE_LOCATION:
            setSocket(deviceId, socket)
            received.latitude = getLocationLatitude(data)
            received.longitude = getLocationLongitude(data)
            sendLocationConfirm(socket, deviceId)
            sendServerMessage(deviceId, {
              type: 'LOCATION',
              payload: {
                message: data,
                latitude: received.latitude,
                longitude: received.longitude
              }
            })
            break
          case MSG_COMMAND_DEVICE_CONFIRM:
            setSocket(deviceId, socket)
            sendServerMessage(deviceId, {
              type: 'CONFIRMATION',
              payload: {
                message: data,
                action: getActionCodeName(data)
              }
            })
            break
          case MSG_COMMAND_SERVER_ACTION:
            disconnect(socket)
            sendDeviceMessage(deviceId, data)
            break
        }
      } catch (e) {
        console.log(e)
        console.log(`Error happened. Remove device socket from server: ${deviceId}`)
        delete sockets[deviceId]
      }

      console.log(received)
    })

    socket.on('error', function (e) {
      console.log('ERROR: ')
      console.log(e)
    })

    socket.on('timeout', () => {
      console.log('socket timeout')
      disconnect(socket)
    })

    socket.on('close', function () {
      console.log('CLOSED: ' + socket.remoteAddress + ' ' + socket.remotePort)
    })

    socket.on('end', function () {
      console.log('ENDED: ' + socket.remoteAddress + ' ' + socket.remotePort)
    })
  } catch (e) {
    console.log(new Date())
    console.log(e)
  }
})

server.on('error', (err) => {
  console.log(err)
})

server.on('connection', (socket) => {
  console.log(`connection: ${socket.remoteAddress}`)
  socket.setTimeout(1000 * 60 * 30)
})

server.listen(PORT)

function disconnect (socket) {
  if (!socket) {
    return
  }

  console.log('Disconnect socket')
  socket.end()
  socket.destroy()
  socket.unref()
}

function sendOnlineConfirm (socket, deviceId) {
  let bodyMessage = `${MSG_HEAD}${MSG_COMMAND_SERVER_CONFIRM}${deviceId}00026B00`
  let message = `${bodyMessage}${getChecksum(bodyMessage)}${MSG_END}`
  socket.write(message, 'hex')
  console.log(`Online Confirm from device ${deviceId}: ${message}`)
}

function sendLocationConfirm (socket, deviceId) {
  let bodyMessage = `${MSG_HEAD}${MSG_COMMAND_SERVER_CONFIRM}${deviceId}00028000`
  let message = `${bodyMessage}${getChecksum(bodyMessage)}${MSG_END}`
  socket.write(message, 'hex')
  console.log(`Location Confirm from device ${deviceId}: ${message}`)
}

function getMsgHead (data) {
  return data.substr(0, 4)
}

function getMsgCommand (data) {
  return data.substr(4, 2)
}

function getMsgCommandName (data) {
  switch (getMsgCommand(data)) {
    case MSG_COMMAND_SERVER_CONFIRM:
      return 'MSG_COMMAND_SERVER_CONFIRM'
    case MSG_COMMAND_DEVICE_ONLINE:
      return 'MSG_COMMAND_DEVICE_ONLINE'
    case MSG_COMMAND_DEVICE_LOCATION:
      return 'MSG_COMMAND_DEVICE_LOCATION'
    case MSG_COMMAND_SERVER_ACTION:
      return 'MSG_COMMAND_SERVER_ACTION'
    case MSG_COMMAND_DEVICE_CONFIRM:
      return 'MSG_COMMAND_DEVICE_CONFIRM'
  }
}

function getDeviceId (data) {
  return data.substr(6, 14)
}

function getLocationDateTime (data) {
  return data.substr(24, 12)
}

function getLocationLatitude (data) {
  let result = data.substr(36, 8)
  let degree = parseInt(result.substr(0, 2))
  let minute = parseInt(result.substr(2, 6)) / 10000 / 60
  return parseFloat((degree + minute).toFixed(6)) * -1
}

function getLocationLongitude (data) {
  let result = data.substr(44, 8)
  let degree = parseInt(result.substr(0, 3))
  let minute = parseInt(result.substr(3, 5)) / 1000 / 60
  return parseFloat((degree + minute).toFixed(6))
}

function getActionCode (data) {
  return data.substr(24, 4)
}

function getActionCodeName (data) {
  switch (getActionCode(data)) {
    case MSG_COMMAND_DEVICE_CONFIRM_OPEN_DOOR:
      return 'MSG_COMMAND_DEVICE_CONFIRM_OPEN_DOOR'
    case MSG_COMMAND_DEVICE_CONFIRM_CLOSE_DOOR:
      return 'MSG_COMMAND_DEVICE_CONFIRM_CLOSE_DOOR'
  }
}

function sendDeviceMessage (deviceId, data) {
  sockets[deviceId].write(data, 'hex')
  console.log(`Sent command to device ${deviceId}: ${data}`)
}

function getChecksum (data) {
  return data.match(/.{2}/g).reduce((checksum, item) =>
    checksum ^ parseInt(item, 16)
    , 0).toString(16).padStart(2, '0').toUpperCase()
}

function sendServerMessage (deviceId, data) {
  request({
    url: `${SERVER_BASE_API_URL}/devices/${deviceId}/reports`,
    method: 'POST',
    headers: {},
    body: JSON.stringify(data)
  }, function (error) {
    if (error) {
      console.log(error)
    }

    console.log('Sent to server response success')
  })
}

function setSocket (deviceId, socket) {
  sockets[deviceId] = socket
}
