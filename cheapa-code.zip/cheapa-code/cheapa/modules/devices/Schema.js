import Joi from 'joi'

export class DeviceSchema {
  static getDynamoSchema () {
    return Joi.object().keys({
      id: Joi.string().trim().required(),
      type: Joi.string().valid(['linghang', 'h6', 'h6_2']).default('linghang'),
      enabled: Joi.boolean().default(true),
      vehicleId: Joi.string().allow('', null),
      password: Joi.string().allow('', null),
      mobile: Joi.string().allow('', null),
      mobileExpireDate: Joi.date().iso().allow('', null),
      comment: Joi.string().allow('', null),
      createdAt: Joi.date().iso().required(),
      updatedAt: Joi.date().iso()
    })
  }

  static getViewSchema () {
    return Joi.object().keys({
      id: Joi.string().trim().required(),
      vehicleId: Joi.string().allow('', null),
      type: Joi.string().valid(['linghang', 'h6', 'h6_2']).default('linghang'),
      password: Joi.string().allow('', null),
      mobile: Joi.string().allow('', null),
      mobileExpireDate: Joi.date().iso().allow('', null),
      comment: Joi.string().allow('', null)
    })
  }
}
