import Exception from '../lib/Exception'
import JoiUtil from '../lib/util/JoiUtil'
import { VehicleService } from '../vehicles/Service'
import { DeviceRepo } from './Repo'
import { DeviceSchema } from './Schema'
import { VehicleRepo } from '../vehicles/Repo'

const repo = new DeviceRepo()
const vehicleRepo = new VehicleRepo()

export class DeviceService {
  static async getAll (q) {
    return repo.getAll(q)
  }

  static async getInstance (id) {
    let instance = await repo.getInstance(id)
    if (!instance) {
      throw Exception.notFound()
    }
    return instance
  }

  static async create (body) {
    JoiUtil.validate(body, DeviceSchema.getViewSchema())
    await this.updateVehicleDevice(body.vehicleId, body.id)
    return repo.create(body)
  }

  static async update (id, body) {
    JoiUtil.validate(body, DeviceSchema.getViewSchema())
    await this.updateVehicleDevice(body.vehicleId, body.id)
    let instance = await this.getInstance(id)
    return repo.update(Object.assign(instance, body))
  }

  static async updateVehicleDevice (vehicleId, deviceId) {
    if (vehicleId) {
      let vehicle = await VehicleService.getInstance(vehicleId)
      if (vehicle.deviceId !== deviceId) {
        vehicle.deviceId = deviceId
        await vehicleRepo.update(vehicle)
      }
    }
  }

  static async delete (id) {
    await this.getInstance(id)
    return repo.destroy(id)
  }
}
