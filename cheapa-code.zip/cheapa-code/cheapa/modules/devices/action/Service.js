import TcpUtil from '../../lib/util/TcpUtil'
import JoiUtil from '../../lib/util/JoiUtil'
import { DeviceActionSchema } from './Schema'
import { DeviceService } from '../Service'

const SERVER_IP = process.env.TCP_SERVER_IP

const LINGHANG_PORT = process.env.TCP_SERVER_PORT_LINGHANG
const LINGHANG_MSG_HEAD = '4C44'
const LINGHANG_MSG_END = 'AA'
const LINGHANG_MSG_COMMAND_SERVER_ACTION = '33'
const LINGHANG_MSG_COMMAND_SERVER_ACTION_OPEN_DOOR = '0100'
const LINGHANG_MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR = '0200'
const LINGHANG_MSG_COMMAND_SERVER_ACTION_LENGTH_CODE = '0002'

const H6_PORT = process.env.TCP_SERVER_PORT_H6
const H6_MSG_HEAD = '('
const H6_MSG_END = ')'
const H6_MSG_COMMAND_SERVER_ACTION_OPEN_DOOR = 'AV15'
const H6_MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR = 'AV26'
const H6_MSG_COMMAND_SERVER_ACTION_CONTROL_OIL_ON = 'AV011'
const H6_MSG_COMMAND_SERVER_ACTION_CONTROL_OIL_OFF = 'AV010'
const H6_MSG_COMMAND_SERVER_ACTION_CONTROL_CIRCUIT_ON = 'AV001'
const H6_MSG_COMMAND_SERVER_ACTION_CONTROL_CIRCUIT_OFF = 'AV000'

export class DeviceActionService {
  static async processAction (id, body) {
    JoiUtil.validate(body, DeviceActionSchema.getViewSchema())
    let instance = await DeviceService.getInstance(id)
    let deviceId = instance.id
    let message
    let port

    switch (instance.type) {
      case 'linghang':
        message = this.getLinghangMessage(deviceId, body.action)
        port = LINGHANG_PORT
        await TcpUtil.sendHexRequest({
          serverIp: SERVER_IP,
          port: port,
          message: message
        })
        break
      case 'h6':
        message = this.getH6Message(deviceId, body.action)
        port = H6_PORT
        await TcpUtil.sendRequest({
          serverIp: SERVER_IP,
          port: port,
          message: message
        })
        break
      case 'h6_2':
        message = this.getH62Message(deviceId, body.action)
        port = H6_PORT
        await TcpUtil.sendRequest({
          serverIp: SERVER_IP,
          port: port,
          message: message
        })
        break
    }
    return {message, action: body.action, deviceId}
  }

  static getLinghangMessage (deviceId, action) {
    let bodyMessage
    switch (action) {
      case 'OPEN_DOOR':
        bodyMessage = `${LINGHANG_MSG_HEAD}${LINGHANG_MSG_COMMAND_SERVER_ACTION}${deviceId}${LINGHANG_MSG_COMMAND_SERVER_ACTION_LENGTH_CODE}${LINGHANG_MSG_COMMAND_SERVER_ACTION_OPEN_DOOR}`
        break
      case 'CLOSE_DOOR':
        bodyMessage = `${LINGHANG_MSG_HEAD}${LINGHANG_MSG_COMMAND_SERVER_ACTION}${deviceId}${LINGHANG_MSG_COMMAND_SERVER_ACTION_LENGTH_CODE}${LINGHANG_MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR}`
        break
    }
    return `${bodyMessage}${this.getChecksum(bodyMessage)}${LINGHANG_MSG_END}`
  }

  static getH6Message (deviceId, action) {
    switch (action) {
      case 'OPEN_DOOR':
        return `${H6_MSG_HEAD}${deviceId}${H6_MSG_COMMAND_SERVER_ACTION_CONTROL_OIL_ON}${H6_MSG_END}`
      case 'CLOSE_DOOR':
        return `${H6_MSG_HEAD}${deviceId}${H6_MSG_COMMAND_SERVER_ACTION_CONTROL_OIL_OFF}${H6_MSG_END}`
      case 'CONTROL_CIRCUIT_ON':
        return `${H6_MSG_HEAD}${deviceId}${H6_MSG_COMMAND_SERVER_ACTION_CONTROL_CIRCUIT_ON}${H6_MSG_END}`
      case 'CONTROL_CIRCUIT_OFF':
        return `${H6_MSG_HEAD}${deviceId}${H6_MSG_COMMAND_SERVER_ACTION_CONTROL_CIRCUIT_OFF}${H6_MSG_END}`
    }
  }

  static getH62Message (deviceId, action) {
    switch (action) {
      case 'OPEN_DOOR':
        return `${H6_MSG_HEAD}${deviceId}${H6_MSG_COMMAND_SERVER_ACTION_OPEN_DOOR}${H6_MSG_END}`
      case 'CLOSE_DOOR':
        return `${H6_MSG_HEAD}${deviceId}${H6_MSG_COMMAND_SERVER_ACTION_CLOSE_DOOR}${H6_MSG_END}`
      case 'CONTROL_CIRCUIT_ON':
        return `${H6_MSG_HEAD}${deviceId}${H6_MSG_COMMAND_SERVER_ACTION_CONTROL_CIRCUIT_ON}${H6_MSG_END}`
      case 'CONTROL_CIRCUIT_OFF':
        return `${H6_MSG_HEAD}${deviceId}${H6_MSG_COMMAND_SERVER_ACTION_CONTROL_CIRCUIT_OFF}${H6_MSG_END}`
    }
  }

  static getChecksum (data) {
    return data.match(/.{2}/g).reduce((checksum, item) =>
      checksum ^ parseInt(item, 16)
      , 0).toString(16).padStart(2, '0')
  }
}
