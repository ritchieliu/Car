import Joi from 'joi'

export class DeviceActionSchema {
  static getViewSchema () {
    return Joi.object().keys({
      action: Joi.string().valid(['OPEN_DOOR', 'CLOSE_DOOR', 'CONTROL_CIRCUIT_ON', 'CONTROL_CIRCUIT_OFF']).required(),
      orderCreatedAt: Joi.string().allow('', null),
      vehicleId: Joi.string().allow('', null)
    })
  }
}
