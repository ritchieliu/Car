import Bb from 'bluebird'
import DynamoRepo from '../lib/dynamo/DynamoRepo'
import Exception from '../lib/Exception'
import DynamoHelper from '../lib/dynamo/DynamoHelper'
import { DeviceSchema } from './Schema'

export class DeviceRepo extends DynamoRepo {
  constructor () {
    super('devices', DeviceSchema.getDynamoSchema(), {
      hashKey: 'id'
    })
  }

  getAll (q) {
    return new Bb((resolve, reject) => {
      let query = this.model.scan()

      if (q.limit) {
        query.limit(q.limit)
      }

      if (q.startKey) {
        query.startKey(q.startKey)
      }

      if (q.name) {
        query.where('name').equals(q.name)
      }

      query
        .expressionAttributeNames(DynamoHelper.getExpressionAttributeNames(q.express, {'#id': 'id'}))
        .projectionExpression(DynamoHelper.getProjectionExpression(q.express, '#id'))
        .exec((err, results) => {
          if (err) {
            return reject(Exception.internal(err.message, err))
          }
          results.Items = results.Items.map((item) => item.attrs)
          resolve(results)
        })
    })
  }
}
