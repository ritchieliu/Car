import ApiLambdaHandler from '../lib/lambda/ApiLambdaHandler'
import { DeviceActionService } from './action/Service'
import { DeviceReportService } from './reports/Service'
import { DeviceService } from './Service'
import Exception from '../lib/Exception'
import { VehicleService } from '../vehicles/Service'
import { OrderService } from '../orders/Service'

const runner = {
  '/devices': {},
  '/devices/{id}': {},
  '/devices/{id}/action': {},
  '/devices/{id}/reports': {},
  '/devices/{id}/reports/{createdAt}': {}
}

runner['/devices'].GET = async (request) => {
  if (request.isAdmin) {
    return DeviceService.getAll(request.q)
  }
}

runner['/devices/{id}'].GET = async (request) => {
  if (request.isAdmin) {
    return DeviceService.getInstance(request.path.id)
  }
}

runner['/devices'].POST = async (request) => {
  if (request.isAdmin) {
    return DeviceService.create(request.body)
  }
}

runner['/devices/{id}'].PUT = async (request) => {
  if (request.isAdmin) {
    return DeviceService.update(request.path.id, request.body)
  }
}

runner['/devices/{id}'].DELETE = async (request) => {
  if (request.isAdmin) {
    return DeviceService.delete(request.path.id)
  }
}

runner['/devices/{id}/action'].POST = async (request) => {
  if (request.isMember) {
    let order = await OrderService.getInstance(request.authorizer.id, request.body.orderCreatedAt)
    if (!(order.status === 'ACTIVE' || order.status === 'VEHICLE_RETURNED')) {
      throw Exception.notFound()
    }

    let vehicle = await VehicleService.getInstance(order.vehicleId)
    if (vehicle.deviceId !== request.path.id) {
      throw Exception.notFound()
    }
  }
  if (request.isPartner) {
    let vehicle = await VehicleService.getInstance(request.body.vehicleId)
    if (vehicle.accountId !== request.authorizer.id) {
      throw Exception.notFound()
    }
  }
  return DeviceActionService.processAction(request.path.id, request.body)
}

runner['/devices/{id}/reports'].GET = async (request) => {
  return DeviceReportService.getAll(request.path.id, request.q)
}

runner['/devices/{id}/reports'].POST = async (request) => {
  request.body.deviceId = request.path.id
  return DeviceReportService.save(request.body)
}

runner['/devices/{id}/reports/{createdAt}'].GET = async (request) => {
  return DeviceReportService.getInstance(request.path.id, request.path.createdAt)
}

module.exports.handler = ApiLambdaHandler(runner)
