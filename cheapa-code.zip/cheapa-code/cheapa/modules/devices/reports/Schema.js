import Joi from 'joi'

export class DeviceReportSchema {
  static getDynamoSchema () {
    return Joi.object().keys({
      deviceId: Joi.string().required(),
      createdAt: Joi.date().iso().required(),
      type: this.getType(),
      payload: this.getPayload(),
      updatedAt: Joi.date().iso()
    })
  }

  static getViewSchema () {
    return Joi.object().keys({
      deviceId: Joi.string().required(),
      type: this.getType(),
      payload: this.getPayload()
    })
  }

  static getType () {
    return Joi.string().valid(['CONFIRMATION', 'LOCATION', 'ONLINE']).required()
  }

  static getPayload () {
    return Joi.any()
      .when('type', {
        is: 'ONLINE',
        then: this.getOnlinePayload()
      })
      .when('type', {
        is: 'LOCATION',
        then: this.getLocationPayload()
      })
      .when('type', {
        is: 'CONFIRMATION',
        then: this.getConfirmationPayload()
      })
  }

  static getOnlinePayload () {
    return Joi.object().keys({
      message: Joi.string().required()
    })
  }

  static getLocationPayload () {
    return Joi.object().keys({
      message: Joi.string().required(),
      latitude: Joi.number().required(),
      longitude: Joi.number().required(),
      mileage: Joi.number().allow(null)
    })
  }

  static getConfirmationPayload () {
    return Joi.object().keys({
      message: Joi.string().required(),
      action: Joi.string().required()
    })
  }
}
