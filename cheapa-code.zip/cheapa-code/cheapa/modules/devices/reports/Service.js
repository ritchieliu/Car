import Exception from '../../lib/Exception'
import JoiUtil from '../../lib/util/JoiUtil'
import DateUtil from '../../lib/util/DateUtil'
import { VehicleRepo } from '../../vehicles/Repo'
import { DeviceReportRepo } from './Repo'
import { DeviceService } from '../Service'
import { DeviceReportSchema } from './Schema'

const repo = new DeviceReportRepo()
const vehicleRepo = new VehicleRepo()

export class DeviceReportService {
  static async getAll (deviceId, q) {
    return repo.getAll(deviceId, q)
  }

  static async getInstance (deviceId, createdAt) {
    let instance = await repo.getInstance(deviceId, createdAt)
    if (!instance) {
      throw Exception.notFound()
    }
    return instance
  }

  static async save (body) {
    JoiUtil.validate(body, DeviceReportSchema.getViewSchema())
    let deviceInstance = await DeviceService.getInstance(body.deviceId)
    await repo.create(body)
    if (body.type === 'LOCATION') {
      if (deviceInstance.vehicleId) {
        let vehicleInstance = await vehicleRepo.getInstance(deviceInstance.vehicleId)
        let location = {
          latitude: body.payload.latitude,
          longitude: body.payload.longitude,
          mileage: body.payload.mileage,
          updatedAt: DateUtil.getISODate()
        }

        if (!vehicleInstance) {
          return
        }

        await vehicleRepo.partialUpdate({
          id: deviceInstance.vehicleId,
          location: location
        })
      }
    }
  }
}
