import Bb from 'bluebird'
import DynamoRepo from '../../lib/dynamo/DynamoRepo'
import Exception from '../../lib/Exception'
import DynamoHelper from '../../lib/dynamo/DynamoHelper'
import { DeviceReportSchema } from './Schema'

export class DeviceReportRepo extends DynamoRepo {
  constructor () {
    super('device_reports', DeviceReportSchema.getDynamoSchema(), {
      hashKey: 'deviceId',
      rangeKey: 'createdAt'
    })
  }

  getAll (deviceId, q) {
    return new Bb((resolve, reject) => {
      let query = this.model.query(deviceId)

      if (q.limit) {
        query.limit(q.limit)
      }

      if (q.startKey) {
        query.startKey(JSON.parse(q.startKey))
      }

      if (q.descending) {
        query.descending()
      }

      if (q.startDate && q.endDate) {
        query.where('createdAt').between(q.startDate, q.endDate)
      }

      query
        .expressionAttributeNames(DynamoHelper.getExpressionAttributeNames(q.express, {'#deviceId': 'deviceId', '#createdAt': 'createdAt'}))
        .projectionExpression(DynamoHelper.getProjectionExpression(q.express, '#deviceId,#createdAt'))
        .exec((err, results) => {
          if (err) {
            return reject(Exception.internal(err.message, err))
          }
          results.Items = results.Items.map((item) => item.attrs)
          resolve(results)
        })
    })
  }
}
