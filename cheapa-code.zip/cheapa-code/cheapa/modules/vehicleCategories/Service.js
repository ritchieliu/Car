import Exception from '../lib/Exception'
import JoiUtil from '../lib/util/JoiUtil'
import { VehicleCategoryRepo } from './Repo'
import { VehicleCategorySchema } from './Schema'
import UuidUtil from '../lib/util/UuidUtil'
import ImageService from '../lib/image/ImageService'

const repo = new VehicleCategoryRepo()

export class VehicleCategoryService {
  static async getAll (q) {
    return repo.getAll(q)
  }

  static async getInstance (id) {
    let instance = await repo.getInstance(id)
    if (!instance) {
      throw Exception.notFound()
    }
    return instance
  }

  static async create (body) {
    JoiUtil.validate(body, VehicleCategorySchema.getViewSchema())
    body.id = UuidUtil.get()
    return repo.create(body)
  }

  static async update (id, body) {
    JoiUtil.validate(body, VehicleCategorySchema.getViewSchema())
    let instance = await this.getInstance(id)
    return repo.update(Object.assign(instance, body))
  }

  static async delete (id) {
    await this.getInstance(id)
    return repo.destroy(id)
  }

  static async createImage (id, body) {
    let instance = await this.getInstance(id)
    let key = `vehicleCategories/${id}/${UuidUtil.get()}.jpg`
    let smallKey = `vehicleCategories/${id}/${UuidUtil.get()}.jpg`
    let image = await ImageService.upload({key, smallKey, body: body.body})

    if (!instance.images) {
      instance.images = []
    }
    instance.images.push(image)

    await repo.update(instance)

    return image
  }

  static async deleteImage (id, key) {
    let instance = await this.getInstance(id)
    if (!instance.images) {
      return
    }

    let image = instance.images.find(item => {
      return item.key === key
    })

    if (!image) {
      return
    }

    instance.images = instance.images.filter(item => {
      return item.key !== key
    })

    await repo.update(instance)
    await ImageService.remove({key: image.key, smallKey: image.smallKey})
  }
}
