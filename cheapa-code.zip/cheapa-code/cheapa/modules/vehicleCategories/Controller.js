import ApiLambdaHandler from '../lib/lambda/ApiLambdaHandler'
import { VehicleCategoryService } from './Service'

const runner = {
  '/vehicleCategories': {},
  '/vehicleCategories/{id}': {},
  '/vehicleCategories/{id}/images': {}
}

runner['/vehicleCategories'].GET = async (request) => {
  return VehicleCategoryService.getAll(request.q)
}

runner['/vehicleCategories/{id}'].GET = async (request) => {
  if (request.isAdmin) {
    return VehicleCategoryService.getInstance(request.path.id)
  }
}

runner['/vehicleCategories'].POST = async (request) => {
  if (request.isAdmin) {
    return VehicleCategoryService.create(request.body)
  }
}

runner['/vehicleCategories/{id}'].PUT = async (request) => {
  if (request.isAdmin) {
    return VehicleCategoryService.update(request.path.id, request.body)
  }
}

runner['/vehicleCategories/{id}'].DELETE = async (request) => {
  if (request.isAdmin) {
    return VehicleCategoryService.delete(request.path.id)
  }
}

runner['/vehicleCategories/{id}/images'].POST = async (request) => {
  if (request.isAdmin) {
    return VehicleCategoryService.createImage(request.path.id, request.body)
  }
}

runner['/vehicleCategories/{id}/images'].DELETE = async (request) => {
  if (request.isAdmin) {
    return VehicleCategoryService.deleteImage(request.path.id, request.q.key)
  }
}

module.exports.handler = ApiLambdaHandler(runner)
