import Bb from 'bluebird'
import DynamoRepo from '../lib/dynamo/DynamoRepo'
import Exception from '../lib/Exception'
import DynamoHelper from '../lib/dynamo/DynamoHelper'
import { VehicleCategorySchema } from './Schema'

export class VehicleCategoryRepo extends DynamoRepo {
  constructor () {
    super('vehicle_categories', VehicleCategorySchema.getDynamoSchema(), {
      hashKey: 'id'
    })
  }

  getAll (q) {
    return new Bb((resolve, reject) => {
      let query = this.model.scan()

      if (q.limit) {
        query.limit(q.limit)
      }

      if (q.startKey) {
        query.startKey(q.startKey)
      }

      if (q.name) {
        query.where('name').equals(q.name)
      }

      if (q.isForRent) {
        query.where('isForRent').equals(true)
        q.express += ',isForRent'
      }

      if (q.hasPricing) {
        query.where('pricing').notNull()
        q.express += ',pricing'
      }

      if (q.hasInsurance) {
        query.where('insurance').notNull()
        q.express += ',insurance'
      }

      query
        .expressionAttributeNames(DynamoHelper.getExpressionAttributeNames(q.express, {'#id': 'id'}))
        .projectionExpression(DynamoHelper.getProjectionExpression(q.express, '#id'))
        .exec((err, results) => {
          if (err) {
            return reject(Exception.internal(err.message, err))
          }
          results.Items = results.Items.map((item) => item.attrs)
          resolve(results)
        })
    })
  }
}
