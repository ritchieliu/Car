import Joi from 'joi'
import { ImageSchema } from '../lib/image/Schema'

export class VehicleCategorySchema {
  static getDynamoSchema () {
    return Joi.object().keys({
      id: Joi.string().required(),
      name: Joi.string().required(),
      description: Joi.string().allow('', null),
      location: Joi.string().allow('', null),
      isForRent: Joi.boolean().default(true),
      rentPricePerDay: Joi.number().allow(null),
      currency: this.getCurrency(),
      images: this.getImages(),
      pricing: Joi.object().allow(null),
      insurance: Joi.array().allow(null),
      createdAt: Joi.date().iso().required(),
      updatedAt: Joi.date().iso()
    })
  }

  static getViewSchema () {
    return Joi.object().keys({
      name: Joi.string().required(),
      description: Joi.string().allow('', null),
      location: Joi.string().allow('', null),
      isForRent: Joi.boolean().default(true),
      rentPricePerDay: Joi.number().allow(null),
      currency: this.getCurrency(),
      pricing: Joi.object().allow(null),
      insurance: Joi.array().allow(null)
    })
  }

  static getCurrency () {
    return Joi.string().valid(['AUD'])
  }

  static getImages () {
    return Joi.array().items(
      ImageSchema.getImage()
    )
  }
}
