import ApiLambdaHandler from '../lib/lambda/ApiLambdaHandler'
import { OrderService } from './Service'
import { BusinessService } from '../businesses/Service'

const runner = {
  '/orders': {},
  '/orders/{id}': {},
  '/orders/{id}/vehicleImages': {},
  '/orders/{id}/return': {},
  '/orders/{id}/signature': {},
  '/orders/{id}/driverLicenses': {},
  '/orders/{id}/confirmEmail': {},
  '/orders/status': {},
  '/orders/booking': {}
}

runner['/orders'].GET = async (request) => {
  if (request.isAdmin) {
    return OrderService.getAll(null, request.q)
  }
  if (request.isPartner) {
    let businessInstance = await BusinessService.getInstanceByEmail(request.authorizer.email)
    return OrderService.getAll(null, Object.assign(request.q, {businessPartnerId: businessInstance.id}))
  }
  return OrderService.getAll(request.authorizer.id, request.q)
}

runner['/orders/{id}'].GET = async (request) => {
  if (request.isAdmin) {
    return OrderService.getInstance(request.q.accountId, request.path.id)
  }
  return OrderService.getInstance(request.authorizer.id, request.path.id)
}

runner['/orders'].POST = async (request) => {
  if (request.isAdmin) {
    return OrderService.adminSave({}, request.body)
  }

  // Stop order with payment
  // request.body.email = request.authorizer.email
  // return OrderService.create(request.body)
  throw new Error('Not supported')
}

runner['/orders/booking'].POST = async (request) => {
  return OrderService.clientBooking(request.body)
}

runner['/orders/{id}'].PUT = async (request) => {
  if (request.isAdmin) {
    return OrderService.adminSave({accountId: request.q.accountId, createdAt: request.path.id}, request.body)
  }
}

runner['/orders/{id}'].DELETE = async (request) => {
  if (request.isAdmin) {
    return OrderService.delete(request.path.id)
  }
}

runner['/orders/{id}/vehicleImages'].POST = async (request) => {
  if (request.isAdmin) {
    return OrderService.createVehicleImage(request.q.accountId, request.path.id, request.body)
  }
  return OrderService.createVehicleImage(request.authorizer.id, request.path.id, request.body)
}

runner['/orders/{id}/vehicleImages'].DELETE = async (request) => {
  if (request.isAdmin) {
    return OrderService.deleteVehicleImage(request.q.accountId, request.path.id, request.q.type)
  }
  return OrderService.deleteVehicleImage(request.authorizer.id, request.path.id, request.q.type)
}

runner['/orders/{id}/return'].POST = async (request) => {
  return OrderService.confirmReturn(request.authorizer.id, request.path.id, request.body)
}

runner['/orders/{id}/signature'].POST = async (request) => {
  return OrderService.createSignature(request.authorizer.id, request.path.id, request.body)
}

runner['/orders/{id}/driverLicenses'].POST = async (request) => {
  if (request.isAdmin) {
    return OrderService.createDriverLicense(request.q.accountId, request.path.id, request.body)
  }
  return OrderService.createDriverLicense(request.authorizer.id, request.path.id, request.body)
}

runner['/orders/{id}/driverLicenses'].DELETE = async (request) => {
  if (request.isAdmin) {
    return OrderService.deleteDriverLicense(request.q.accountId, request.path.id, request.q.key)
  }
  return OrderService.deleteDriverLicense(request.authorizer.id, request.path.id, request.q.key)
}

runner['/orders/{id}/confirmEmail'].POST = async (request) => {
  if (request.isAdmin) {
    return OrderService.confirmEmail(request.q.accountId, request.path.id)
  }
}

runner['/orders/status'].POST = async (request) => {
  if (request.isAdmin) {
    return OrderService.updateStatus(request.body)
  }
}

module.exports.handler = ApiLambdaHandler(runner)
