import Joi from 'joi'
import { ImageSchema } from '../lib/image/Schema'

export class OrderSchema {
  static getDynamoSchema () {
    return Joi.object().keys({
      accountId: Joi.string().required(),
      email: Joi.string().email().lowercase().trim().required(),
      firstName: Joi.string().allow('', null),
      lastName: Joi.string().allow('', null),
      mobile: Joi.string().allow('', null),
      vehicleId: Joi.string().allow('', null),
      vehicleCategoryId: Joi.string().allow('', null),
      vehicleCategoryName: Joi.string().allow('', null),
      vehicleOdometerStart: Joi.number().allow(null),
      vehicleOdometerEnd: Joi.number().allow(null),
      pickUpDate: Joi.date().iso().required(),
      dropOffDate: Joi.date().iso().required(),
      driverAge: Joi.boolean(),
      insurance: Joi.boolean(),
      roadSideAssistant: Joi.boolean(),
      additionalDriver: Joi.boolean(),
      childSeatSmall: Joi.boolean(),
      childSeatLarge: Joi.boolean(),
      gps: Joi.boolean(),
      mobilePhoneHolder: Joi.boolean(),
      tyreWindscreenCover: Joi.boolean(),
      unlimitedDistance: Joi.boolean(),
      rentDays: Joi.number(),
      payment: this.getPaymentDynamoSchema(),
      status: this.getStatus(),
      source: Joi.string().allow('', null),
      vehicleImages: this.getVehicleImages(),
      vehicleReturnedAt: Joi.date().iso(),
      vehicleChecks: this.getVehicleChecks(),
      pickUpLocation: this.getLocationPayload(),
      dropOffLocation: this.getLocationPayload(),
      signature: ImageSchema.getImage(),
      driverLicenses: Joi.array().items(
        ImageSchema.getImage()
      ),
      businessPartnerId: Joi.string().allow('', null),
      comment: Joi.string().allow('', null),
      createdAt: Joi.date().iso().required(),
      updatedAt: Joi.date().iso()
    })
  }

  static getViewSchema () {
    return Joi.object().keys({
      email: Joi.string().email().lowercase().trim().required(),
      vehicleId: Joi.string().required(),
      pickUpDate: Joi.date().iso().required(),
      dropOffDate: Joi.date().iso().required(),
      driverAge: Joi.boolean(),
      insurance: Joi.boolean(),
      payment: this.getPaymentViewSchema()
    })
  }

  static getAdminViewSchema () {
    return Joi.object().keys({
      email: Joi.string().email().lowercase().trim().required(),
      firstName: Joi.string().allow('', null),
      lastName: Joi.string().allow('', null),
      mobile: Joi.string().allow('', null),
      vehicleId: Joi.string().allow('', null),
      vehicleCategoryId: Joi.string().required(),
      vehicleCategoryName: Joi.string().allow('', null),
      vehicleOdometerStart: Joi.number().allow(null),
      vehicleOdometerEnd: Joi.number().allow(null),
      pickUpDate: Joi.date().iso().required(),
      dropOffDate: Joi.date().iso().required(),
      pickUpLocation: this.getLocationPayload(),
      dropOffLocation: this.getLocationPayload(),
      driverAge: Joi.boolean(),
      insurance: Joi.boolean(),
      roadSideAssistant: Joi.boolean(),
      additionalDriver: Joi.boolean(),
      childSeatSmall: Joi.boolean(),
      childSeatLarge: Joi.boolean(),
      gps: Joi.boolean(),
      mobilePhoneHolder: Joi.boolean(),
      tyreWindscreenCover: Joi.boolean(),
      unlimitedDistance: Joi.boolean(),
      source: Joi.string().allow('', null),
      discount: Joi.number(),
      businessPartnerId: Joi.string().allow('', null),
      comment: Joi.string().allow('', null)
    })
  }

  static getClientBookingSchema () {
    return Joi.object().keys({
      email: Joi.string().email().lowercase().trim().required(),
      firstName: Joi.string().required(),
      lastName: Joi.string().required(),
      mobile: Joi.string().required(),
      vehicleCategoryId: Joi.string().required(),
      pickUpDate: Joi.date().iso().required(),
      dropOffDate: Joi.date().iso().required(),
      pickUpLocation: this.getLocationPayload(),
      dropOffLocation: this.getLocationPayload(),
      driverAge: Joi.boolean(),
      insurance: Joi.boolean(),
      roadSideAssistant: Joi.boolean(),
      additionalDriver: Joi.boolean(),
      childSeatSmall: Joi.boolean(),
      childSeatLarge: Joi.boolean(),
      gps: Joi.boolean(),
      mobilePhoneHolder: Joi.boolean(),
      tyreWindscreenCover: Joi.boolean(),
      unlimitedDistance: Joi.boolean(),
      source: Joi.string().allow('', null),
      discount: Joi.number().valid(0),
      businessPartnerId: Joi.string().allow('', null)
    })
  }

  static getStatusSchema () {
    return Joi.object().keys({
      accountId: Joi.string().required(),
      createdAt: Joi.date().iso().required(),
      status: this.getStatus()
    })
  }

  static getPaymentDynamoSchema () {
    return Joi.object().keys({
      stripeChargeId: Joi.string(),
      stripeSourceId: Joi.string(),
      stripeCustomerId: Joi.string(),
      amount: Joi.number().required(),
      currency: this.getCurrency(),
      discount: Joi.number(),
      cardHolderName: Joi.string(),
      last4: Joi.string(),
      cardExpMonth: Joi.number(),
      cardExpYear: Joi.number(),
      bond: Joi.number(),
      bondStripeChargeId: Joi.string(),
      rentalPrice: Joi.number(),
      insurancePrice: Joi.number(),
      youngDriverCharge: Joi.number(),
      roadSideAssistantCharge: Joi.number(),
      additionalDriverCharge: Joi.number(),
      childSeatSmallCharge: Joi.number(),
      childSeatLargeCharge: Joi.number(),
      gpsCharge: Joi.number(),
      mobilePhoneHolderCharge: Joi.number(),
      tyreWindscreenCoverCharge: Joi.number(),
      unlimitedDistanceCharge: Joi.number(),
      differentLocationCharge: Joi.number()
    })
  }

  static getPaymentViewSchema () {
    return Joi.object().keys({
      amount: Joi.number().required(),
      currency: this.getCurrency(),
      cardHolderName: Joi.string(),
      cardNumber: Joi.string().required(),
      cardExpMonth: Joi.number().required(),
      cardExpYear: Joi.number().required(),
      cardCvc: Joi.number().required()
    }).required()
  }

  static getVehicleImageViewSchema () {
    return Joi.object().keys({
      body: Joi.string().required(),
      type: Joi.string().valid(['FRONT_RIGHT', 'FRONT_LEFT', 'BACK_RIGHT', 'BACK_LEFT', 'DASHBOARD', 'KEY']).required()
    })
  }

  static getVehicleChecks () {
    return Joi.object().keys({
      isReturnedToLocation: Joi.boolean().required(),
      isClean: Joi.boolean().required(),
      isFullFuel: Joi.boolean().required()
    })
  }

  static getLocationPayload () {
    return Joi.object().keys({
      name: Joi.string(),
      city: Joi.string().allow('', null),
      latitude: Joi.number(),
      longitude: Joi.number(),
      updatedAt: Joi.date().iso()
    })
  }

  static getCurrency () {
    return Joi.string().valid(['AUD', 'USD', 'CNY']).required()
  }

  static getStatus () {
    return Joi.string().valid(['RESERVED', 'ACTIVE', 'VEHICLE_RETURNED', 'COMPLETED', 'CANCELLED']).required()
  }

  static getVehicleImages () {
    return Joi.object().keys({
      FRONT_RIGHT: ImageSchema.getImage(),
      FRONT_LEFT: ImageSchema.getImage(),
      BACK_RIGHT: ImageSchema.getImage(),
      BACK_LEFT: ImageSchema.getImage(),
      DASHBOARD: ImageSchema.getImage(),
      KEY: ImageSchema.getImage()
    })
  }
}
