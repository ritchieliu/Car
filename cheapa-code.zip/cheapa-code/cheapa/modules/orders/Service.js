import Exception from '../lib/Exception'
import JoiUtil from '../lib/util/JoiUtil'
import { OrderRepo } from './Repo'
import { OrderSchema } from './Schema'
import { AccountRepo } from '../accounts/Repo'
import UuidUtil from '../lib/util/UuidUtil'
import LambdaService from '../lib/lambda/LambdaService'
import { VehicleService } from '../vehicles/Service'
import DateUtil from '../lib/util/DateUtil'
import { VehicleRepo } from '../vehicles/Repo'
import ImageService from '../lib/image/ImageService'
import { BusinessService } from '../businesses/Service'
import util from 'util'
import { VehicleCategoryService } from '../vehicleCategories/Service'
import { SesService } from '../lib/ses/SesService'
import { OrderFeeService } from './OrderFeeService'

const repo = new OrderRepo()
const accountRepo = new AccountRepo()
const vehicleRepo = new VehicleRepo()

export class OrderService {
  static async getAll (accountId, q) {
    if (accountId) {
      return repo.getAllByAccountId(accountId, q)
    }
    return repo.getAll(q)
  }

  static async getInstance (accountId, createdAt) {
    let instance = await repo.getInstance(accountId, createdAt)
    if (!instance) {
      throw Exception.notFound()
    }
    return instance
  }

  static async clientBooking (body) {
    JoiUtil.validate(body, OrderSchema.getClientBookingSchema())
    return this.save({}, body)
  }

  static async adminSave ({accountId, createdAt}, body) {
    JoiUtil.validate(body, OrderSchema.getAdminViewSchema())
    return this.save({accountId, createdAt}, body)
  }

  static async save ({accountId, createdAt}, body) {
    let isCreate = false
    let orderStatus
    if (accountId && createdAt) {
      let originalOrder = await OrderService.getInstance(accountId, createdAt)
      orderStatus = originalOrder.status
      createdAt = originalOrder.createdAt
    } else {
      isCreate = true
      orderStatus = 'RESERVED'
      createdAt = DateUtil.getISODate()
    }

    let vehicleCategoryInstance = await VehicleCategoryService.getInstance(body.vehicleCategoryId)

    let currency = vehicleCategoryInstance.currency
    body.vehicleCategoryName = vehicleCategoryInstance.name

    // Find email from account
    let accountInstance = await accountRepo.getInstanceByFriendlyId(body.email)

    // Create account if not exists
    if (!accountInstance) {
      let tempPassword = Math.floor(100000 + Math.random() * 900000).toString()
      accountInstance = await accountRepo.create({
        id: UuidUtil.get(),
        friendly_id: body.email,
        temp_password: tempPassword
      })

      // Sign up in cognito
      LambdaService.invoke({
        FunctionName: process.env.LAMBDA_COGNITO_FUNCTION_ARN,
        InvocationType: 'Event',
        Payload: JSON.stringify({
          resource: '/accounts/cognito/signUp',
          httpMethod: 'POST',
          body: JSON.stringify({
            id: accountInstance.id,
            email: body.email,
            tempPassword: tempPassword
          })
        })
      })
    }

    // Find business partner
    if (body.businessPartnerId) {
      let businessInstance = await BusinessService.getInstance(body.businessPartnerId)
      body.source = businessInstance.name
    }

    // Calculate price
    let rentDays = OrderFeeService.calculateRentDays(body.pickUpDate, body.dropOffDate)
    let rentPricePerDay = OrderFeeService.calculateRentPricePerDay(rentDays, vehicleCategoryInstance.pricing)
    let insuranceObject = OrderFeeService.calculateInsuranceObject(rentDays, vehicleCategoryInstance.insurance, body.insurance)
    let totalPrice = Math.round(OrderFeeService.calculateTotalPrice({
      pickUpLocation: body.pickUpLocation,
      dropOffLocation: body.dropOffLocation,
      insurancePrice: insuranceObject.price,
      driverAge: body.driverAge,
      roadSideAssistant: body.roadSideAssistant,
      additionalDriver: body.additionalDriver,
      childSeatSmall: body.childSeatSmall,
      childSeatLarge: body.childSeatLarge,
      gps: body.gps,
      mobilePhoneHolder: body.mobilePhoneHolder,
      tyreWindscreenCover: body.tyreWindscreenCover,
      unlimitedDistance: body.unlimitedDistance,
      rentDays: rentDays,
      rentPricePerDay: rentPricePerDay,
      discount: body.discount
    }) * 100)

    // Create Order
    let order = {
      accountId: accountInstance.id,
      createdAt: createdAt,
      email: body.email,
      mobile: body.mobile,
      firstName: body.firstName,
      lastName: body.lastName,
      vehicleId: body.vehicleId,
      vehicleCategoryId: body.vehicleCategoryId,
      vehicleCategoryName: body.vehicleCategoryName,
      vehicleOdometerStart: body.vehicleOdometerStart,
      vehicleOdometerEnd: body.vehicleOdometerEnd,
      pickUpDate: body.pickUpDate,
      dropOffDate: body.dropOffDate,
      pickUpLocation: body.pickUpLocation,
      dropOffLocation: body.dropOffLocation,
      driverAge: body.driverAge,
      insurance: body.insurance,
      roadSideAssistant: body.roadSideAssistant,
      additionalDriver: body.additionalDriver,
      childSeatSmall: body.childSeatSmall,
      childSeatLarge: body.childSeatLarge,
      gps: body.gps,
      mobilePhoneHolder: body.mobilePhoneHolder,
      tyreWindscreenCover: body.tyreWindscreenCover,
      unlimitedDistance: body.unlimitedDistance,
      rentDays: rentDays,
      payment: {
        amount: totalPrice,
        currency: currency,
        bond: insuranceObject.bond * 100,
        rentalPrice: OrderFeeService.calculateRental(rentDays, rentPricePerDay) * 100,
        insurancePrice: OrderFeeService.calculateInsurance(rentDays, insuranceObject.price) * 100,
        youngDriverCharge: OrderFeeService.calculateChargeByType(rentDays, 'AGE_RENTAL_PRICE', body.driverAge) * 100,
        roadSideAssistantCharge: OrderFeeService.calculateChargeByType(rentDays, 'ROADSIDE_ASSISTANT', body.roadSideAssistant) * 100,
        additionalDriverCharge: OrderFeeService.calculateChargeByType(rentDays, 'ADDITIONAL_DRIVER', body.additionalDriver) * 100,
        childSeatSmallCharge: OrderFeeService.calculateChargeByType(rentDays, 'CHILD_SEAT_SMALL', body.childSeatSmall) * 100,
        childSeatLargeCharge: OrderFeeService.calculateChargeByType(rentDays, 'CHILD_SEAT_LARGE', body.childSeatLarge) * 100,
        gpsCharge: OrderFeeService.calculateChargeByType(rentDays, 'GPS', body.gps) * 100,
        mobilePhoneHolderCharge: OrderFeeService.calculateChargeByType(rentDays, 'MOBILE_PHONE_HOLDER', body.mobilePhoneHolder) * 100,
        tyreWindscreenCoverCharge: OrderFeeService.calculateChargeByType(rentDays, 'TYRE_WINDSCREEN_COVER', body.tyreWindscreenCover) * 100,
        unlimitedDistanceCharge: OrderFeeService.calculateChargeByType(rentDays, 'UNLIMITED_DISTANCE', body.unlimitedDistance) * 100,
        differentLocationCharge: OrderFeeService.calculateDropOffPrice(body.pickUpLocation, body.dropOffLocation) * 100,
        discount: body.discount * 100
      },
      status: orderStatus,
      source: body.source,
      businessPartnerId: body.businessPartnerId,
      comment: body.comment
    }

    if (isCreate) {
      await repo.create(order)
      await this.notifyOrderToAdmin({
        'email': order.email,
        'vehicleCategoryName': order.vehicleCategoryName,
        'vehicleId': order.vehicleId ? order.vehicleId : 'N/A'
      })
    } else {
      await repo.update(order)
    }

    return order
  }

  static async notifyOrderToAdmin ({email, vehicleCategoryName, vehicleId}) {
    let toEmailAddress = process.env.RECEIVER_EMAIL_ADDRESS
    if (process.env.STAGE === 'prod') {
      toEmailAddress = process.env.INFO_EMAIL_ADDRESS
    }

    await SesService.send({
      fromAddress: process.env.INFO_EMAIL_ADDRESS,
      toAddress: toEmailAddress,
      templateName: process.env.ORDER_CREATED_TEMPLATE_NAME,
      templateData: {
        'email': email,
        'vehicleCategoryName': vehicleCategoryName,
        'vehicleId': vehicleId
      }
    })
  }

  // static async create (body) {
  //   JoiUtil.validate(body, OrderSchema.getViewSchema())
  //
  //   // Validate vehicle Id
  //   let vehicleInstance = await VehicleService.getInstance(body.vehicleId)
  //
  //   // Validate vehicle
  //   if (vehicleInstance.operationStatus !== 'AVAILABLE') {
  //     throw Exception.conflict('This vehicle has been ordered. Please pick up another one.')
  //   }
  //
  //   // Fetch business partner
  //   let businessInstance
  //   if (vehicleInstance.businessPartnerId) {
  //     businessInstance = await BusinessService.getInstance(vehicleInstance.businessPartnerId)
  //   }
  //
  //   // Find email from account
  //   let accountInstance = await accountRepo.getInstanceByFriendlyId(body.email)
  //
  //   body.pickUpDate = DateUtil.getISODate()
  //   body.rentPricePerDay = vehicleInstance.rentPricePerDay
  //   let rentDays = OrderFeeService.calculateRentDays(body.pickUpDate, body.dropOffDate)
  //   let totalBond = Math.round(OrderFeeService.calculateTotalBond(body) * 100)
  //   let totalPrice = Math.round(OrderFeeService.calculateTotalPrice(body) * 100)
  //   let currency = vehicleInstance.currency
  //   let bondCharge
  //   let priceCharge
  //
  //   // Validate amount
  //   if (totalPrice + totalBond !== body.payment.amount) {
  //     throw Exception.conflict('Invalid payment amount')
  //   }
  //
  //   try {
  //     // Create bond charge
  //     bondCharge = await PaymentService.charge(process.env.LAMBDA_PAYMENT_FUNCTION_ARN, {
  //       amount: totalBond,
  //       currency: currency,
  //       statement_descriptor: 'Cheapa Car Bond',
  //       email: accountInstance.email,
  //       receipt_email: accountInstance.email,
  //       card: {
  //         object: 'card',
  //         number: body.payment.cardNumber,
  //         exp_month: body.payment.cardExpMonth,
  //         exp_year: body.payment.cardExpYear,
  //         cvc: body.payment.cardCvc
  //       }
  //     })
  //
  //     // Create rental charge
  //     let priceChargeBody = {
  //       stripeCustomerId: bondCharge.customer,
  //       stripeCardId: bondCharge.source.id,
  //       amount: totalPrice,
  //       currency: currency,
  //       statement_descriptor: 'Cheapa Car Rental',
  //       receipt_email: accountInstance.email
  //     }
  //
  //     if (businessInstance) {
  //       priceChargeBody.destination = {
  //         account: businessInstance.stripeAccountId,
  //         amount: Math.round(totalPrice * businessInstance.commissionRate)
  //       }
  //     }
  //
  //     priceCharge = await PaymentService.charge(process.env.LAMBDA_PAYMENT_FUNCTION_ARN, priceChargeBody)
  //
  //     // Save order
  //     let order = {
  //       accountId: accountInstance.id,
  //       email: accountInstance.email,
  //       vehicleId: body.vehicleId,
  //       pickUpDate: body.pickUpDate,
  //       dropOffDate: body.dropOffDate,
  //       pickUpLocation: vehicleInstance.location,
  //       dropOffLocation: vehicleInstance.location,
  //       driverAge: body.driverAge,
  //       insurance: body.insurance,
  //       rentDays: rentDays,
  //       payment: {
  //         stripeChargeId: priceCharge.id,
  //         stripeSourceId: priceCharge.source.id,
  //         stripeCustomerId: priceCharge.customer,
  //         amount: priceCharge.amount,
  //         currency: currency,
  //         last4: priceCharge.source.last4,
  //         cardExpMonth: priceCharge.source.exp_month,
  //         cardExpYear: priceCharge.source.exp_year,
  //         bond: bondCharge.amount,
  //         bondStripeChargeId: bondCharge.id,
  //         rentalPrice: OrderFeeService.calculateRental(rentDays, body.rentPricePerDay) * 100,
  //         insurancePrice: OrderFeeService.calculateInsurance(rentDays, body.insurance) * 100,
  //         youngDriverCharge: OrderFeeService.calculateChargeByType(rentDays, 'AGE_RENTAL_PRICE', body.driverAge) * 100
  //       },
  //       status: 'ACTIVE',
  //       createdAt: DateUtil.getISODate()
  //     }
  //     await repo.create(order)
  //
  //     // Update vehicle status
  //     this.setVehicleOperationStatus(vehicleInstance, 'ACTIVE')
  //     await vehicleRepo.update(vehicleInstance)
  //
  //     if (!process.env.TEST_ACCOUNTS.includes(accountInstance.email)) {
  //       await PaymentService.capture(process.env.LAMBDA_PAYMENT_FUNCTION_ARN, priceCharge.id)
  //     }
  //
  //     // Notify admin
  //     await this.notifyOrderToAdmin({
  //       'email': accountInstance.email,
  //       'vehicleCategoryName': vehicleInstance.vehicleCategoryName,
  //       'vehicleId': vehicleInstance.id
  //     })
  //
  //     return {
  //       accountId: order.accountId,
  //       createdAt: order.createdAt
  //     }
  //   } catch (e) {
  //     if (bondCharge) {
  //       await PaymentService.refund(process.env.LAMBDA_PAYMENT_FUNCTION_ARN, bondCharge.id)
  //     }
  //     if (priceCharge) {
  //       await PaymentService.refund(process.env.LAMBDA_PAYMENT_FUNCTION_ARN, priceCharge.id)
  //     }
  //     throw Exception.conflict(e.message)
  //   }
  // }

  // static async update (id, body) {
  //   JoiUtil.validate(body, OrderSchema.getViewSchema())
  //   let instance = await this.getInstance(id)
  //   return repo.update(Object.assign(instance, body))
  // }

  static async updateStatus (body) {
    JoiUtil.validate(body, OrderSchema.getStatusSchema())
    let instance = await this.getInstance(body.accountId, body.createdAt)

    if ((instance.status === 'ACTIVE' || instance.status === 'VEHICLE_RETURNED') && body.status === 'COMPLETED') {
    }

    if ((instance.status === 'ACTIVE' || instance.status === 'VEHICLE_RETURNED') && body.status === 'CANCELLED') {
    }
    instance.status = body.status

    if (instance.vehicleId) {
      let vehicleInstance = await VehicleService.getInstance(instance.vehicleId)
      this.setVehicleOperationStatus(vehicleInstance, body.status)
      await vehicleRepo.update(vehicleInstance)
    }

    return repo.update(instance)
  }

  static async delete (id) {
    await this.getInstance(id)
    return repo.destroy(id)
  }

  static setVehicleOperationStatus (vehicle, orderStatus) {
    if (orderStatus === 'ACTIVE') {
      vehicle.operationStatus = 'IN_USE'
    } else if (orderStatus === 'CANCELLED' || orderStatus === 'COMPLETED') {
      vehicle.operationStatus = 'AVAILABLE'
    }
  }

  static async confirmReturn (accountId, createdAt, body) {
    let instance = await this.getInstance(accountId, createdAt)
    let vehicleInstance = await VehicleService.getInstance(instance.vehicleId)
    if (instance.status !== 'ACTIVE') {
      throw Exception.conflict('Invalid Order Status')
    }
    if (!(instance.vehicleImages &&
        instance.vehicleImages.FRONT_RIGHT &&
        instance.vehicleImages.FRONT_LEFT &&
        instance.vehicleImages.BACK_RIGHT &&
        instance.vehicleImages.BACK_LEFT &&
        instance.vehicleImages.DASHBOARD &&
        instance.vehicleImages.KEY)) {
      throw Exception.conflict('Missing Vehicle Images')
    }

    instance.status = 'VEHICLE_RETURNED'
    instance.vehicleReturnedAt = DateUtil.getISODate()
    instance.vehicleChecks = body
    instance.dropOffLocation = vehicleInstance.location

    // Notify admin
    let toEmailAddress = process.env.RECEIVER_EMAIL_ADDRESS
    if (process.env.STAGE === 'prod') {
      toEmailAddress = process.env.INFO_EMAIL_ADDRESS
    }

    await LambdaService.invoke({
      FunctionName: process.env.SES_SEND_FUNCTION_ARN,
      InvocationType: 'Event',
      Payload: JSON.stringify({
        'fromAddress': process.env.INFO_EMAIL_ADDRESS,
        'toAddress': toEmailAddress,
        'templateName': process.env.ORDER_RETURNED_TEMPLATE_NAME,
        'templateData': {
          'email': instance.email,
          'vehicleId': vehicleInstance.id
        }
      })
    }, 'us-east-1')

    await repo.update(instance)
  }

  static async createVehicleImage (accountId, createdAt, body) {
    JoiUtil.validate(body, OrderSchema.getVehicleImageViewSchema())
    let instance = await this.getInstance(accountId, createdAt)
    let key = `orders/${accountId}/${UuidUtil.get()}.jpg`
    let smallKey = `orders/${accountId}/${UuidUtil.get()}.jpg`
    let image = await ImageService.upload({key, smallKey, body: body.body})

    if (!instance.vehicleImages) {
      instance.vehicleImages = {}
    }

    instance.vehicleImages[body.type] = image
    await repo.update(instance)

    return image
  }

  static async deleteVehicleImage (accountId, createdAt, type) {
    let instance = await this.getInstance(accountId, createdAt)
    if (!instance.vehicleImages || !instance.vehicleImages[type]) {
      return
    }

    let image = instance.vehicleImages[type]
    delete instance.vehicleImages[type]
    await repo.update(instance)
    await ImageService.remove({key: image.key, smallKey: image.smallKey})
  }

  static async createSignature (accountId, createdAt, body) {
    let instance = await this.getInstance(accountId, createdAt)
    let key = `orders/${accountId}/${UuidUtil.get()}.jpg`
    let image = await ImageService.upload({key, body: body.body})

    instance.signature = image
    await repo.update(instance)

    return image
  }

  static async createDriverLicense (accountId, createdAt, body) {
    let instance = await this.getInstance(accountId, createdAt)
    let key = `orders/${accountId}/${UuidUtil.get()}.jpg`
    let smallKey = `orders/${accountId}/${UuidUtil.get()}.jpg`
    let image = await ImageService.upload({key, smallKey, body: body.body})

    if (!instance.driverLicenses) {
      instance.driverLicenses = []
    }
    instance.driverLicenses.push(image)

    await repo.update(instance)

    return image
  }

  static async deleteDriverLicense (accountId, createdAt, key) {
    let instance = await this.getInstance(accountId, createdAt)
    if (!instance.driverLicenses) {
      return
    }

    let image = instance.driverLicenses.find(item => {
      return item.key === key
    })

    if (!image) {
      return
    }

    instance.driverLicenses = instance.driverLicenses.filter(item => {
      return item.key !== key
    })

    await repo.update(instance)
    await ImageService.remove({key: image.key, smallKey: image.smallKey})
  }

  static async confirmEmail (accountId, createdAt) {
    let instance = await this.getInstance(accountId, createdAt)
    let account = await accountRepo.getInstanceByFriendlyId(instance.email)
    // Send user order email
    await LambdaService.invoke({
      FunctionName: process.env.SES_SEND_FUNCTION_ARN,
      InvocationType: 'Event',
      Payload: JSON.stringify({
        'fromAddress': process.env.INFO_EMAIL_ADDRESS,
        'toAddress': instance.email,
        'templateName': process.env.ORDER_CONFIRM_TEMPLATE_NAME,
        'templateData': {
          'confirmUrl': util.format(process.env.ORDER_CONFIRM_EMAIL_CONFIRM_URL, instance.createdAt),
          'activateAccountUrl': util.format(process.env.ORDER_CONFIRM_EMAIL_ACTIVATE_ACCOUNT_URL, account.id, account.temp_password),
          'isAccountActive': account.refresh_token || ''
        }
      })
    }, 'us-east-1')
  }
}
