import moment from 'moment'
import DateUtil from '../lib/util/DateUtil'

const AGE_RENTAL = 10
const ROADSIDE_ASSISTANT = 5.5
const ADDITIONAL_DRIVER = 5
const CHILD_SEAT_SMALL = 10
const CHILD_SEAT_LARGE = 10
const GPS = 5
const MOBILE_PHONE_HOLDER = 1
const TYRE_WINDSCREEN_COVER = 5.5
const UNLIMITED_DISTANCE = 20

const LOCATIONS = [
  {
    name: 'NSW - Greenacre',
    city: 'Sydney',
    dropOffCities: [
      {city: 'Sydney', price: 0},
      {city: 'Melbourne', price: 410},
      {city: 'Gold Coast', price: 450}
    ]
  },
  {
    name: 'NSW - Sydney Airport',
    city: 'Sydney',
    dropOffCities: [
      {city: 'Sydney', price: 0},
      {city: 'Melbourne', price: 410},
      {city: 'Gold Coast', price: 450}
    ]
  },
  {
    name: 'NSW - Carlingford',
    city: 'Sydney',
    dropOffCities: [
      {city: 'Sydney', price: 0},
      {city: 'Melbourne', price: 410},
      {city: 'Gold Coast', price: 450}
    ]
  },
  {
    name: 'QLD - Gold Coast Airport',
    city: 'Gold Coast',
    dropOffCities: [
      {city: 'Sydney', price: 450},
      {city: 'Melbourne', price: 530},
      {city: 'Gold Coast', price: 0}
    ]
  },
  {
    name: 'QLD - Gold Coast City',
    city: 'Gold Coast',
    dropOffCities: [
      {city: 'Sydney', price: 450},
      {city: 'Melbourne', price: 530},
      {city: 'Gold Coast', price: 0}
    ]
  },
  {
    name: 'VIC - Melbourne Boxing Hill',
    city: 'Melbourne',
    dropOffCities: [
      {city: 'Sydney', price: 410},
      {city: 'Melbourne', price: 0},
      {city: 'Gold Coast', price: 530}
    ]
  },
  {
    name: 'VIC - Melbourne City',
    city: 'Melbourne',
    dropOffCities: [
      {city: 'Sydney', price: 410},
      {city: 'Melbourne', price: 0},
      {city: 'Gold Coast', price: 530}
    ]
  },
  {
    name: 'VIC - Melbourne Airport',
    city: 'Melbourne',
    dropOffCities: [
      {city: 'Sydney', price: 410},
      {city: 'Melbourne', price: 0},
      {city: 'Gold Coast', price: 530}
    ]
  }
]

export class OrderFeeService {
  static calculateRentDays (pickUpDate, dropOffDate) {
    let rentHours = Math.round(moment.duration(DateUtil.toDate(dropOffDate).diff(DateUtil.toDate(pickUpDate))).asHours())

    if (rentHours <= 25) {
      return 1
    }

    let day = Math.floor(rentHours / 24)

    if (rentHours % 24 === 0) {
    } else if (rentHours % 24 <= 4) {
      day += 0.5
    } else {
      day += 1
    }

    return day
  }

  static calculateRentPricePerDay (rentDays, pricing) {
    let pricingItem = pricing.common.find(item => item.day === Math.floor(rentDays))
    if (!pricingItem) {
      pricingItem = pricing.common[pricing.common.length - 1]
    }
    return pricingItem.price
  }

  static calculateChargeByType (rentDays, type, applied) {
    if (!applied) {
      return 0
    }
    switch (type) {
      case 'AGE_RENTAL_PRICE':
        return AGE_RENTAL * rentDays
      case 'ROADSIDE_ASSISTANT':
        return ROADSIDE_ASSISTANT * rentDays
      case 'ADDITIONAL_DRIVER':
        return ADDITIONAL_DRIVER * rentDays
      case 'CHILD_SEAT_SMALL':
        return CHILD_SEAT_SMALL * rentDays
      case 'CHILD_SEAT_LARGE':
        return CHILD_SEAT_LARGE * rentDays
      case 'GPS':
        return GPS * rentDays
      case 'MOBILE_PHONE_HOLDER':
        return MOBILE_PHONE_HOLDER * rentDays
      case 'TYRE_WINDSCREEN_COVER':
        return TYRE_WINDSCREEN_COVER * rentDays
      case 'UNLIMITED_DISTANCE':
        return UNLIMITED_DISTANCE * rentDays
    }
    return 0
  }

  static calculateRental (rentDays, rentPricePerDay) {
    return rentPricePerDay * rentDays
  }

  static calculateYoungDriverCharge (rentDays, driverAge) {
    if (driverAge) {
      return AGE_RENTAL * rentDays
    }
    return 0
  }

  static calculateInsuranceObject (rentDays, insurance, insuranceApplied) {
    let pricingItem = insurance.find(item => item.day === Math.floor(rentDays))
    if (!pricingItem) {
      pricingItem = insurance[insurance.length - 1]
    }

    if (insuranceApplied) {
      return pricingItem
    } else {
      return {
        price: 0,
        bond: pricingItem.maxBond
      }
    }
  }

  static calculateInsurance (rentDays, insurance) {
    return insurance * rentDays
  }

  static calculateDropOffPrice (pickUpLocation, dropOffLocation) {
    let pickUp = LOCATIONS.find(item => item.name === pickUpLocation.name)
    let dropOff = LOCATIONS.find(item => item.name === dropOffLocation.name)
    return pickUp.dropOffCities.find(item => item.city === dropOff.city).price
  }

  static calculateTotalPrice ({pickUpLocation, dropOffLocation, insurancePrice, driverAge, roadSideAssistant, additionalDriver, childSeatSmall, childSeatLarge, gps, mobilePhoneHolder, tyreWindscreenCover, unlimitedDistance, rentDays, rentPricePerDay, discount = 0}) {
    let rentalPrice = OrderFeeService.calculateRental(rentDays, rentPricePerDay)
    let insuranceCharge = this.calculateInsurance(rentDays, insurancePrice)
    let youngDriverCharge = OrderFeeService.calculateChargeByType(rentDays, 'AGE_RENTAL_PRICE', driverAge)
    let roadSideAssistantCharge = OrderFeeService.calculateChargeByType(rentDays, 'ROADSIDE_ASSISTANT', roadSideAssistant)
    let additionalDriverCharge = OrderFeeService.calculateChargeByType(rentDays, 'ADDITIONAL_DRIVER', additionalDriver)
    let childSeatSmallCharge = OrderFeeService.calculateChargeByType(rentDays, 'CHILD_SEAT_SMALL', childSeatSmall)
    let childSeatLargeCharge = OrderFeeService.calculateChargeByType(rentDays, 'CHILD_SEAT_LARGE', childSeatLarge)
    let gpsCharge = OrderFeeService.calculateChargeByType(rentDays, 'GPS', gps)
    let mobilePhoneHolderCharge = OrderFeeService.calculateChargeByType(rentDays, 'MOBILE_PHONE_HOLDER', mobilePhoneHolder)
    let tyreWindscreenCoverCharge = OrderFeeService.calculateChargeByType(rentDays, 'TYRE_WINDSCREEN_COVER', tyreWindscreenCover)
    let unlimitedDistanceCharge = OrderFeeService.calculateChargeByType(rentDays, 'UNLIMITED_DISTANCE', unlimitedDistance)
    let differentLocationCharge = OrderFeeService.calculateDropOffPrice(pickUpLocation, dropOffLocation)
    return rentalPrice + insuranceCharge + youngDriverCharge + roadSideAssistantCharge +
      additionalDriverCharge + childSeatSmallCharge + childSeatLargeCharge +
      gpsCharge + mobilePhoneHolderCharge + tyreWindscreenCoverCharge +
      unlimitedDistanceCharge + differentLocationCharge - discount
  }
}
