import Bb from 'bluebird'
import DynamoRepo from '../lib/dynamo/DynamoRepo'
import Exception from '../lib/Exception'
import DynamoHelper from '../lib/dynamo/DynamoHelper'
import { OrderSchema } from './Schema'

export class OrderRepo extends DynamoRepo {
  constructor () {
    super('orders', OrderSchema.getDynamoSchema(), {
      hashKey: 'accountId',
      rangeKey: 'createdAt'
    })
  }

  getAllByAccountId (accountId, q) {
    return new Bb((resolve, reject) => {
      let query = this.model.query(accountId)

      if (q.limit) {
        query.limit(q.limit)
      }

      if (q.startKey) {
        query.startKey(q.startKey)
      }

      if (q.descending) {
        query.descending()
      }

      query
        .expressionAttributeNames(DynamoHelper.getExpressionAttributeNames(q.express, {
          '#accountId': 'accountId',
          '#createdAt': 'createdAt'
        }))
        .projectionExpression(DynamoHelper.getProjectionExpression(q.express, '#accountId,#createdAt'))
        .exec((err, results) => {
          if (err) {
            return reject(Exception.internal(err.message, err))
          }
          results.Items = results.Items.map((item) => item.attrs)
          resolve(results)
        })
    })
  }

  getAll (q) {
    return new Bb((resolve, reject) => {
      let query = this.model.scan()

      if (q.limit) {
        query.limit(q.limit)
      }

      if (q.startKey) {
        query.startKey(q.startKey)
      }

      if (q.businessPartnerId) {
        query.where('businessPartnerId').equals(q.businessPartnerId)
      }

      query
        .expressionAttributeNames(DynamoHelper.getExpressionAttributeNames(q.express, {
          '#accountId': 'accountId',
          '#createdAt': 'createdAt'
        }))
        .projectionExpression(DynamoHelper.getProjectionExpression(q.express, '#accountId,#createdAt'))
        .exec((err, results) => {
          if (err) {
            return reject(Exception.internal(err.message, err))
          }
          results.Items = results.Items.map((item) => item.attrs)
          resolve(results)
        })
    })
  }
}
