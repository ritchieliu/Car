import Bb from 'bluebird'
import jwt from 'jsonwebtoken'
import AuthPolicy from './AuthPolicy'

export default class CustomAuthorizer {
  static authenticate (authorizationToken, eventMethodArn, publicKey) {
    return new Bb((resolve, reject) => {
      jwt.verify(authorizationToken, publicKey, (err, payload) => {
        if (err) {
          return reject('Unauthorized')
        }

        // Valid token. Generate the API Gateway policy for the user
        // Always generate the policy on value of 'sub' claim and not for 'username' because username is reassignable
        // sub is UUID for a user which is never reassigned to another user.
        const principalId = payload.id

        // Get AWS AccountId and API Options

        const methodArn = eventMethodArn.split(':')
        const apiGatewayArn = methodArn[5].split('/')
        const awsAccountId = methodArn[4]
        const apiOptions = {
          region: methodArn[3],
          restApiId: apiGatewayArn[0],
          stage: apiGatewayArn[1]
        }

        // For more information on specifics of generating policy, refer to blueprint for API Gateway's Custom authorizer in Lambda console
        const policy = new AuthPolicy(principalId, payload, awsAccountId, apiOptions)
        policy.allowAllMethods()

        resolve(policy.build())
      })
    })
  }
}
