import CognitoCustomAuthorizer from './CustomAuthorizer'
import SsmService from '../../lib/ssmService/SsmService'

module.exports.handler = async (event, context, done) => {
  try {
    let result = await CognitoCustomAuthorizer.authenticate(event.authorizationToken, event.methodArn, await SsmService.getParameter('JWT_ID_TOKEN_PUBLIC_KEY'))
    return done(null, result)
  } catch (error) {
    console.log(error)
    return done('Unauthorized')
  }
}
