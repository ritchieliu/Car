import Bb from 'bluebird'
import { AccountSchema } from './Schema'
import DynamoRepo from '../lib/dynamo/DynamoRepo'
import Exception from '../lib/Exception'
import DynamoHelper from '../lib/dynamo/DynamoHelper'

export class AccountRepo extends DynamoRepo {
  constructor () {
    super('accounts', AccountSchema.getDynamoSchema(), {
      hashKey: 'id',
      indexes: [{
        hashKey: 'friendly_id',
        name: 'friendly_id-index',
        type: 'global'
      }]
    })
  }

  getInstanceByFriendlyId (friendlyId) {
    return new Bb((resolve, reject) => {
      this.model
        .query(friendlyId.toLowerCase().trim())
        .usingIndex('friendly_id-index')
        .exec(function (err, results) {
          if (err) {
            return reject(err)
          }

          if (results.Count === 0) {
            return resolve(null)
          }

          resolve(results.Items[0].attrs)
        })
    })
  }

  getAll (q) {
    return new Bb((resolve, reject) => {
      let query = this.model.scan()

      if (q.limit) {
        query.limit(q.limit)
      }

      if (q.startKey) {
        query.startKey(q.startKey)
      }

      if (q.name) {
        query.where('name').equals(q.name)
      }

      if (q.cognito_groups) {
        query.where('cognito_groups').equals(q.cognito_groups)
        q.express += ',cognito_groups'
      }

      query
        .expressionAttributeNames(DynamoHelper.getExpressionAttributeNames(q.express, {'#id': 'id'}))
        .projectionExpression(DynamoHelper.getProjectionExpression(q.express, '#id'))
        .exec((err, results) => {
          if (err) {
            return reject(Exception.internal(err.message, err))
          }
          results.Items = results.Items.map((item) => item.attrs)
          resolve(results)
        })
    })
  }
}
