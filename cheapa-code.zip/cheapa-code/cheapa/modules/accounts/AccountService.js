import { AccountRepo } from './Repo'
import Exception from '../lib/Exception'

const repo = new AccountRepo()

export class AccountService {
  static async getInstance (id) {
    let instance = await repo.getInstance(id)
    if (!instance) {
      throw Exception.notFound()
    }
    return instance
  }
}
