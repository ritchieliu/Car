import Bb from 'bluebird'
import CognitoIdentityServiceProvider from 'aws-sdk/clients/cognitoidentityserviceprovider'
import Exception from '../../lib/Exception'
import UuidUtil from '../../lib/util/UuidUtil'

export default class CognitoService {
  static authenticate (poolInfo, username, password) {
    return new Bb((resolve, reject) => {
      const params = {
        AuthFlow: 'ADMIN_NO_SRP_AUTH',
        ClientId: poolInfo.client_id,
        UserPoolId: poolInfo.pool_id,
        AuthParameters: {
          USERNAME: username,
          PASSWORD: password
        }
      }
      new CognitoIdentityServiceProvider().adminInitiateAuth(params, function (err, data) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve(data)
      })
    })
  }

  static async signUp (poolInfo, id, tempPassword, email, preferredUsername, phoneNumber, group, skipValidate) {
    let userAttributes = []
    let messageAction = null
    if (email) {
      userAttributes.push({
        'Name': 'email',
        'Value': email.toLowerCase().trim()
      }, {
        'Name': 'email_verified',
        'Value': 'true'
      })
    }
    if (preferredUsername) {
      userAttributes.push({
        'Name': 'preferred_username',
        'Value': preferredUsername
      })
    }
    if (phoneNumber) {
      userAttributes.push({
        'Name': 'phone_number',
        'Value': phoneNumber
      }, {
        'Name': 'phone_number_verified',
        'Value': 'true'
      })
    }

    if (skipValidate) {
      messageAction = 'SUPPRESS'
    }

    try {
      const params = {
        UserPoolId: poolInfo.pool_id,
        Username: id || UuidUtil.get(),
        DesiredDeliveryMediums: [
          'EMAIL'
        ],
        MessageAction: messageAction,
        TemporaryPassword: tempPassword || Math.floor(100000 + Math.random() * 900000).toString(), // 6 digits random password
        UserAttributes: userAttributes
      }
      let data = await new CognitoIdentityServiceProvider().adminCreateUser(params).promise()

      if (group) {
        await new CognitoIdentityServiceProvider().adminAddUserToGroup({
          GroupName: group,
          Username: data.User.Username,
          UserPoolId: poolInfo.pool_id
        }).promise()
      }
      return data
    } catch (err) {
      throw Exception.create(err.message, err.statusCode, err)
    }
  }

  static signOut (accessToken) {
    return new Bb((resolve, reject) => {
      const params = {
        AccessToken: accessToken
      }
      new CognitoIdentityServiceProvider().globalSignOut(params, function (err) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve()
      })
    })
  }

  static forgotPassword (poolInfo, username) {
    return new Bb((resolve, reject) => {
      const params = {
        ClientId: poolInfo.client_id,
        Username: username
      }
      new CognitoIdentityServiceProvider().forgotPassword(params, err => {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve()
      })
    })
  }

  static confirmForgotPassword (poolInfo, username, password, confirmCode) {
    return new Bb((resolve, reject) => {
      const params = {
        ClientId: poolInfo.client_id,
        ConfirmationCode: confirmCode,
        Password: password,
        Username: username
      }
      new CognitoIdentityServiceProvider().confirmForgotPassword(params, function (err) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve()
      })
    })
  }

  static newPassword (poolInfo, username, password, session) {
    return new Bb((resolve, reject) => {
      const params = {
        ChallengeName: 'NEW_PASSWORD_REQUIRED',
        ClientId: poolInfo.client_id,
        ChallengeResponses: {
          USERNAME: username,
          NEW_PASSWORD: password
        },
        Session: session
      }
      new CognitoIdentityServiceProvider().respondToAuthChallenge(params, function (err, data) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve(data)
      })
    })
  }

  static changePassword (accessToken, previousPassword, proposedPassword) {
    return new Bb((resolve, reject) => {
      const params = {
        PreviousPassword: previousPassword,
        ProposedPassword: proposedPassword,
        AccessToken: accessToken
      }
      new CognitoIdentityServiceProvider().changePassword(params, function (err) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve()
      })
    })
  }

  static refreshToken (poolInfo, refreshToken) {
    return new Bb((resolve, reject) => {
      const params = {
        AuthFlow: 'REFRESH_TOKEN',
        ClientId: poolInfo.client_id,
        UserPoolId: poolInfo.pool_id,
        AuthParameters: {
          REFRESH_TOKEN: refreshToken
        }
      }
      new CognitoIdentityServiceProvider().adminInitiateAuth(params, function (err, data) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve(data)
      })
    })
  }

  static enableUser (poolInfo, username) {
    return new Bb((resolve, reject) => {
      const params = {
        UserPoolId: poolInfo.pool_id,
        Username: username
      }
      new CognitoIdentityServiceProvider().adminEnableUser(params, function (err) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve()
      })
    })
  }

  static disableUser (poolInfo, username) {
    return new Bb((resolve, reject) => {
      const params = {
        UserPoolId: poolInfo.pool_id,
        Username: username
      }
      new CognitoIdentityServiceProvider().adminDisableUser(params, function (err) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve()
      })
    })
  }

  static getUser (poolInfo, username) {
    return new Bb((resolve, reject) => {
      const params = {
        UserPoolId: poolInfo.pool_id,
        Username: username
      }
      new CognitoIdentityServiceProvider().adminGetUser(params, function (err, data) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve(data)
      })
    })
  }

  static updateUser (poolInfo, username, attributes) {
    let userAttributes = Object.keys(attributes).map((key) => {
      let attribute = {
        'Name': key,
        'Value': attributes[key]
      }
      return attribute
    })

    if (attributes.email) {
      userAttributes.push({
        'Name': 'email_verified',
        'Value': 'true'
      })
    }
    if (attributes.phone_number) {
      userAttributes.push({
        'Name': 'phone_number_verified',
        'Value': 'true'
      })
    }

    return new Bb((resolve, reject) => {
      const params = {
        UserPoolId: poolInfo.pool_id,
        Username: username,
        UserAttributes: userAttributes
      }
      new CognitoIdentityServiceProvider().adminUpdateUserAttributes(params, function (err, data) {
        if (err) {
          return reject(Exception.create(err.message, err.statusCode, err))
        }
        resolve(data)
      })
    })
  }
}
