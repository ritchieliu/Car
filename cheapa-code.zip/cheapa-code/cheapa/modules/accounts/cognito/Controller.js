import ApiLambdaHandler from '../../lib/lambda/ApiLambdaHandler'
import CognitoService from './CognitoService'

const runner = {
  '/accounts/cognito/signUp': {},
  '/accounts/cognito/signIn': {},
  '/accounts/cognito/newPassword': {},
  '/accounts/cognito/forgotPassword': {},
  '/accounts/cognito/confirmForgotPassword': {},
  '/accounts/cognito/refreshToken': {},
  '/accounts/cognito/changePassword': {},
  '/accounts/cognito/signOut': {}
}

const poolInfo = {
  pool_id: process.env.COGNITO_USER_POOL_ID,
  client_id: process.env.COGNITO_USER_POOL_CLIENT_ID,
  provider_url: process.env.COGNITO_USER_POOL_PROVIDER_URL
}

runner['/accounts/cognito/signUp'].POST = async (request) => {
  return CognitoService.signUp(poolInfo, request.body.id, request.body.tempPassword, request.body.email, request.body.preferred_username, request.body.phone_number, request.body.group, request.body.skipValidate)
}

runner['/accounts/cognito/signIn'].POST = async (request) => {
  return CognitoService.authenticate(poolInfo, request.body.username, request.body.password)
}

runner['/accounts/cognito/newPassword'].POST = async (request) => {
  return CognitoService.newPassword(poolInfo, request.body.username, request.body.password, request.body.session)
}

runner['/accounts/cognito/forgotPassword'].POST = async (request) => {
  return CognitoService.forgotPassword(poolInfo, request.body.username)
}

runner['/accounts/cognito/confirmForgotPassword'].POST = async (request) => {
  return CognitoService.confirmForgotPassword(poolInfo, request.body.username, request.body.password, request.body.confirmCode)
}

runner['/accounts/cognito/refreshToken'].POST = async (request) => {
  return CognitoService.refreshToken(poolInfo, request.body.refreshToken)
}

runner['/accounts/cognito/changePassword'].POST = async (request) => {
  return CognitoService.changePassword(request.body.accessToken, request.body.previousPassword, request.body.proposedPassword)
}

runner['/accounts/cognito/signOut'].POST = async (request) => {
  return CognitoService.signOut(request.body.accessToken)
}

module.exports.handler = ApiLambdaHandler(runner)
