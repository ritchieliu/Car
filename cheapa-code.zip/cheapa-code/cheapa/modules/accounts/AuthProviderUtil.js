import Bb from 'bluebird'
import jwt from 'jsonwebtoken'
import GoogleVerifier from 'google-id-token-verifier'
import FB from 'fb'

export default class AuthProviderUtil {
  static authenticateCognito (authorizationToken, pems) {
    return new Bb((resolve, reject) => {
      const decodedJwt = jwt.decode(authorizationToken, {complete: true})
      if (!decodedJwt) {
        return reject('Unauthorized')
      }

      jwt.verify(authorizationToken, pems[decodedJwt.header.kid], {issuer: decodedJwt.payload.iss}, (err, payload) => {
        if (err) {
          return reject('Unauthorized')
        }

        resolve(payload)
      })
    })
  }

  static authenticateGoogle (authorizationToken, clientId) {
    return new Bb((resolve, reject) => {
      GoogleVerifier.verify(authorizationToken, clientId, (err, payload) => {
        if (err) {
          return reject('Unauthorized')
        }

        resolve(payload)
      })
    })
  }

  static authenticateFacebook (authorizationToken) {
    return new Bb((resolve, reject) => {
      FB.options({accessToken: authorizationToken})
      FB.api('/me', {
        fields: 'id,birthday,email,first_name,last_name,name,name_format,age_range,gender,languages,locale, timezone,currency,relationship_status,hometown,about,cover,devices,' +
        'education,favorite_athletes,favorite_teams,interested_in,link,location,political,quotes,religion,short_name,significant_other,sports,website,work'
      }, function (payload) {
        if (payload && payload.error) {
          return reject('Unauthorized')
        }
        resolve(payload)
      })
    })
  }
}
