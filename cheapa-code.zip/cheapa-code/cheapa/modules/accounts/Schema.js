import Joi from 'joi'

export class AccountSchema {
  static getDynamoSchema () {
    return Joi.object().keys({
      id: Joi.string().required(),
      friendly_id: Joi.string().email().lowercase().trim().required(),
      cognito_username: Joi.string(),
      cognito_id: Joi.string(),
      cognito_issuer: Joi.string(),
      cognito_groups: Joi.string().allow('', null),
      google_id: Joi.string(),
      google_issuer: Joi.string(),
      facebook_id: Joi.string(),
      facebook_issuer: Joi.string(),
      facebook_link: Joi.string(),
      email: Joi.string().email(),
      temp_password: Joi.string(),
      preferred_username: Joi.string(),
      phone_number: Joi.string(),
      given_name: Joi.string(),
      family_name: Joi.string(),
      picture: Joi.string(),
      name: Joi.string(),
      locale: Joi.string(),
      gender: Joi.string(),
      refresh_token: Joi.string(),
      enabled: Joi.boolean().default(true),
      createdAt: Joi.date().iso().required(),
      updatedAt: Joi.date().iso()
    })
  }

  static getViewSchema () {
    return Joi.object().keys({
      phone_number: Joi.string(),
      given_name: Joi.string(),
      family_name: Joi.string()
    })
  }
}
