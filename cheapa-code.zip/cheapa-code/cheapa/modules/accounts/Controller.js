import Joi from 'joi'
import ApiLambdaHandler from '../lib/lambda/ApiLambdaHandler'
import AuthProviderUtil from './AuthProviderUtil'
import JoiUtil from '../lib/util/JoiUtil'
import Exception from '../lib/Exception'
import JwtUtil from '../lib/util/JwtUtil'
import { AccountSchema } from './Schema'
import UuidUtil from '../lib/util/UuidUtil'
import { AccountRepo } from './Repo'
import { AccountService } from './AccountService'
import SsmService from '../lib/ssmService/SsmService'

const repo = new AccountRepo()

const runner = {
  '/accounts': {},
  '/accounts/{id}': {},
  '/accounts/token': {},
  '/accounts/token/refresh': {}
}

runner['/accounts'].GET = async (request) => {
  if (request.isAdmin) {
    return repo.getAll(request.q)
  }
}

runner['/accounts/{id}'].GET = async (request) => {
  if (request.isMember && request.path.id !== request.authorizer.id) {
    throw Exception.unauthorized()
  }
  let instance = await AccountService.getInstance(request.path.id)
  delete instance.refresh_token
  return instance
}

runner['/accounts/{id}'].PUT = async (request) => {
  if (request.isMember && request.path.id !== request.authorizer.id) {
    throw Exception.unauthorized()
  }
  JoiUtil.validate(request.body, AccountSchema.getViewSchema())
  let instance = await AccountService.getInstance(request.path.id)
  let result = await repo.update(Object.assign(instance, request.body, {id: request.path.id}))
  return {
    IdToken: await getIdToken(result)
  }
}

runner['/accounts/token'].GET = async (request) => {
  let instance = await AccountService.getInstance(request.authorizer.id)
  return {
    IdToken: await getIdToken(instance)
  }
}

runner['/accounts/token'].POST = async (request) => {
  JoiUtil.validate(request.body, {
    name: Joi.any().valid('cognito', 'facebook', 'google').required(),
    token: Joi.string()
  })

  let provider = request.body.name
  let authorizationPayload = {}
  try {
    switch (provider) {
      case 'cognito':
        authorizationPayload = await AuthProviderUtil.authenticateCognito(request.body.token, JSON.parse(process.env.COGNITO_USER_POOL_PUBLIC_KEY))
        authorizationPayload.friendly_id = authorizationPayload.email
        break
      case 'google':
        authorizationPayload = await AuthProviderUtil.authenticateGoogle(request.body.token, process.env.GOOGLE_CLIENT_ID)
        authorizationPayload.friendly_id = authorizationPayload.email
        break
      case 'facebook':
        authorizationPayload = await AuthProviderUtil.authenticateFacebook(request.body.token)
        authorizationPayload.friendly_id = authorizationPayload.email
        break
    }
  } catch (error) {
    throw Exception.unauthorized(error.message)
  }

  let accountEntity = await repo.getInstanceByFriendlyId(authorizationPayload.friendly_id)

  if (!accountEntity) {
    accountEntity = await saveAuth(provider, authorizationPayload, null)
  } else {
    if (!(accountEntity.cognito_issuer === authorizationPayload.iss ||
        accountEntity.google_issuer === authorizationPayload.iss ||
        accountEntity.facebook_issuer === provider)) {
      accountEntity = await saveAuth(provider, authorizationPayload, accountEntity)
    }
  }

  return {
    RefreshToken: accountEntity.refresh_token,
    IdToken: await getIdToken(accountEntity)
  }
}

runner['/accounts/token/refresh'].POST = async (request) => {
  JoiUtil.validate(request.body, {
    refresh_token: Joi.string().required()
  })

  try {
    let payload = JwtUtil.verify(request.body.refresh_token, await SsmService.getParameter('JWT_REFRESH_TOKEN_PUBLIC_KEY'))
    let accountEntity = await AccountService.getInstance(payload.id)
    if (!accountEntity.enabled) {
      throw Exception.unauthorized()
    }

    if (request.body.refresh_token !== accountEntity.refresh_token) {
      throw Exception.unauthorized()
    }

    return {
      IdToken: await getIdToken(accountEntity)
    }
  } catch (error) {
    throw Exception.unauthorized(error.message)
  }
}

async function getIdToken (accountEntity) {
  delete accountEntity.refresh_token
  return JwtUtil.sign(accountEntity, await SsmService.getParameter('JWT_ID_TOKEN_PRIVATE_KEY'), process.env.JWT_ALGORITHM, process.env.JWT_ISSUER, process.env.JWT_ID_TOKEN_EXPIRES_IN, process.env.JWT_AUDIENCE, process.env.JWT_KEY_ID)
}

async function getRefreshToken (id) {
  return JwtUtil.sign({id: id}, await SsmService.getParameter('JWT_REFRESH_TOKEN_PRIVATE_KEY'), process.env.JWT_ALGORITHM, process.env.JWT_ISSUER, 315360000, process.env.JWT_AUDIENCE, process.env.JWT_KEY_ID)
}

async function saveAuth (provider, authorizationPayload, entity) {
  let id = entity ? entity.id : UuidUtil.get()
  let auth = {
    id: id,
    friendly_id: authorizationPayload.friendly_id,
    email: authorizationPayload.email,
    preferred_username: authorizationPayload.preferred_username,
    phone_number: authorizationPayload.phone_number,
    given_name: authorizationPayload.given_name,
    family_name: authorizationPayload.family_name,
    gender: authorizationPayload.gender,
    picture: authorizationPayload.picture,
    name: authorizationPayload.name,
    locale: authorizationPayload.locale,
    refresh_token: await getRefreshToken(id)
  }

  switch (provider) {
    case 'cognito':
      auth.cognito_username = authorizationPayload['cognito:username']
      auth.cognito_id = authorizationPayload.sub
      auth.cognito_issuer = authorizationPayload.iss
      auth.cognito_groups = authorizationPayload['cognito:groups'] ? authorizationPayload['cognito:groups'].join(',') : null
      break
    case 'google':
      auth.google_id = authorizationPayload.sub
      auth.google_issuer = authorizationPayload.iss
      break
    case 'facebook':
      auth.given_name = authorizationPayload.first_name
      auth.family_name = authorizationPayload.last_name
      auth.facebook_id = authorizationPayload.id
      auth.facebook_issuer = provider
      auth.facebook_link = authorizationPayload.link
      break
  }

  if (entity) {
    return repo.update(Object.assign(entity, auth))
  }

  return repo.create(Object.assign(auth, {id: auth.id}))
}

module.exports.handler = ApiLambdaHandler(runner)
