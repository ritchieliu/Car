'use strict'

const Bb = require('bluebird')
const childProcess = require('child_process')
const AWS = require('aws-sdk')
const S3Service = require('./cloud/lib/S3Service')
const FileUtil = require('./lib/util/FileUtil')

const stage = process.argv[2] ? process.argv[2] : 'dev'
const _vars = Object.assign(JSON.parse(FileUtil.readFile(`${__dirname}/../env/env.json`, 'utf8')), JSON.parse(FileUtil.readFile(`${__dirname}/../env/env-${stage}.json`, 'utf8')))
_vars.deploymentBucket = `${_vars.appName}-code-bucket`

AWS.config.credentials = new AWS.SharedIniFileCredentials({profile: _vars.codeCommit.profile})
const logPath = `${__dirname}/cloud_log.txt`

console.log('Deploying to stage: ' + _vars.stage)

Bb.resolve()
  .then(clean)
  .then(() => S3Service.createBucket(_vars.codeCommit.profile, _vars.region, _vars.deploymentBucket))
  .then(outputVarsJson)
  .then(() => deploy('cloud/codeCommit'))
  .then(() => deploy('cloud/codeBuild'))

function clean () {
  FileUtil.deleteFile(logPath)
}

function outputVarsJson () {
  FileUtil.writeFile(`${__dirname}/vars.json`, JSON.stringify(_vars, null, 2))
}

function deploy (service) {
  return new Bb((resolve, reject) => {
    let cmdString = `cd ${__dirname}/${service} && sls deploy --stage ${_vars.stage}`
    FileUtil.log(logPath, cmdString)

    let cmd = childProcess.exec(cmdString)
    cmd.stdout.on('data', function (data) {
      if (data.toLowerCase().includes('error')) {
        FileUtil.log(logPath, `stderr: ${data}`)
        console.log(`stderr: ${data}`)
        return reject(data)
      }

      FileUtil.log(logPath, `stdout: ${data}`)
    })
    cmd.stderr.on('data', (data) => {
      FileUtil.log(logPath, `stderr: ${data}`)
      console.log(`stderr: ${data}`)
      return reject(data)
    })
    cmd.on('close', () => {
      FileUtil.log(logPath, `${service} Deployed`)
      console.log(`${service} Deployed`)
      resolve()
    })
  })
}
