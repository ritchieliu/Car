import { VehicleService } from '../Service'
import { VehicleRepo } from '../Repo'
import { DeviceReportRepo } from '../../devices/reports/Repo'
import { getPathLength } from 'geolib'
import moment from 'moment-timezone'

const repo = new VehicleRepo()
const deviceReportRepo = new DeviceReportRepo()
module.exports.handler = async (event, context, done) => {
  let offset = moment().tz('Australia/Sydney').format('Z')
  let today = moment().utcOffset(offset).set({
    hour: 0,
    minute: 0,
    second: 0,
    millisecond: 0
  }).utc()
  let startDate = today.toISOString()
  let endDate = today.add(1, 'days').toISOString()
  console.log(startDate)
  console.log(endDate)
  try {
    let vehicles = await VehicleService.getAll({
      express: 'id,deviceId,distance'
    })
    for (let vehicle of vehicles.Items) {
      if (!vehicle.deviceId) {
        continue
      }
      let deviceId = vehicle.deviceId
      let reports = await deviceReportRepo.getAll(deviceId, {
        startDate: startDate,
        endDate: endDate,
        express: 'deviceId,type,payload,createdAt'
      })
      reports = reports.Items.filter(item =>
        item.type === 'LOCATION' &&
        item.payload.latitude !== 0 &&
        item.payload.longitude !== 0
      ).map(item => {
        return {
          latitude: item.payload.latitude,
          longitude: item.payload.longitude
        }
      })
      let distance = {
        distance: getPathLength(reports),
        startDate: startDate,
        endDate: endDate
      }
      if (vehicle.distance && vehicle.distance.startDate === startDate && vehicle.distance.distance === distance.distance) {
        continue
      }
      vehicle.distance = distance
      console.log(vehicle.distance)
      await repo.partialUpdate(vehicle)
    }
    return done(null)
  } catch (error) {
    console.log(error)
    return done(error)
  }
}
