import Exception from '../lib/Exception'
import JoiUtil from '../lib/util/JoiUtil'
import { VehicleRepo } from './Repo'
import { VehicleSchema } from './Schema'
import Geo from 'geo-nearby'
import UuidUtil from '../lib/util/UuidUtil'
import ImageService from '../lib/image/ImageService'
import { VehicleCategoryService } from '../vehicleCategories/Service'

const repo = new VehicleRepo()

export class VehicleService {
  static async getAll (q) {
    if (q.express && !q.express.includes('vehicleCategoryId')) {
      q.express += ',vehicleCategoryId'
    }
    let list = await repo.getAll(q)
    let vehicleCategories = await VehicleCategoryService.getAll({express: 'id,name,rentPricePerDay,currency'})
    list.Items.forEach(item => {
      let vehicleCategory = vehicleCategories.Items.find(vc => vc.id === item.vehicleCategoryId)
      if (vehicleCategory) {
        this.mapCategoryToInstance(item, vehicleCategory)
      }
    })

    return list
  }

  static async getInstance (id) {
    let instance = await repo.getInstance(id)
    if (!instance) {
      throw Exception.notFound()
    }

    if (instance.vehicleCategoryId) {
      let vehicleCategory = await VehicleCategoryService.getInstance(instance.vehicleCategoryId)
      this.mapCategoryToInstance(instance, vehicleCategory)
    }

    return instance
  }

  static mapCategoryToInstance (vehicle, vehicleCategory) {
    vehicle.vehicleCategoryName = vehicleCategory.name
    if (vehicleCategory.rentPricePerDay) {
      vehicle.rentPricePerDay = vehicleCategory.rentPricePerDay
    }
    if (vehicleCategory.currency) {
      vehicle.currency = vehicleCategory.currency
    }
  }

  static async create (body) {
    JoiUtil.validate(body, VehicleSchema.getViewSchema())
    return repo.create(body)
  }

  static async update (id, body) {
    JoiUtil.validate(body, VehicleSchema.getViewSchema())
    let instance = await this.getInstance(id)
    return repo.update(Object.assign(instance, body))
  }

  static async delete (id) {
    await this.getInstance(id)
    return repo.destroy(id)
  }

  static async getNearby (q) {
    const vehicleList = await this.getAll(q)
    vehicleList.Items = vehicleList.Items.filter(item => item.location)

    if (vehicleList.Items.length === 0) {
      return []
    }

    const dataSet = Geo.createCompactSet(vehicleList.Items, {
      id: 'id',
      lat: ['location', 'latitude'],
      lon: ['location', 'longitude']
    })
    const geo = new Geo(dataSet, {sorted: true})
    const nearbyVehicles = geo.nearBy(q.latitude, q.longitude, q.range)
    return nearbyVehicles.map(item => vehicleList.Items.find(vehicle => vehicle.id === item.i))
  }

  static async createImage (id, body) {
    let instance = await this.getInstance(id)
    let key = `vehicles/${id}/${UuidUtil.get()}.jpg`
    let smallKey = `vehicles/${id}/${UuidUtil.get()}.jpg`
    let image = await ImageService.upload({key, smallKey, body: body.body})

    if (!instance.images) {
      instance.images = []
    }

    instance.images.push(image)
    await repo.update(instance)

    return image
  }

  static async deleteImage (id, key) {
    let instance = await this.getInstance(id)
    if (!instance.images) {
      return
    }

    let image = instance.images.find(item => {
      return item.key === key
    })

    if (!image) {
      return
    }

    await ImageService.remove({key: image.key, smallKey: image.smallKey})

    instance.images = instance.images.filter(item => {
      return item.key !== key
    })
    return repo.update(instance)
  }
}
