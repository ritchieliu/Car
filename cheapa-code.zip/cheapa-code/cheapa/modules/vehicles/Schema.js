import Joi from 'joi'
import { ImageSchema } from '../lib/image/Schema'

export class VehicleSchema {
  static getDynamoSchema () {
    return Joi.object().keys({
      id: Joi.string().uppercase().trim().required(),
      make: Joi.string().uppercase().trim().required(),
      model: Joi.string().uppercase().trim().required(),
      seatNumber: Joi.number().required(),
      transmission: this.getTransmission(),
      color: Joi.string().uppercase().trim().required(),
      year: Joi.number().required(),
      rentPricePerDay: Joi.number(),
      currency: this.getCurrency(),
      location: this.getLocationPayload(),
      deviceId: Joi.string(),
      operationStatus: this.getOperationStatus(),
      deviceStatus: this.getDeviceStatus(),
      images: this.getImages(),
      vehicleCategoryId: Joi.string().allow('', null),
      vehicleCategoryName: Joi.string().allow('', null),
      accountId: Joi.string().allow('', null),
      distance: this.getDistance(),
      createdAt: Joi.date().iso().required(),
      updatedAt: Joi.date().iso()
    })
  }

  static getViewSchema () {
    return Joi.object().keys({
      id: Joi.string().uppercase().trim().required(),
      make: Joi.string().uppercase().trim().required(),
      model: Joi.string().uppercase().trim().required(),
      seatNumber: Joi.number().required(),
      transmission: this.getTransmission(),
      color: Joi.string().uppercase().trim().required(),
      year: Joi.number().required(),
      deviceId: Joi.string(),
      operationStatus: this.getOperationStatus(),
      accountId: Joi.string().allow('', null),
      vehicleCategoryId: Joi.string().allow('', null)
    })
  }

  static getTransmission () {
    return Joi.string().valid(['AUTO', 'MANUAL']).required()
  }

  static getCurrency () {
    return Joi.string().valid(['AUD', 'USD', 'CNY'])
  }

  static getOperationStatus () {
    return Joi.string().valid(['AVAILABLE', 'IN_USE', 'MAINTAIN']).default('AVAILABLE')
  }

  static getDeviceStatus () {
    return Joi.string().valid(['NORMAL', 'ERROR'])
  }

  static getLocationPayload () {
    return Joi.object().keys({
      latitude: Joi.number().required(),
      longitude: Joi.number().required(),
      mileage: Joi.number().allow(null),
      updatedAt: Joi.date().iso()
    })
  }

  static getImages () {
    return Joi.array().items(
      ImageSchema.getImage()
    )
  }

  static getDistance () {
    return Joi.object().keys({
      distance: Joi.number().allow(null),
      startDate: Joi.date().iso(),
      endDate: Joi.date().iso()
    })
  }
}
