import Bb from 'bluebird'
import DynamoRepo from '../lib/dynamo/DynamoRepo'
import Exception from '../lib/Exception'
import DynamoHelper from '../lib/dynamo/DynamoHelper'
import { VehicleSchema } from './Schema'

export class VehicleRepo extends DynamoRepo {
  constructor () {
    super('vehicles', VehicleSchema.getDynamoSchema(), {
      hashKey: 'id'
    })
  }

  getAll (q) {
    return new Bb((resolve, reject) => {
      let query = this.model.scan()

      if (q.limit) {
        query.limit(q.limit)
      }

      if (q.startKey) {
        query.startKey(q.startKey)
      }

      if (q.name) {
        query.where('name').equals(q.name)
      }

      if (q.operationStatus) {
        query.where('operationStatus').equals(q.operationStatus)
      }

      if (q.deviceStatus) {
        query.where('deviceStatus').equals(q.deviceStatus)
      }

      if (q.hasLocation) {
        query.where('location').notNull()
      }

      if (q.accountId) {
        query.where('accountId').equals(q.accountId)
      }

      if (q.nullAccountId) {
        query.where('accountId').null()
        q.express += ',accountId'
      }

      query
        .expressionAttributeNames(DynamoHelper.getExpressionAttributeNames(q.express, {'#id': 'id'}))
        .projectionExpression(DynamoHelper.getProjectionExpression(q.express, '#id'))
        .exec((err, results) => {
          if (err) {
            return reject(Exception.internal(err.message, err))
          }
          results.Items = results.Items.map((item) => item.attrs)
          resolve(results)
        })
    })
  }
}
