import { VehicleService } from '../Service'
import DateUtil from '../../lib/util/DateUtil'
import moment from 'moment/moment'
import { VehicleRepo } from '../Repo'

const repo = new VehicleRepo()
module.exports.handler = async (event, context, done) => {
  try {
    let vehicles = await VehicleService.getAll({
      express: 'id,location,deviceStatus'
    })
    for (let vehicle of vehicles.Items) {
      let requireUpdate = false
      if (!vehicle.location) {
        continue
      }
      let locationUpdatedAt = DateUtil.toDate(vehicle.location.updatedAt)
      let minutesFromLastUpdate = moment.duration(DateUtil.now().diff(locationUpdatedAt)).asMinutes()
      if (minutesFromLastUpdate < 15) {
        if (vehicle.deviceStatus !== 'NORMAL') {
          requireUpdate = true
        }
        vehicle.deviceStatus = 'NORMAL'
      } else {
        if (vehicle.deviceStatus !== 'ERROR') {
          requireUpdate = true
        }
        vehicle.deviceStatus = 'ERROR'
      }

      if (requireUpdate) {
        await repo.partialUpdate(vehicle)
      }
    }
    return done(null)
  } catch (error) {
    console.log(error)
    return done(error)
  }
}
