import ApiLambdaHandler from '../lib/lambda/ApiLambdaHandler'
import { VehicleService } from './Service'

const runner = {
  '/vehicles': {},
  '/vehicles/{id}': {},
  '/vehicles/nearby': {},
  '/vehicles/{id}/images': {}
}

runner['/vehicles'].GET = async (request) => {
  return VehicleService.getAll(request.q)
}

runner['/vehicles/{id}'].GET = async (request) => {
  return VehicleService.getInstance(request.path.id)
}

runner['/vehicles'].POST = async (request) => {
  if (request.isAdmin) {
    return VehicleService.create(request.body)
  }
}

runner['/vehicles/{id}'].PUT = async (request) => {
  if (request.isAdmin) {
    return VehicleService.update(request.path.id, request.body)
  }
}

runner['/vehicles/{id}'].DELETE = async (request) => {
  if (request.isAdmin) {
    return VehicleService.delete(request.path.id)
  }
}

runner['/vehicles/nearby'].GET = async (request) => {
  return VehicleService.getNearby(request.q)
}

runner['/vehicles/{id}/images'].POST = async (request) => {
  if (request.isAdmin) {
    return VehicleService.createImage(request.path.id, request.body)
  }
}

runner['/vehicles/{id}/images'].DELETE = async (request) => {
  if (request.isAdmin) {
    return VehicleService.deleteImage(request.path.id, request.q.key)
  }
}

module.exports.handler = ApiLambdaHandler(runner)
