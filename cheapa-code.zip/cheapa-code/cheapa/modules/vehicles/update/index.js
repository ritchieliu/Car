import { VehicleService } from '../Service'
import { VehicleRepo } from '../Repo'
import delay from 'delay'

const repo = new VehicleRepo()
module.exports.handler = async (event, context, done) => {
  try {
    let vehicles = await VehicleService.getAll({
      express: 'id'
    })
    for (let vehicle of vehicles.Items) {
      let instance = await repo.getInstance(vehicle.id)
      if (instance.rentPricePerDay || instance.currency) {
        delete instance.rentPricePerDay
        delete instance.currency
        await repo.update(instance)
        await delay(500)
      }
    }
    return done(null)
  } catch (error) {
    console.log(error)
    return done(error)
  }
}
