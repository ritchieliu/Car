#!/bin/bash
rm modules/vars.json
node modules/run.js prod
rm modules/vars.json
