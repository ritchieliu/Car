const path = require('path')
const slsw = require('serverless-webpack')

module.exports = {
  entry: slsw.lib.entries,
  resolve: {
    extensions: [
      '.js',
      '.json']
  },
  stats: 'errors-only',
  output: {
    libraryTarget: 'commonjs',
    path: path.join(__dirname, '.webpack'),
    filename: '[name].js'
  },
  target: 'node',
  externals: ['aws-sdk'],
  mode: 'development',
  optimization: {
    minimize: false
  },
  performance: {hints: false},
  module: {
    rules: [
      {
        test: /\.js$/,
        loader: 'babel-loader',
        include: __dirname,
        exclude: /node_modules/,
        options: {
          presets: [
            [
              'env',
              {
                targets: {
                  node: '8.10'
                }
              }
            ]
          ]
        }
      }
    ]
  }
}
